# ch05-locked-harness (Ch 5 예제)

Ch 0의 CSV 합계 검사기에 세 가지 장치를 더한 판입니다.

1. 봉인: `python scripts/lock.py "이름"` 으로 tests/, samples/, CRITERIA.md 의 지문을 tests.lock 에 저장
2. 연속 실패 카운터: 같은 항목이 5번 연속 실패하면 verify.py 가 "멈춤"을 출력하고 종료 코드 1
3. 경비원 훅: AI가 봉인 파일을 고치려 하면 scripts/guard_locked.py 가 막음 (.claude/settings.json)

4. 기준서 점검기(Ch 4): `python scripts/criteria_lint.py drafts/criteria_draft_bad.md` 로 초안에 판정 불가 표현이 있는지 확인

## 실행 순서

```
python scripts/lock.py "홍길동"     # 사람이 승인할 때 한 번
python scripts/verify.py           # 검사 (11개 항목: 봉인 1 + 기준 7 + 봉인 장치 점검 3)
python scripts/lock.py --check     # 봉인 상태만 확인
```

- 표준 라이브러리만 씁니다. 테스트는 unittest 형식이며 pytest 로도 돌릴 수 있습니다.
- output/ 폴더는 Git에 올리지 않습니다. tests.lock 은 Git에 함께 올립니다.
