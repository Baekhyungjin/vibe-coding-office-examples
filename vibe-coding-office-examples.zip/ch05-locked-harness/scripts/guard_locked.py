"""PreToolUse 훅용 경비원: AI가 봉인된 파일을 고치려 하면 막는다.

Claude Code는 AI가 파일을 쓰거나 고치기 직전에 이 스크립트를 실행하고,
어떤 파일을 건드리려는지(JSON)를 표준 입력으로 넘겨준다.
봉인 대상이면 종료 코드 2로 막고, 이유를 AI에게 보여준다.

[확인 필요: 출간 직전 Claude Code 훅 문서에서 PreToolUse 입력 JSON의 필드 이름
(tool_name, tool_input.file_path)과 종료 코드 2의 차단 동작 재확인]
"""
import json
import sys
from pathlib import Path

if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
PROTECTED_DIRS = ["tests", "samples"]
PROTECTED_FILES = ["CRITERIA.md", "tests.lock"]


def is_protected(file_path):
    try:
        rel = Path(file_path).resolve().relative_to(ROOT)
    except ValueError:
        return False  # 이 폴더 밖의 파일은 상관하지 않는다
    parts = rel.parts
    if not parts:
        return False
    return parts[0] in PROTECTED_DIRS or rel.as_posix() in PROTECTED_FILES


def main():
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0
    tool_input = event.get("tool_input", {}) or {}
    target = tool_input.get("file_path") or tool_input.get("notebook_path")
    if target and is_protected(target):
        print(f"차단: {target} 는 사람이 승인한 봉인 파일입니다. "
              "고쳐야 할 이유가 있으면 파일을 고치지 말고 사람에게 먼저 설명하세요.",
              file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
