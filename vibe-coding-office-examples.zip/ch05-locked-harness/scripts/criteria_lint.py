"""기준서 맞춤법 검사기: CRITERIA.md 초안이 '판정 가능한 기준'으로 쓰였는지 점검한다. (Ch 4)

점검 항목
  C1. 성공 조건이 [S1], [S2] ... 번호로 1개 이상 있다
  C2. 금지사항이 [N1], [N2] ... 번호로 1개 이상 있다
  C3. S, N 줄에 판정할 수 없는 말(꼼꼼, 깔끔, 알아서 등)이 없다
  C4. 모든 S 줄에 숫자 또는 '판정:' 표시가 있다
  C5. '사람 최종 확인' 칸이 있고, 5줄 이하로 짧다

사용법:
    python scripts/criteria_lint.py drafts/criteria_draft_bad.md
    python scripts/criteria_lint.py CRITERIA.md
"""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

VAGUE = ["꼼꼼", "깔끔", "알아서", "적절", "최대한", "보기 좋", "빠르게", "정확하게",
         "완벽", "자연스럽", "센스", "문제없", "잘 "]


def lint(text):
    lines = text.splitlines()
    s_lines = [l for l in lines if re.search(r"\[S\d+\]", l)]
    n_lines = [l for l in lines if re.search(r"\[N\d+\]", l)]
    results = []

    results.append(("C1_성공조건_번호", bool(s_lines), f"[S번호] 항목 {len(s_lines)}개"))
    results.append(("C2_금지사항_번호", bool(n_lines), f"[N번호] 항목 {len(n_lines)}개"))

    vague_hits = []
    for l in s_lines + n_lines:
        for w in VAGUE:
            if w in l + " ":
                vague_hits.append(f"'{w.strip()}' in {l.strip()[:30]}")
    results.append(("C3_판정불가_표현없음", not vague_hits,
                    "없음" if not vague_hits else "; ".join(vague_hits)))

    no_measure = [l.strip()[:30] for l in s_lines
                  if not re.search(r"\d", re.sub(r"\[S\d+\]", "", l)) and "판정:" not in l]
    results.append(("C4_S항목_판정방법", bool(s_lines) and not no_measure,
                    "모두 있음" if not no_measure else "숫자/판정 없음: " + "; ".join(no_measure)))

    human_idx = next((i for i, l in enumerate(lines) if "사람 최종 확인" in l), None)
    if human_idx is None:
        results.append(("C5_사람확인칸_짧게", False, "'사람 최종 확인' 칸이 없습니다"))
    else:
        items = [l for l in lines[human_idx + 1:] if l.strip().startswith("- ")]
        results.append(("C5_사람확인칸_짧게", 1 <= len(items) <= 5, f"항목 {len(items)}개"))
    return results


def main():
    if len(sys.argv) != 2:
        print("사용법: python scripts/criteria_lint.py <기준서 파일>")
        return 1
    path = Path(sys.argv[1])
    results = lint(path.read_text(encoding="utf-8"))
    print(f"[기준서 점검] {path.name}")
    for name, ok, detail in results:
        print(f"  {'PASS' if ok else 'FAIL':<5} {name}: {detail}")
    passed = sum(1 for _, ok, _ in results if ok)
    print(f"RESULT: {'PASSED' if passed == len(results) else 'FAILED'} ({passed}/{len(results)})")
    return 0 if passed == len(results) else 2


if __name__ == "__main__":
    sys.exit(main())
