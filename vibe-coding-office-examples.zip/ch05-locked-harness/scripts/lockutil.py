"""봉인(잠금) 도구 모음. lock.py, verify.py, 테스트가 함께 쓴다.

봉인 대상: tests/ 폴더 전체, samples/ 폴더 전체, CRITERIA.md
봉인 파일: tests.lock (파일 경로별 SHA-256 지문 목록)

주의: 이것은 '자물쇠'가 아니라 '봉인 스티커'다.
누가 고치면 반드시 티가 나게 만드는 장치이지, 고치는 것 자체를 막지는 않는다.
고치는 것 자체를 막는 일은 PreToolUse 훅(scripts/guard_locked.py)이 맡는다.
"""
import hashlib
import json
from pathlib import Path

LOCK_NAME = "tests.lock"
LOCKED_DIRS = ["tests", "samples"]
LOCKED_FILES = ["CRITERIA.md"]
SKIP_PARTS = {"__pycache__"}


def locked_paths(root):
    root = Path(root)
    paths = []
    for d in LOCKED_DIRS:
        for p in sorted((root / d).rglob("*")):
            if p.is_file() and not (SKIP_PARTS & set(p.parts)):
                paths.append(p)
    for f in LOCKED_FILES:
        if (root / f).exists():
            paths.append(root / f)
    return paths


def fingerprint(root):
    root = Path(root)
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in locked_paths(root)}


def compare(root):
    """봉인 상태를 확인한다. (상태, 문제 목록)을 돌려준다.
    상태: 'OK' | 'NO_LOCK' | 'BROKEN'
    """
    root = Path(root)
    lock_file = root / LOCK_NAME
    if not lock_file.exists():
        return "NO_LOCK", ["tests.lock 이 없습니다. 사람이 테스트 목록을 승인한 뒤 python scripts/lock.py 를 실행해야 합니다."]
    saved = json.loads(lock_file.read_text(encoding="utf-8"))["files"]
    now = fingerprint(root)
    problems = []
    for path in sorted(set(saved) | set(now)):
        if path not in now:
            problems.append(f"삭제됨: {path}")
        elif path not in saved:
            problems.append(f"새로 생김: {path}")
        elif saved[path] != now[path]:
            problems.append(f"내용 바뀜: {path}")
    return ("OK" if not problems else "BROKEN"), problems
