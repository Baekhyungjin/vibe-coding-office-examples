# 공통 모듈 (common/)

앱 3(Ch 8)에서 만들고 검증한 부품을 다른 앱이 복사해 쓰도록 꺼내 둔 폴더입니다.
원본은 `app3-mail-mask/` 이며, 고칠 때는 앱 3에서 고치고 하네스를 통과시킨 뒤 이 폴더로 다시 복사합니다.

| 파일 | 복사 위치 | 하는 일 |
| --- | --- | --- |
| masking.py | 각 앱 `src/` | 개인정보 마스킹(Masker), 잔여 검사(residual_scan) |
| ai_call.py | 각 앱 `src/` (masking.py 와 같은 폴더) | AI 호출 창구. 잔여 검사 실패 시 MaskingNotPassed 로 호출 차단, `claude -p` / `codex exec` 호출, JSON 응답 스키마 검사, 테스트용 MockAI |
| verify_core.py | 각 앱 `scripts/` | verify_report.json 과 `RESULT: PASSED (n/n)` 규약, record_metric() 으로 측정 수치 기록 |

## 쓰는 법 (요약)
```python
from masking import Masker, residual_scan
from ai_call import call_ai, cli_backend, MockAI

m = Masker(roster=["가상이름"])
safe_text = m.mask(raw_text)                      # 1) 로컬 마스킹 먼저
data = call_ai("JSON으로 요약해줘\n" + safe_text,  # 2) AI는 그다음
               backend=cli_backend("claude"),
               schema={"required": {"summary": str}})
```

`scripts/verify.py` 는 아래 몇 줄이면 됩니다.
```python
from verify_core import run_harness
sys.exit(run_harness(Path(__file__).resolve().parent.parent, quiet="--quiet" in sys.argv))
```

## 알려진 한계 (테스트 세트 밖)
앱 3 하네스의 "누락 0건"은 가짜 메일 50개 기준입니다. 아래는 현재 잡지 못합니다.
- 성 없이 이름만 쓴 경우 (예: "하람이가")
- 한글로 읽은 번호 (예: "공일공 영일이삼 ...")
- 주민번호를 앞자리/뒷자리로 나눠 쓴 경우
그래서 잔여 검사와 사람 확인을 반드시 함께 씁니다.
