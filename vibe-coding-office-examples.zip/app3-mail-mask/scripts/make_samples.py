"""가짜 문의 메일 50개와 정답 라벨을 만든다 (samples/golden).

- 모든 이름, 번호, 주소는 가짜다.
  * 휴대폰: 010-0xxx-xxxx (가운데 자리가 0으로 시작하는 번호는 배정되지 않는 형식)
  * 주민번호: 생년월일 형식만 맞고, 옛 검증 숫자(마지막 자리)는 일부러 틀리게 만든다.
  * 카드: 4000-00 으로 시작하는 테스트용 번호(Luhn 검사만 통과)
  * 이메일: example.com / example.net (예시 전용 도메인)
- 같은 씨앗값(seed)으로 만들기 때문에 언제 돌려도 같은 샘플이 나온다.

사용법: python scripts/make_samples.py
"""
import csv
import json
import random
import sys
from email.message import EmailMessage
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "samples" / "golden"
rng = random.Random(20261018)

SURNAMES = list("김이박최정강조윤장임한오서신권황안송류홍")
GIVEN = ["다온", "윤슬", "라온", "하솔", "새봄", "로운", "겨레", "나린", "해솔", "가온",
         "이든", "시온", "도담", "아라", "별하", "마루", "하람", "온유", "누리", "단비"]


def make_name(used):
    while True:
        n = rng.choice(SURNAMES) + rng.choice(GIVEN)
        if n not in used:
            used.add(n)
            return n


def mobile():
    mid = f"0{rng.randint(100, 999)}"
    last = f"{rng.randint(0, 9999):04d}"
    style = rng.choice(["hyphen", "hyphen", "none", "dot", "space", "intl"])
    if style == "hyphen":
        return f"010-{mid}-{last}"
    if style == "none":
        return f"010{mid}{last}"
    if style == "dot":
        return f"010.{mid}.{last}"
    if style == "space":
        return f"010 {mid} {last}"
    return f"+82-10-{mid}-{last}"


def landline():
    area = rng.choice(["02", "031", "051", "062"])
    return f"{area}-0{rng.randint(10, 99)}-{rng.randint(0, 9999):04d}"


def rrn():
    yy = rng.randint(60, 99)
    mm = rng.randint(1, 12)
    dd = rng.randint(1, 28)
    g = rng.choice("1212")
    body = f"{yy:02d}{mm:02d}{dd:02d}{g}{rng.randint(0, 99999):05d}"
    w = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5]
    check = (11 - sum(int(a) * b for a, b in zip(body, w)) % 11) % 10
    wrong = (check + rng.randint(1, 9)) % 10  # 일부러 틀린 검증 숫자
    full = body + str(wrong)
    style = rng.choice(["hyphen", "none", "space"])
    if style == "hyphen":
        return f"{full[:6]}-{full[6:]}"
    if style == "space":
        return f"{full[:6]} {full[6:]}"
    return full


def foreign_rrn():
    s = rrn().replace("-", "").replace(" ", "")
    g = rng.choice("56")
    return f"{s[:6]}-{g}{s[7:]}"


def luhn_ok(num):
    total = 0
    for i, d in enumerate(reversed(num)):
        n = int(d)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def card():
    while True:
        body = "400000" + "".join(str(rng.randint(0, 9)) for _ in range(10))
        if luhn_ok(body):
            break
    style = rng.choice(["hyphen", "space", "none"])
    if style == "hyphen":
        return "-".join(body[i:i + 4] for i in range(0, 16, 4))
    if style == "space":
        return " ".join(body[i:i + 4] for i in range(0, 16, 4))
    return body


def email(name_seed):
    local = rng.choice(["sky", "blue", "moon", "tree", "river", "cloud"]) + str(rng.randint(10, 999))
    dom = rng.choice(["example.com", "example.net"])
    if rng.random() < 0.25:
        return f"{local} @ {dom}"
    return f"{local}@{dom}"


BANKS = ["국민은행", "신한은행", "우리은행", "하나은행", "농협", "카카오뱅크", "기업은행"]


def account():
    bank = rng.choice(BANKS)
    style = rng.choice(["a", "b", "c"])
    if style == "a":
        num = f"{rng.randint(100000, 999999)}-{rng.randint(10, 99)}-{rng.randint(100000, 999999)}"
    elif style == "b":
        num = f"{rng.randint(100, 999)}-{rng.randint(100, 999)}-{rng.randint(100000, 999999)}"
    else:
        num = f"{rng.randint(10**11, 10**12 - 1)}"
    return bank, num


ADDRS = [
    ("서울특별시 마포구 상암산로 {n}, {h}호"),
    ("경기도 성남시 분당구 정자일로 {n}"),
    ("부산 해운대구 센텀동로 {n} {h}호"),
    ("인천광역시 연수구 컨벤시아대로 {n}"),
    ("대전 유성구 대학로 {n}, {h}호"),
    ("서울 강서구 마곡중앙로 {n}"),
]


def address():
    return rng.choice(ADDRS).format(n=rng.randint(10, 299), h=rng.randint(101, 1504))


# 개인정보가 아닌데 숫자가 많은 값들 (오탐 측정용)
def order_no():
    return f"2026{rng.randint(1001, 1031)}{rng.randint(10000, 99999)}"  # 13자리


def barcode():
    return f"880{rng.randint(10**9, 10**10 - 1)}"  # 13자리, 국내 상품 바코드 형식


def product_code():
    return f"{rng.choice(['MX', 'KT', 'HB', 'QA'])}-{rng.randint(1000, 9999)}-{rng.choice('ABCDK')}"


def a_date():
    return f"2026-{rng.randint(9, 10):02d}-{rng.randint(1, 28):02d}"


def tracking():
    return f"{rng.randint(5000, 6999)} {rng.randint(1000, 9999)} {rng.randint(1000, 9999)}"


CATS = ["배송", "환불", "제품문의", "불만", "기타"]


def build_mail(i, cat, roster_name, used):
    pii = []
    nonpii = []
    non_roster = []
    lines = []

    def add(kind, value):
        pii.append({"type": kind, "value": value})
        return value

    def safe(value):
        nonpii.append(value)
        return value

    greet = rng.choice([f"안녕하세요. 저는 {roster_name}입니다.",
                        f"안녕하세요, {roster_name} 고객입니다.",
                        f"{roster_name}입니다. 문의드립니다."])
    add("name_roster", roster_name)
    lines.append(greet)
    on = order_no()  # 실제로 본문에 쓸 때만 safe()로 정답표에 올린다

    if cat == "배송":
        other = make_name(used)
        non_roster.append(other)
        add("name_other", other)
        lines.append(f"주문번호 {safe(on)} 상품이 아직 도착하지 않았습니다.")
        lines.append(f"운송장 번호 {safe(tracking())} 로 조회해도 배송 중으로만 나옵니다.")
        lines.append(f"받는 분은 {other} 님이고 주소는 {add('address', address())} 입니다.")
        lines.append(f"주문일은 {safe(a_date())} 이었고, 언제 배송되는지 알려주세요.")
    elif cat == "환불":
        bank, num = account()
        lines.append(f"주문번호 {safe(on)} 건 환불 요청드립니다. 상품코드 {safe(product_code())} 입니다.")
        lines.append(f"반품은 {safe(a_date())}에 보냈고 환불 계좌는 {bank} {add('account', num)} 입니다.")
        if rng.random() < 0.5:
            lines.append(f"결제한 카드는 {add('card', card())} 인데 카드 취소로 해주셔도 됩니다.")
        other = make_name(used)
        non_roster.append(other)
        add("name_other", other)
        lines.append(f"예금주는 가족인 {other} 씨 명의입니다.")
    elif cat == "제품문의":
        lines.append(f"상품코드 {safe(product_code())} 제품 사용법이 궁금합니다.")
        lines.append(f"바코드 {safe(barcode())} 붙은 제품인데 설명서가 없습니다.")
        lines.append("필터 교체 주기와 호환되는 부품이 있는지 문의드립니다.")
        if rng.random() < 0.5:
            other = make_name(used)
            non_roster.append(other)
            add("name_other", other)
            lines.append(f"매장 직원 {other} 님이 이메일로 물어보라고 하셨어요.")
    elif cat == "불만":
        lines.append(f"주문번호 {safe(on)} 제품을 받았는데 정말 실망스럽습니다.")
        lines.append("상담 전화를 세 번이나 했는데 연결이 안 되고 응대도 불친절했습니다.")
        lines.append(f"{safe(a_date())}에 통화한 상담원 태도에 항의합니다. 책임자 답변 바랍니다.")
        if rng.random() < 0.7:
            other = make_name(used)
            non_roster.append(other)
            add("name_other", other)
            lines.append(f"같이 주문한 친구 {other} 씨도 같은 일을 겪었습니다.")
    else:  # 기타
        lines.append("회원 등급 기준과 적립금 사용 방법이 궁금합니다.")
        lines.append("그리고 매장 영업시간도 알려주시면 감사하겠습니다.")
        if rng.random() < 0.5:
            lines.append(f"본인 확인이 필요하다고 해서 주민번호 적습니다. {add('rrn', rrn())}")
        if rng.random() < 0.3:
            lines.append(f"외국인 등록번호는 {add('rrn', foreign_rrn())} 입니다.")

    # 공통 연락처
    lines.append(f"연락은 {add('phone', mobile())} 로 부탁드립니다.")
    if rng.random() < 0.4:
        lines.append(f"낮에는 회사 번호 {add('phone', landline())} 로 주셔도 됩니다.")
    lines.append(f"메일 회신은 {add('email', email(roster_name))} 로 주세요.")
    if cat != "기타" and rng.random() < 0.25:
        lines.append(f"본인 확인용 주민번호 {add('rrn', rrn())} 입니다.")
    # 이름이 호칭 없이 끝에 한 번 더 나오는 경우
    lines.append(rng.choice([f"{roster_name} 드림", f"감사합니다. {roster_name}", "감사합니다."]))
    if lines[-1] != "감사합니다.":
        add("name_roster", roster_name)
    return "\n".join(lines), pii, nonpii, non_roster


# 명단에 없는 이름이 호칭 없이 나와서 놓치기 쉬운 메일 (정직하게 측정하려고 일부러 넣음)
HARD_NAME_LINES = [
    "어제 동생 {n}이가 대신 받았는데 상자가 찢어져 있었다고 합니다.",
    "남편이 {n}이라서 그 이름으로 주문이 들어갔을 수도 있어요.",
]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    mails_dir = OUT / "mails"
    mails_dir.mkdir(exist_ok=True)
    for old in mails_dir.glob("*.eml"):
        old.unlink()
    used = set()
    roster = [make_name(used) for _ in range(35)]
    with open(OUT / "customers.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["고객번호", "이름"])
        for k, n in enumerate(roster, 1):
            w.writerow([f"C{k:04d}", n])

    labels = []
    cats = [c for c in CATS for _ in range(10)]
    rng.shuffle(cats)
    for i, cat in enumerate(cats, 1):
        rname = roster[(i - 1) % len(roster)]
        body, pii, nonpii, non_roster = build_mail(i, cat, rname, used)
        if i in (7, 31):  # 호칭 없는 이름 2건
            other = make_name(used)
            non_roster.append(other)
            pii.append({"type": "name_other", "value": other})
            body += "\n" + HARD_NAME_LINES[0 if i == 7 else 1].format(n=other)
        msg = EmailMessage()
        mid = f"M{i:03d}"
        msg["Subject"] = f"[{mid}] 고객 문의"
        msg["From"] = "customer@example.com"
        msg["To"] = "cs@example.com"
        msg["Message-ID"] = f"<{mid}@example.com>"
        msg.set_content(body)
        (mails_dir / f"{mid}.eml").write_bytes(bytes(msg))
        labels.append({"id": mid, "category": cat, "pii": pii, "non_pii": nonpii,
                       "non_roster_names": non_roster})

    (OUT / "labels.json").write_text(json.dumps(labels, ensure_ascii=False, indent=1), encoding="utf-8")
    total_pii = sum(len(x["pii"]) for x in labels)
    print(f"메일 {len(labels)}개, 개인정보 {total_pii}건, 비개인정보 숫자값 {sum(len(x['non_pii']) for x in labels)}건, 명단 {len(roster)}명")


if __name__ == "__main__":
    main()
