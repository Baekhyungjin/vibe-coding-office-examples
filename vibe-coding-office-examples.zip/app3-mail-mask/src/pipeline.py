"""문의 메일 처리 흐름: 읽기 -> 로컬 마스킹 -> 잔여 검사 -> 분류 -> (필요할 때만) AI -> 저장

사용법 (앱 폴더에서):
    python src/pipeline.py samples/golden/mails --roster samples/golden/customers.csv
    python src/pipeline.py data/inbox --roster data/customers.csv --ai claude   # 실제 사용 [확인 필요]
"""
import argparse
import csv
import email
import sys
from email import policy
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))

from ai_call import MaskingNotPassed, BadAIResponse, call_ai, cli_backend  # noqa: E402
from classify import CATEGORIES, classify  # noqa: E402
from masking import Masker, residual_scan  # noqa: E402

DRAFT_TEMPLATES = {
    "배송": "{who} 안녕하세요. 문의하신 주문의 배송 상황을 확인하고 있습니다. 확인되는 대로 다시 안내드리겠습니다.",
    "환불": "{who} 안녕하세요. 환불 요청을 접수했습니다. 반품 상품 확인 후 처리 결과를 안내드리겠습니다.",
    "제품문의": "{who} 안녕하세요. 문의하신 제품 사용법과 부품 정보를 정리해 안내드리겠습니다.",
    "불만": "{who} 안녕하세요. 불편을 드려 죄송합니다. 담당 책임자가 내용을 확인한 뒤 직접 연락드리겠습니다.",
    "기타": "{who} 안녕하세요. 문의 주셔서 감사합니다. 요청하신 내용을 확인해 안내드리겠습니다.",
}

AI_SCHEMA = {"required": {"category": str, "draft": str}, "enum": {"category": CATEGORIES}}


def read_roster(path):
    if not path:
        return []
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [row["이름"].strip() for row in csv.DictReader(f) if row.get("이름")]


def read_mails(folder):
    """폴더 안의 .eml 파일 또는 CSV(id, body 열)를 읽는다."""
    folder = Path(folder)
    mails = []
    for p in sorted(folder.glob("*.eml")):
        msg = email.message_from_bytes(p.read_bytes(), policy=policy.default)
        part = msg.get_body(preferencelist=("plain",))
        mails.append({"id": p.stem, "body": part.get_content() if part else ""})
    for p in sorted(folder.glob("*.csv")):
        with open(p, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if "body" in row:
                    mails.append({"id": row.get("id") or f"{p.stem}-{len(mails)+1}", "body": row["body"]})
    return mails


def process(mails, roster, ai_backend=None, ai_all=False):
    """ai_all=False: 분류 확신이 낮은 메일만 AI로 / True: 모든 메일의 답변 초안을 AI로"""
    masker = Masker(roster)
    results = []
    for m in mails:
        masked = masker.mask(m["body"])
        counts = dict(masker.counts)
        leftovers = residual_scan(masked, roster)
        cls = classify(masked)
        row = {"id": m["id"], "category": cls["category"], "evidence": ",".join(cls["evidence"]),
               "masked_count": sum(counts.values()), "status": "정상", "masked": masked, "draft": ""}
        if leftovers:
            row["status"] = "사람 확인 필요(잔여 개인정보)"
            results.append(row)
            continue
        who = next((a for a in masker.alias.values() if a in masked), "고객님,")
        row["draft"] = DRAFT_TEMPLATES[row["category"]].format(who=who)
        if ai_backend is not None and (ai_all or not cls["confident"]):
            prompt = ("다음 고객 문의를 배송/환불/제품문의/불만/기타 중 하나로 분류하고 "
                      "정중한 답변 초안을 써라. JSON만 출력: {\"category\": ..., \"draft\": ...}\n\n" + masked)
            try:
                data = call_ai(prompt, ai_backend, AI_SCHEMA, roster)
                row["category"], row["draft"] = data["category"], data["draft"]
                row["status"] = "AI 보정"
            except (MaskingNotPassed, BadAIResponse) as e:
                row["status"] = f"사람 확인 필요({e.__class__.__name__})"
        results.append(row)
    return results, masker


def save(results, masker, out_dir, mapping_path):
    out_dir = Path(out_dir)
    drafts = out_dir / "drafts"
    if drafts.exists():  # 지난 실행의 초안이 섞이지 않게 비우고 시작
        for old in drafts.glob("*.txt"):
            old.unlink()
    drafts.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "분류결과.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["메일ID", "유형", "근거", "마스킹건수", "상태"])
        for r in results:
            w.writerow([r["id"], r["category"], r["evidence"], r["masked_count"], r["status"]])
    for r in results:
        if r["draft"]:
            (out_dir / "drafts" / f"{r['id']}.txt").write_text(
                f"[마스킹된 문의]\n{r['masked']}\n\n[답변 초안 - 발송 전 사람 확인]\n{r['draft']}\n",
                encoding="utf-8")
    mapping_path = Path(mapping_path)
    mapping_path.parent.mkdir(parents=True, exist_ok=True)
    with open(mapping_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["실명", "가명"])
        w.writeheader()
        w.writerows(masker.mapping_rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inbox")
    ap.add_argument("--roster")
    ap.add_argument("--ai", choices=["none", "claude", "codex"], default="none")
    ap.add_argument("--ai-all", action="store_true", help="모든 메일 답변 초안을 AI로")
    ap.add_argument("--out", default="output")
    args = ap.parse_args()
    backend = None if args.ai == "none" else cli_backend(args.ai)
    results, masker = process(read_mails(args.inbox), read_roster(args.roster), backend, args.ai_all)
    save(results, masker, args.out, "data/mapping.csv")
    need = sum(1 for r in results if r["status"].startswith("사람"))
    print(f"메일 {len(results)}건 처리, 사람 확인 필요 {need}건. 결과: {args.out}/분류결과.csv")


if __name__ == "__main__":
    main()
