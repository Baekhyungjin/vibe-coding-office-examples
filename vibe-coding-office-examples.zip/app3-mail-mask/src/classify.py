"""키워드 규칙으로 문의 유형을 나눈다 (모드 A, AI 미사용)

점수가 가장 높은 유형을 고르고, 근거 키워드를 함께 돌려준다.
1등과 2등 점수 차이가 작으면 '확신 낮음'으로 표시한다(이것만 AI 보정 대상).
"""
CATEGORIES = ["배송", "환불", "제품문의", "불만", "기타"]

KEYWORDS = {
    "배송": {"배송": 2, "도착": 2, "운송장": 3, "택배": 2, "받는 분": 2, "출고": 2},
    "환불": {"환불": 3, "반품": 2, "취소": 2, "계좌": 1, "예금주": 1},
    "제품문의": {"사용법": 3, "설명서": 2, "호환": 2, "부품": 1, "교체 주기": 2, "궁금": 1},
    "불만": {"실망": 3, "불친절": 3, "항의": 3, "책임자": 2, "화가": 2, "연결이 안": 2},
    "기타": {"회원 등급": 3, "적립금": 2, "영업시간": 2, "제휴": 2},
}


def classify(text):
    scores = {}
    evidence = {}
    for cat, words in KEYWORDS.items():
        hits = [w for w in words if w in text]
        scores[cat] = sum(words[w] for w in hits)
        evidence[cat] = hits
    ranked = sorted(CATEGORIES, key=lambda c: (-scores[c], CATEGORIES.index(c)))
    best, second = ranked[0], ranked[1]
    if scores[best] == 0:
        return {"category": "기타", "evidence": [], "confident": False}
    confident = scores[best] - scores[second] >= 2
    return {"category": best, "evidence": evidence[best], "confident": confident}
