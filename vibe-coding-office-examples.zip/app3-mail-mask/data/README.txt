이 폴더에는 실제 메일과 고객 명단(customers.csv), 대응표(mapping.csv)만 둡니다.
.gitignore 로 Git에서 제외되어 있습니다. 이 폴더 내용을 AI 채팅창이나 메일로 보내지 마세요.
