# 앱 3. 문의 메일 분류 & 개인정보 자동 마스킹 (Ch 8)

배포 등급: **로컬 전용**. 공개 웹에 올리지 마세요.

## 실행 방법 3줄 (이 폴더에서)
```
python scripts/make_samples.py                     # 가짜 메일 50개 만들기 (이미 들어 있음)
python src/pipeline.py samples/golden/mails --roster samples/golden/customers.csv
python scripts/verify.py                           # 하네스: RESULT: PASSED (10/10) 이 나와야 함
```

## 실제 메일에 쓸 때
1. 메일 프로그램에서 문의 메일을 .eml 로 내보내 `data/inbox/` 에 넣는다. (CSV라면 `id`, `body` 열)
2. 고객 명단을 `data/customers.csv` (열: 고객번호, 이름) 로 둔다.
3. `python src/pipeline.py data/inbox --roster data/customers.csv`
4. AI 보정을 쓰려면 `--ai claude` 또는 `--ai codex` 를 붙인다. [확인 필요: 독자 환경에서 claude -p / codex exec 실제 호출 확인]

## 폴더
- src/masking.py : 마스킹 + 잔여 검사 (공통 모듈 common/ 과 같은 파일)
- src/ai_call.py : AI 호출 창구. 마스킹 검사 미통과 시 호출 차단
- src/classify.py : 키워드 규칙 분류
- src/pipeline.py : 읽기 -> 마스킹 -> 잔여 검사 -> 분류 -> (선택) AI -> 저장
- scripts/verify.py, scripts/verify_core.py : 하네스
- samples/golden : 가짜 메일 50개(mails/), 가짜 고객 명단, 정답 라벨(labels.json)
- samples/trap : 반드시 잡혀야 하는 함정 4종
- data/ : 실데이터, 대응표 (Git 제외)
