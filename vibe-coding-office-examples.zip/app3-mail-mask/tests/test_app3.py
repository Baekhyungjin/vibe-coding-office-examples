"""앱 3 하네스 테스트 (CRITERIA.md 의 S/N 항목과 사양서 T1~T6 에 대응)"""
import csv
import json
import shutil
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from ai_call import BadAIResponse, MaskingNotPassed, MockAI, call_ai  # noqa: E402
from masking import residual_scan  # noqa: E402
from pipeline import AI_SCHEMA, process, read_mails, read_roster, save  # noqa: E402
from verify_core import record_metric  # noqa: E402

GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
STRUCTURED = {"phone", "rrn", "email", "card", "account", "address"}

_cache = {}


def run_golden():
    if not _cache:
        labels = json.loads((GOLDEN / "labels.json").read_text(encoding="utf-8"))
        roster = read_roster(GOLDEN / "customers.csv")
        results, masker = process(read_mails(GOLDEN / "mails"), roster)
        _cache.update(labels={x["id"]: x for x in labels}, roster=roster,
                      results={r["id"]: r for r in results}, masker=masker)
    return _cache


class T1_정형정보(unittest.TestCase):
    def test_T1_정형개인정보_누락0(self):
        c = run_golden()
        total, missed = 0, []
        for mid, lab in c["labels"].items():
            masked = c["results"][mid]["masked"]
            for p in lab["pii"]:
                if p["type"] in STRUCTURED:
                    total += 1
                    if p["value"] in masked:
                        missed.append(f"{mid}:{p['type']}:{p['value']}")
        record_metric(ROOT, "정형 개인정보 건수", total)
        record_metric(ROOT, "정형 개인정보 누락", len(missed))
        self.assertEqual(missed, [], f"누락 {len(missed)}건: {missed[:5]}")


class T2_이름(unittest.TestCase):
    def test_T2_명단이름_누락0_명단외_탐지율기록(self):
        c = run_golden()
        roster_total, roster_missed, other_total, other_found = 0, [], 0, 0
        for mid, lab in c["labels"].items():
            masked = c["results"][mid]["masked"]
            for p in lab["pii"]:
                if p["type"] == "name_roster":
                    roster_total += 1
                    if p["value"] in masked:
                        roster_missed.append(f"{mid}:{p['value']}")
                elif p["type"] == "name_other":
                    other_total += 1
                    other_found += p["value"] not in masked
        rate = round(other_found / other_total, 3) if other_total else 1.0
        record_metric(ROOT, "명단 이름 누락", f"{len(roster_missed)}/{roster_total}")
        record_metric(ROOT, "명단 외 이름 탐지율", f"{rate} ({other_found}/{other_total}, 목표 0.95)")
        self.assertEqual(roster_missed, [], f"명단 이름 누락: {roster_missed[:5]}")


class T3_오탐(unittest.TestCase):
    def test_T3_주문번호_바코드_날짜_오탐률_5퍼센트이하(self):
        c = run_golden()
        total, broken = 0, []
        for mid, lab in c["labels"].items():
            masked = c["results"][mid]["masked"]
            for v in lab["non_pii"]:
                total += 1
                if v not in masked:
                    broken.append(f"{mid}:{v}")
        rate = round(len(broken) / total, 3)
        record_metric(ROOT, "오탐률(주문번호/바코드/상품코드/날짜/운송장)", f"{rate} ({len(broken)}/{total})")
        self.assertLessEqual(rate, 0.05, f"오탐 {len(broken)}건: {broken[:5]}")


class T4_AI차단(unittest.TestCase):
    def test_T4_마스킹안된글은_AI호출차단(self):
        prompt = (TRAP / "trap2_unmasked_prompt.txt").read_text(encoding="utf-8")
        ai = MockAI('{"category": "기타", "draft": "x"}')
        with self.assertRaises(MaskingNotPassed):
            call_ai(prompt, ai, AI_SCHEMA, ["홍새봄"])
        self.assertEqual(ai.received, [], "차단됐다면 가짜 AI는 아무것도 받지 않아야 합니다")

    def test_T4_AI가받은글에_개인정보0(self):
        c = run_golden()
        ai = MockAI('{"category": "기타", "draft": "확인 후 안내드리겠습니다."}')
        process(read_mails(GOLDEN / "mails"), c["roster"], ai_backend=ai, ai_all=True)
        leaks = [f for p in ai.received for f in residual_scan(p, c["roster"])]
        record_metric(ROOT, "AI로 보낸 글(모든 메일 초안 모드)", len(ai.received))
        self.assertEqual(leaks, [])


class T5_분류(unittest.TestCase):
    def test_T5_분류정확도_85퍼센트이상(self):
        c = run_golden()
        right = sum(c["results"][mid]["category"] == lab["category"] for mid, lab in c["labels"].items())
        acc = round(right / len(c["labels"]), 3)
        record_metric(ROOT, "분류 정확도(키워드 규칙)", f"{acc} ({right}/{len(c['labels'])})")
        self.assertGreaterEqual(acc, 0.85)


class T6_결과물재검사(unittest.TestCase):
    def test_T6_output전체_개인정보패턴0(self):
        c = run_golden()
        tmp = ROOT / "data" / "_test"  # 대응표는 data/ 에만 (Git 제외 폴더)
        try:
            results = list(c["results"].values())
            tmp.mkdir(parents=True, exist_ok=True)
            save(results, c["masker"], ROOT / "output", tmp / "mapping.csv")
            found = []
            for p in (ROOT / "output").rglob("*"):
                if p.is_file() and p.suffix in (".csv", ".txt"):
                    for f in residual_scan(p.read_text(encoding="utf-8-sig"), c["roster"]):
                        found.append(f"{p.name}:{f['type']}:{f['value']}")
            self.assertEqual(found, [], f"output 에 남은 개인정보: {found[:5]}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class 함정샘플(unittest.TestCase):
    def test_TRAP1_새어나간_결과물을_잔여검사가_잡는다(self):
        text = (TRAP / "trap1_leaked_output.txt").read_text(encoding="utf-8")
        kinds = {f["type"] for f in residual_scan(text, read_roster(TRAP / "trap1_roster.csv"))}
        self.assertTrue({"전화", "이메일", "계좌", "이름"} <= kinds, f"잡은 종류: {kinds}")

    def test_TRAP3_JSON아닌_AI응답은_거부(self):
        reply = (TRAP / "trap3_free_text_reply.txt").read_text(encoding="utf-8")
        with self.assertRaises(BadAIResponse):
            call_ai("[고객A] 배송 문의", MockAI(reply), AI_SCHEMA)

    def test_TRAP4_허용목록밖_유형은_거부(self):
        reply = (TRAP / "trap4_wrong_category_reply.json").read_text(encoding="utf-8")
        with self.assertRaises(BadAIResponse):
            call_ai("[고객A] 배송 문의", MockAI(reply), AI_SCHEMA)


if __name__ == "__main__":
    unittest.main()
