"""앱 1 하네스 테스트. CRITERIA.md 의 T1~T6 + 함정 샘플 검사(H1) + 숨김/병합 주의(FR5).

승인(봉인) 후에는 이 파일을 고치지 않는다.
"""
import hashlib
import sys
import time
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from openpyxl import Workbook, load_workbook  # noqa: E402
import excel_check as ec  # noqa: E402

GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
OUT = ROOT / "output" / "test_run"


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def errors(res):
    return [(i.sheet, i.cell) for i in res.issues if i.level == ec.ERROR]


class AppOneHarness(unittest.TestCase):

    def test_T1_골든샘플은_오류0건(self):
        files = sorted(GOLDEN.glob("*.xlsx"))
        self.assertGreaterEqual(len(files), 2, "골든 샘플이 2개 이상 있어야 합니다")
        for f in files:
            res = ec.check_file(f, out_dir=OUT)
            self.assertEqual(res.status, "통과", f"{f.name}: {res.status}, {errors(res)}")
            self.assertEqual(errors(res), [], f.name)

    def test_T2_1원차이_3곳을_정확한좌표로_찾는다(self):
        res = ec.check_file(TRAP / "budget_err_row.xlsx", out_dir=OUT)
        self.assertEqual(sorted(errors(res)), sorted([("예산", "N3"), ("실적", "N2"), ("실적", "N4")]))
        for i in res.issues:
            if i.level == ec.ERROR:
                self.assertEqual(i.diff, "1", f"{i.sheet}!{i.cell} 차이 {i.diff}")

    def test_T3_문자숫자와_빈캐시수식을_경고한다(self):
        res = ec.check_file(TRAP / "budget_err_text.xlsx", out_dir=OUT)
        converted = sorted((i.sheet, i.cell) for i in res.issues if i.level == ec.CONVERTED)
        self.assertEqual(converted, [("예산", "C2"), ("예산", "E3")], "문자 숫자 변환 기록")
        self.assertIn(("실적", "H4"), errors(res), "'미정'은 오류여야 합니다")
        self.assertEqual(len(errors(res)), 1, f"'미정' 1곳 외에 다른 오류가 번지면 안 됩니다: {errors(res)}")

        res = ec.check_file(TRAP / "budget_no_cache.xlsx", out_dir=OUT)
        self.assertEqual(res.status, "확인불가", "계산값 없는 수식은 확인불가여야 합니다")
        self.assertTrue(any("저장" in i.message for i in res.issues if i.level == ec.UNKNOWN),
                        "'엑셀에서 한 번 저장 후 다시 올려 주세요' 안내가 있어야 합니다")

    def test_T4_원본파일_지문이_바뀌지않는다(self):
        for f in sorted(GOLDEN.glob("*.xlsx")) + sorted(TRAP.glob("*.xlsx")):
            before = sha256(f)
            ec.check_file(f, out_dir=OUT)
            self.assertEqual(before, sha256(f), f"{f.name} 원본이 바뀌었습니다")

    def test_T5_오류칸만_빨간배경_정상칸서식불변(self):
        src = TRAP / "budget_err_row.xlsx"
        res = ec.check_file(src, out_dir=OUT)
        out = load_workbook(res.output_xlsx)
        orig = load_workbook(src)
        red = set(errors(res))
        for sheet in ("예산", "실적"):
            for row in orig[sheet].iter_rows():
                for cell in row:
                    o = out[sheet][cell.coordinate]
                    if (sheet, cell.coordinate) in red:
                        self.assertEqual(o.fill.fgColor.rgb[-6:], "FF0000", f"{sheet}!{cell.coordinate}")
                    else:
                        self.assertEqual(o.fill.fill_type, cell.fill.fill_type, f"{sheet}!{cell.coordinate} 배경")
                        self.assertEqual(o.number_format, cell.number_format, f"{sheet}!{cell.coordinate} 표시형식")
                        self.assertEqual(o.font.b, cell.font.b, f"{sheet}!{cell.coordinate} 굵게")
                        self.assertEqual(o.value, cell.value, f"{sheet}!{cell.coordinate} 값")
        self.assertIn("검증요약", out.sheetnames)

    def test_T6_1만행_30열을_10초안에_처리한다(self):
        # 승인 후 변경 1건(사람 승인): 시스템 임시 폴더 권한 문제로 output/test_run/t6 를 쓰도록 바꿈
        tmp = OUT / "t6"
        tmp.mkdir(parents=True, exist_ok=True)
        big = Path(tmp) / "big.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.append(["항목"] + [f"c{j}" for j in range(28)] + ["합계"])
        col_sum = [0] * 28
        for i in range(10000):
            vals = [(i * 7 + j * 13) % 9973 for j in range(28)]
            col_sum = [a + b for a, b in zip(col_sum, vals)]
            ws.append([f"r{i}"] + vals + [sum(vals)])
        ws.append(["합계"] + col_sum + [sum(col_sum)])
        wb.save(big)
        start = time.perf_counter()
        res = ec.check_file(big, out_dir=Path(tmp) / "out")
        elapsed = time.perf_counter() - start
        print(f"\n[T6] 10000행 x 30열 처리 {elapsed:.2f}초", file=sys.stderr)
        self.assertEqual(res.status, "통과")
        self.assertLess(elapsed, 10.0, f"{elapsed:.2f}초 걸렸습니다")

    def test_H1_함정샘플은_모두_FAIL(self):
        files = sorted(TRAP.glob("*.xlsx"))
        self.assertGreaterEqual(len(files), 3, "함정 샘플이 3개 이상 있어야 합니다")
        for f in files:
            res = ec.check_file(f, out_dir=OUT)
            self.assertNotEqual(res.status, "통과", f"{f.name} 함정이 통과해 버렸습니다")

    def test_FR5_숨김열과_병합셀은_주의로_표시한다(self):
        res = ec.check_file(GOLDEN / "budget_ok_hidden.xlsx", out_dir=OUT)
        cautions = [i for i in res.issues if i.level == ec.CAUTION]
        self.assertTrue(any("숨김" in i.message for i in cautions), "숨김 열 주의 없음")
        self.assertTrue(any("병합" in i.message for i in cautions), "병합 셀 주의 없음")
        self.assertEqual(res.status, "통과", "주의만 있으면 판정은 통과여야 합니다")


if __name__ == "__main__":
    unittest.main()
