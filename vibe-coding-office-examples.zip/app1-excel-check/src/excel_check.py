"""엑셀 교차 검증기 (앱 1) - 검증 로직

표 모양 가정 (사람이 바꿀 수 있음)
  - 1행: 제목 줄(1월, 2월 ... 합계)
  - A열: 항목 이름(부서명 ... 합계)
  - '합계/총계/계/소계'라고 적힌 열과 행을 합계 칸으로 자동 탐지

검사 3가지
  1. 각 행: 숫자 칸의 합 = 그 행의 합계 칸
  2. 각 열: 숫자 칸의 합 = 그 열의 합계 칸
  3. 전체: 모든 숫자 칸의 합 = 오른쪽 아래 총합계 칸

원본 파일은 읽기만 한다. 결과는 output/ 에 새 파일로 만든다.
"""
import csv
import sys
from dataclasses import dataclass, field, asdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import column_index_from_string, get_column_letter

sys.dont_write_bytecode = True

TOLERANCE = Decimal("0")          # 허용 오차 기본값 0원. 테스트 통과용으로 늘리지 말 것.
MAX_MB = 20
MAX_SHEETS = 20
TOTAL_WORDS = ["합계", "총계", "계", "소계"]   # 앞쪽일수록 우선
RED = PatternFill(fill_type="solid", fgColor="FFFF0000")

# 결과 구분
ERROR = "오류"          # 합계 불일치, 숫자가 아닌 값
UNKNOWN = "확인불가"    # 계산값이 없는 수식 등, 검사할 수 없음
CAUTION = "주의"        # 병합 셀, 숨김 행/열, 빈 칸
CONVERTED = "변환"      # 문자로 적힌 숫자를 숫자로 바꿔 계산함

NO_CACHE_MSG = "수식의 계산값이 저장되어 있지 않습니다. 엑셀에서 파일을 한 번 열어 저장한 뒤 다시 올려 주세요."


@dataclass
class Issue:
    sheet: str
    cell: str
    level: str
    message: str
    expected: str = ""
    actual: str = ""
    diff: str = ""


@dataclass
class Result:
    file: str
    status: str = "통과"
    issues: list = field(default_factory=list)
    output_xlsx: str = ""
    output_csv: str = ""

    def count(self, level):
        return sum(1 for i in self.issues if i.level == level)


def _norm(text):
    return str(text).replace(" ", "").strip() if text is not None else ""


def find_total(cells):
    """[(위치, 값)] 중 합계 단어가 적힌 위치. 같은 단어면 가장 오른쪽/아래쪽."""
    for word in TOTAL_WORDS:
        hits = [pos for pos, v in cells if _norm(v) == word]
        if hits:
            return hits[-1]
    return None


def to_number(value):
    """(숫자, 변환여부, 오류문구). 숫자로 볼 수 없으면 숫자는 None."""
    if isinstance(value, bool):
        return None, False, "참/거짓 값"
    if isinstance(value, int):
        return Decimal(value), False, ""
    if isinstance(value, float):
        return Decimal(str(value)), False, ""
    if isinstance(value, str):
        cleaned = value.strip().replace(",", "")
        try:
            return Decimal(cleaned), True, ""
        except InvalidOperation:
            return None, False, f"숫자가 아닌 값 '{value}'"
    if value is None:
        return Decimal(0), False, ""
    return None, False, f"알 수 없는 형식 {type(value).__name__}"


def check_file(path, tolerance=TOLERANCE, out_dir=None, write_output=True, total_row=None, total_col=None):
    """total_row(숫자), total_col(숫자 또는 열 문자)를 주면 자동 탐지 대신 그 위치를 합계로 쓴다."""
    if isinstance(total_col, str) and total_col.strip():
        total_col = column_index_from_string(total_col.strip().upper())
    path = Path(path)
    result = Result(file=path.name)
    if path.suffix.lower() in (".xls", ".csv"):
        raise ValueError(f"{path.suffix} 파일은 바로 검사할 수 없습니다. 엑셀에서 .xlsx로 저장한 뒤 올려 주세요.")
    if path.stat().st_size > MAX_MB * 1024 * 1024:
        raise ValueError(f"파일이 {MAX_MB}MB를 넘습니다. 시트를 나눠서 올려 주세요.")

    values_wb = load_workbook(path, data_only=True)
    if len(values_wb.sheetnames) > MAX_SHEETS:
        raise ValueError(f"시트가 {MAX_SHEETS}개를 넘습니다. 파일을 나눠서 올려 주세요.")

    formula_wb = None
    for ws in values_wb.worksheets:
        if formula_wb is None and _has_empty_cells(ws):
            # 빈 칸이 수식인지(계산값이 없는 수식) 확인하려면 수식 그대로의 파일이 필요하다
            formula_wb = load_workbook(path, data_only=False)
        _check_sheet(ws, tolerance, result, formula_wb[ws.title] if formula_wb else None,
                     total_row or None, total_col or None)

    if result.count(UNKNOWN):
        result.status = "확인불가"
    elif result.count(ERROR):
        result.status = "오류"

    if write_output:
        _write_outputs(path, result, out_dir or Path(__file__).resolve().parent.parent / "output")
    return result


def _has_empty_cells(ws):
    for row in ws.iter_rows(values_only=True):
        if None in row:
            return True
    return False


def _no_cache(fws, r, c):
    """계산값 없이 수식만 있는 칸인가? (openpyxl로 만든 파일, 엑셀에서 저장한 적 없는 파일)"""
    if fws is None:
        return False
    v = fws.cell(r, c).value
    return isinstance(v, str) and v.startswith("=")


def _cautions(ws, result):
    name = ws.title
    for letter, dim in ws.column_dimensions.items():
        if dim.hidden:
            result.issues.append(Issue(name, f"{letter}열", CAUTION, "숨김 열이 있습니다. 숨겨진 숫자도 합계에 포함해 계산했습니다."))
    for r, dim in ws.row_dimensions.items():
        if dim.hidden:
            result.issues.append(Issue(name, f"{r}행", CAUTION, "숨김 행이 있습니다. 숨겨진 숫자도 합계에 포함해 계산했습니다."))
    for rng in ws.merged_cells.ranges:
        result.issues.append(Issue(name, str(rng), CAUTION, "병합 셀이 있습니다. 병합된 칸은 첫 칸 값만 읽습니다."))


def _check_sheet(ws, tolerance, result, fws=None, fixed_row=None, fixed_col=None):
    name = ws.title
    _cautions(ws, result)
    max_r, max_c = ws.max_row, ws.max_column
    total_col = fixed_col or find_total([(c, ws.cell(1, c).value) for c in range(2, max_c + 1)])
    total_row = fixed_row or find_total([(r, ws.cell(r, 1).value) for r in range(2, max_r + 1)])
    if total_col is None or total_row is None:
        missing = "열" if total_col is None else "행"
        result.issues.append(Issue(name, "-", UNKNOWN, f"'합계' {missing}을 찾지 못했습니다. 합계 위치를 직접 지정해 주세요."))
        return

    rows = range(2, total_row)
    cols = range(2, total_col)
    grid = {}
    empty = 0
    for r in rows:
        for c in cols:
            v = ws.cell(r, c).value
            num, converted, err = to_number(v)
            ref = f"{get_column_letter(c)}{r}"
            if v is None and _no_cache(fws, r, c):
                result.issues.append(Issue(name, ref, UNKNOWN, NO_CACHE_MSG))
                num = None
            elif v is None:
                empty += 1
            if err:
                result.issues.append(Issue(name, ref, ERROR, err))
            elif converted:
                result.issues.append(Issue(name, ref, CONVERTED, f"문자 '{v}'를 숫자 {num}로 바꿔 계산"))
            grid[(r, c)] = num

    def compare(cells, total_rc, what):
        nums = [grid[rc] for rc in cells]
        if any(n is None for n in nums):
            return
        tr, tc = total_rc
        ref = f"{get_column_letter(tc)}{tr}"
        if ws.cell(tr, tc).value is None and _no_cache(fws, tr, tc):
            result.issues.append(Issue(name, ref, UNKNOWN, f"{what} 합계 칸: " + NO_CACHE_MSG))
            return
        stated, _, err = to_number(ws.cell(tr, tc).value)
        if err:
            result.issues.append(Issue(name, ref, ERROR, f"{what} 합계 칸: {err}"))
            return
        expected = sum(nums, Decimal(0))
        diff = stated - expected
        if abs(diff) > tolerance:
            result.issues.append(Issue(name, ref, ERROR, f"{what} 합계 불일치",
                                       str(expected), str(stated), str(diff)))

    if empty:
        result.issues.append(Issue(name, "-", CAUTION, f"빈 칸 {empty}개를 0으로 계산했습니다."))
    for r in rows:
        compare([(r, c) for c in cols], (r, total_col), f"{r}행")
    for c in cols:
        compare([(r, c) for r in rows], (total_row, c), f"{get_column_letter(c)}열")
    compare(list(grid), (total_row, total_col), "전체")


def _write_outputs(path, result, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    red_cells = [i for i in result.issues if i.level == ERROR and i.cell != "-"]
    if red_cells:
        wb = load_workbook(path)                  # 원본 사본(수식 그대로)을 메모리에 연다
        for issue in red_cells:
            wb[issue.sheet][issue.cell].fill = RED
    else:
        # 칠할 칸이 없으면 큰 파일을 다시 열고 저장할 필요가 없다 (1만 행 기준 약 5초 절약)
        wb = Workbook()
        wb.remove(wb.active)
    ws = wb.create_sheet("검증요약")
    header = ["시트", "칸", "구분", "내용", "기대값", "실제값", "차이"]
    ws.append(["파일", result.file, "판정", result.status])
    ws.append(header)
    for i in result.issues:
        ws.append([i.sheet, i.cell, i.level, i.message, i.expected, i.actual, i.diff])
    xlsx = out_dir / f"{path.stem}_검증결과.xlsx"
    wb.save(xlsx)
    csv_path = out_dir / f"{path.stem}_검증결과.csv"
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(header)
        for i in result.issues:
            w.writerow([i.sheet, i.cell, i.level, i.message, i.expected, i.actual, i.diff])
    result.output_xlsx, result.output_csv = str(xlsx), str(csv_path)


def main(argv):
    if len(argv) < 2:
        print("사용법: python src/excel_check.py <엑셀파일.xlsx> [허용오차]")
        return 1
    tol = Decimal(argv[2]) if len(argv) > 2 else TOLERANCE
    res = check_file(argv[1], tolerance=tol)
    print(f"[{res.file}] 판정: {res.status}  (오류 {res.count(ERROR)} / 확인불가 {res.count(UNKNOWN)} "
          f"/ 주의 {res.count(CAUTION)} / 변환 {res.count(CONVERTED)})")
    for i in res.issues:
        extra = f"  기대 {i.expected} / 적힌 값 {i.actual} / 차이 {i.diff}" if i.diff else ""
        print(f"  {i.level:<4} {i.sheet}!{i.cell}  {i.message}{extra}")
    print("결과 파일:", res.output_xlsx)
    return 0 if res.status == "통과" else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
