"""엑셀 교차 검증기 (앱 1) - 화면

실행:  streamlit run src/app.py
설치:  pip install streamlit openpyxl
배포 등급: 로컬 전용. 공개 클라우드에 올리지 마세요(실데이터 업로드 위험).
"""
import sys
import tempfile
from decimal import Decimal
from pathlib import Path

import streamlit as st

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import excel_check as ec  # noqa: E402

OUT = Path(__file__).resolve().parent.parent / "output"

st.set_page_config(page_title="엑셀 교차 검증기", layout="wide")
st.title("엑셀 교차 검증기")
st.caption("행/열 합계가 합계 칸과 맞는지 검사합니다. 원본은 바뀌지 않고, 결과는 output 폴더에 새 파일로 만들어집니다.")

uploaded = st.file_uploader("검사할 엑셀 파일(.xlsx, 20MB 이하)", type=["xlsx", "xls", "csv"])
with st.expander("세부 설정"):
    tol = st.number_input("허용 오차(원)", min_value=0.0, value=0.0, step=0.01, format="%.2f")
    st.caption("기본값 0원. 1원이라도 다르면 오류로 표시합니다.")
    auto = st.checkbox("'합계' 위치 자동 찾기", value=True)
    total_row = total_col = None
    if not auto:
        total_row = st.number_input("합계 행 번호", min_value=2, value=5, step=1)
        total_col = st.text_input("합계 열 문자(예: N)", value="N")

if uploaded and st.button("검사 시작", type="primary"):
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / uploaded.name           # 업로드된 사본만 다룬다
        path.write_bytes(uploaded.getvalue())
        try:
            res = ec.check_file(path, tolerance=Decimal(str(tol)), out_dir=OUT,
                                total_row=None if auto else int(total_row),
                                total_col=None if auto else total_col)
        except ValueError as e:
            st.error(str(e))
            st.stop()

    color = {"통과": st.success, "오류": st.error, "확인불가": st.warning}[res.status]
    color(f"판정: {res.status}  |  오류 {res.count(ec.ERROR)}  확인불가 {res.count(ec.UNKNOWN)}  "
          f"주의 {res.count(ec.CAUTION)}  변환 {res.count(ec.CONVERTED)}")
    rows = [{"시트": i.sheet, "칸": i.cell, "구분": i.level, "내용": i.message,
             "기대값": i.expected, "적힌 값": i.actual, "차이": i.diff} for i in res.issues]
    if rows:
        st.dataframe(rows, use_container_width=True)
    c1, c2 = st.columns(2)
    c1.download_button("결과 엑셀 받기", Path(res.output_xlsx).read_bytes(), file_name=Path(res.output_xlsx).name)
    c2.download_button("오류 목록 CSV 받기", Path(res.output_csv).read_bytes(), file_name=Path(res.output_csv).name)
