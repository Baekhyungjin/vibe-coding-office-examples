# 앱 1. 엑셀 교차 검증기 (Ch 6)

부서별 예산/실적 엑셀의 행/열 합계가 합계 칸과 맞는지 자동으로 검사합니다.
틀린 칸은 빨간색으로 칠한 사본을 output/ 에 만듭니다. 원본은 바뀌지 않습니다.

## 실행 3줄

```
pip install openpyxl                         # 처음 한 번 (화면까지 쓰려면: pip install streamlit openpyxl)
python scripts/verify.py                     # 하네스. 마지막 줄 RESULT: PASSED (8/8) 확인
python src/excel_check.py data/내파일.xlsx    # 파일 검사 (화면: streamlit run src/app.py)
```

## 폴더

| 위치 | 내용 |
| --- | --- |
| CRITERIA.md | 성공 기준서 (승인 후 잠금) |
| CLAUDE.md | AI 작업 규칙과 실수 기록 |
| src/excel_check.py | 검사 로직 (openpyxl + 표준 라이브러리만 사용) |
| src/app.py | Streamlit 화면 |
| tests/test_excel_check.py | 하네스 테스트 8개 |
| samples/golden, samples/trap | AI가 만든 가짜 엑셀 (scripts/make_samples.py) |
| scripts/verify.py | 하네스 실행, output/verify_report.json 생성 |
| data/ | 여러분의 실제 파일을 두는 곳. Git에 올라가지 않습니다 |

## 배포 등급: 로컬 전용

이 앱은 내 PC에서만 실행합니다. 공개 클라우드(Streamlit Community Cloud 등)에 올리지 마세요.
업무 엑셀이 외부 서버로 올라가게 됩니다.

## 지원하지 않는 것

- .xls, .csv: 엑셀에서 .xlsx로 저장한 뒤 검사
- 소계가 중간중간 끼어 있는 다단계 표: 소계 단위로 시트를 나누거나 합계 위치를 직접 지정
- 차트, 매크로, 조건부 서식이 많은 파일: 결과 사본에서 일부 서식이 빠질 수 있음(원본은 그대로)
