"""가짜 예산/실적 엑셀 샘플을 만든다. (AI가 생성한 가짜 숫자, 실데이터 아님)

골든(통과해야 함)
  samples/golden/budget_ok.xlsx         3개 부서 x 12개월, 예산/실적 2개 시트, 합계 정확
  samples/golden/budget_ok_hidden.xlsx  위와 같지만 숨김 열 1개, 병합 셀 1개 ('주의'만 나와야 함)
함정(반드시 FAIL 나야 함)
  samples/trap/budget_err_row.xlsx      행 합계 3곳이 1원씩 틀림
  samples/trap/budget_err_text.xlsx     문자로 적힌 숫자 2곳 + 숫자가 아닌 값('미정') 1곳
  samples/trap/budget_no_cache.xlsx     합계 칸이 수식인데 엑셀에서 저장한 적이 없어 계산값이 없음

사용법: python scripts/make_samples.py
주의: 승인(봉인) 후에는 다시 실행하지 않는다. 샘플이 바뀌면 지문이 달라진다.
"""
import random
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
DEPTS = ["영업1팀", "영업2팀", "마케팅팀"]
MONTHS = [f"{m}월" for m in range(1, 13)]
TOTAL_COL = 2 + len(MONTHS)          # N열
TOTAL_ROW = 2 + len(DEPTS)           # 5행


def numbers(seed):
    rnd = random.Random(seed)
    return [[rnd.randrange(800, 5000) * 1000 + rnd.randrange(0, 1000) for _ in MONTHS] for _ in DEPTS]


def fill_sheet(ws, grid, formulas=False):
    ws.cell(1, 1, "부서").font = Font(bold=True)
    for j, m in enumerate(MONTHS):
        ws.cell(1, 2 + j, m).font = Font(bold=True)
    ws.cell(1, TOTAL_COL, "합계").font = Font(bold=True)
    for i, dept in enumerate(DEPTS):
        r = 2 + i
        ws.cell(r, 1, dept)
        for j, v in enumerate(grid[i]):
            ws.cell(r, 2 + j, v).number_format = "#,##0"
        last = get_column_letter(TOTAL_COL - 1)
        ws.cell(r, TOTAL_COL, f"=SUM(B{r}:{last}{r})" if formulas else sum(grid[i])).number_format = "#,##0"
    ws.cell(TOTAL_ROW, 1, "합계").font = Font(bold=True)
    for j in range(len(MONTHS) + 1):
        c = 2 + j
        col = get_column_letter(c)
        if formulas:
            v = f"=SUM({col}2:{col}{TOTAL_ROW - 1})"
        elif c == TOTAL_COL:
            v = sum(sum(row) for row in grid)
        else:
            v = sum(row[j] for row in grid)
        ws.cell(TOTAL_ROW, c, v).number_format = "#,##0"


def book(seed, formulas=False):
    wb = Workbook()
    wb.active.title = "예산"
    fill_sheet(wb["예산"], numbers(seed), formulas)
    fill_sheet(wb.create_sheet("실적"), numbers(seed + 1), formulas)
    return wb


def main():
    g, t = ROOT / "samples" / "golden", ROOT / "samples" / "trap"
    g.mkdir(parents=True, exist_ok=True)
    t.mkdir(parents=True, exist_ok=True)

    book(2026).save(g / "budget_ok.xlsx")

    wb = book(2027)
    wb["예산"].column_dimensions["G"].hidden = True       # 6월 열 숨김
    wb["실적"].merge_cells("A6:C6")                        # 표 아래 메모 칸 병합
    wb["실적"]["A6"] = "비고: 6월 실적은 잠정치"
    wb.save(g / "budget_ok_hidden.xlsx")

    # 함정 1: 행 합계 3곳을 1원씩 틀리게 (예산 N3, 실적 N2, 실적 N4)
    wb = book(2028)
    for sheet, cell in [("예산", "N3"), ("실적", "N2"), ("실적", "N4")]:
        wb[sheet][cell] = wb[sheet][cell].value + 1
    wb.save(t / "budget_err_row.xlsx")

    # 함정 2: 문자로 적힌 숫자 2곳(합계는 맞음) + '미정' 1곳
    wb = book(2029)
    ws = wb["예산"]
    ws["C2"] = f"{ws['C2'].value:,}"          # "1,234,567" 처럼 쉼표 문자
    ws["E3"] = f" {ws['E3'].value} "          # 앞뒤 공백 문자
    ws2 = wb["실적"]
    ws2["H4"] = "미정"
    wb.save(t / "budget_err_text.xlsx")

    # 함정 3: 합계를 수식으로만 저장 (엑셀에서 열어 저장한 적 없음 -> 계산값 없음)
    book(2030, formulas=True).save(t / "budget_no_cache.xlsx")

    for p in sorted((ROOT / "samples").rglob("*.xlsx")):
        print("생성:", p.relative_to(ROOT).as_posix())


if __name__ == "__main__":
    main()
