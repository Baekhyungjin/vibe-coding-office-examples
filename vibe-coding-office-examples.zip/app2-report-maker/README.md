# 앱 2: 사내 서식 보고서 자동 생성기

메모를 넣으면 `1. 개요 / 2. 추진실적 / 3. 향후계획` 서식의 보고서(Markdown, HTML, DOCX, PDF)가 나옵니다.
AI는 문장 정리만 하고, 합격 여부는 `src/report.py`의 검사기가 정합니다.

## 실행 (3줄)

```
python scripts/verify.py                                   # 하네스 (AI 미사용, 가짜 응답)
python src/make_report.py data/memo.txt --ai claude --pdf  # 실제 메모 (구독 CLI 사용)
python src/make_report.py samples/golden/memo_01.txt --ai mock:samples/golden/reply_01.json --pdf  # AI 없이 체험
```

브라우저를 띄울 수 없는 환경(일부 샌드박스, 서버)에서는 `REPORT_SKIP_BROWSER=1`을 켜면 PDF 직접 생성 검사만 생략합니다. 생략했다는 사실은 verify 출력과 리포트의 측정 줄에 남습니다. 평소 PC에서는 켜지 마세요.

`samples/golden/report_ref.pdf`는 브라우저(인쇄 기능)로 만든 기준 PDF입니다. 샘플 응답(`reply_01.json`)을 바꾸면 이 파일도 다시 만들어야 합니다.

## 필요한 것

- Python 3.11 이상, `python-docx` (`pip install python-docx`)
- PDF: PC에 Edge 또는 Chrome (이미 있으면 추가 설치 없음)
- 실제 AI 호출: Claude Code 또는 Codex CLI 로그인 상태

## 폴더

- `CRITERIA.md` 성공 기준서 (승인 후 잠금)
- `config/report_template.json` 서식 설정 (제목, 금지어, 글자 수)
- `src/report.py` 검사기와 출력 / `src/make_report.py` 진입점 / `src/pdf_tools.py` PDF
- `samples/golden` 통과해야 하는 가짜 메모 / `samples/trap` 반드시 걸려야 하는 가짜 응답
- `output/` 결과 (Git 제외)

모든 샘플은 AI가 만든 가짜 데이터입니다. 실제 메모는 `data/`에만 두세요.
