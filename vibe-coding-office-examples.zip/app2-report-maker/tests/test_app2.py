"""앱 2 하네스 테스트 (사양서 7.2 T1~T6 + Never Do + 함정 목록)

AI 호출은 전부 MockAI(가짜 응답)로 한다. 구독 사용량을 쓰지 않는다.
임시 파일은 시스템 TEMP가 아니라 output/_test_tmp 아래에 만든다.
"""
import contextlib
import hashlib
import io
import json
import os
import re
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import docx  # noqa: E402
import make_report as M  # noqa: E402
import pdf_tools  # noqa: E402
import report as R  # noqa: E402
from ai_call import BadAIResponse, MaskingNotPassed, MockAI  # noqa: E402
from verify_core import record_metric  # noqa: E402

SAMPLES = ROOT / "samples"
GOLD, TRAP = SAMPLES / "golden", SAMPLES / "trap"
TMP = ROOT / "output" / "_test_tmp"
TPL = R.load_template()
DATE = "2026-10-16"
CORE_BANNED = ["생각됨", "것 같음", "추정", "아마"]
EXPECTED_HEADINGS = ["1. 개요", "2. 추진실적", "3. 향후계획"]


def gold_pairs():
    pairs = []
    for memo in sorted(GOLD.glob("memo_*.txt")):
        reply = GOLD / memo.name.replace("memo_", "reply_").replace(".txt", ".json")
        pairs.append((memo, reply))
    return pairs


def build(memo_path, reply_path, **kw):
    memo = memo_path.read_text(encoding="utf-8")
    ai = MockAI(reply_path.read_text(encoding="utf-8"))
    return M.generate(memo, ai, date_text=DATE, **kw), ai


def trap_outcome(name, meta):
    """함정 하나를 돌려서 (상태, 상세, 가짜AI)를 돌려준다."""
    memo = (SAMPLES / meta["memo"]).read_text(encoding="utf-8")
    if meta["kind"] == "pii":
        reply = (GOLD / "reply_01.json").read_text(encoding="utf-8")
    else:
        reply = (TRAP / name).read_text(encoding="utf-8")
    ai = MockAI(reply)
    try:
        M.generate(memo, ai, date_text=DATE)
    except M.ReportRejected as e:
        return "rejected", e.result, ai
    except MaskingNotPassed as e:
        return "blocked", str(e), ai
    except BadAIResponse as e:
        return "badjson", str(e), ai
    return "accepted", None, ai


def fail_with_list(test, title, bad):
    """실패 첫 줄에 '몇 개, 어떤 파일'이 보이게 한다 (하네스 로그는 첫 줄만 보여 준다)."""
    names = ", ".join(b.split(":")[0] for b in bad)
    test.fail(f"{title}: {len(bad)}개 ({names})\n" + "\n".join(bad))


def load_expected():
    data = json.loads((TRAP / "expected.json").read_text(encoding="utf-8"))
    return {k: v for k, v in data.items() if not k.startswith("_")}


def why_wrong(name, meta, status, detail):
    """함정이 정해 둔 이유로 걸렸으면 None, 아니면 문제 설명."""
    kind, want = meta["kind"], meta["contains"]
    if kind == "pii":
        return None if status == "blocked" and want in detail else f"{status}"
    if kind == "free_text":
        return None if status == "badjson" else f"{status} (JSON 아님으로 거부되어야 함)"
    if status != "rejected":
        return f"{status} (거부되어야 함)"
    key = {"grounding": "ungrounded", "shape": "shape", "banned": "banned"}.get(kind)
    if kind == "style":
        return None if detail["endings_ratio"] < TPL["min_endings_ratio"] else "개조식 비율이 낮지 않음"
    text = json.dumps(detail.get(key, []), ensure_ascii=False)
    if not detail.get(key) or want not in text:
        return f"다른 이유로 걸림 또는 통과: {json.dumps(detail, ensure_ascii=False)[:120]}"
    return None


class App2Harness(unittest.TestCase):

    def test_T1_제목3개가_정해진_순서로_존재(self):
        for memo, reply in gold_pairs():
            out, _ = build(memo, reply)
            found = re.findall(r"^##\s+(.+?)\s*$", out["markdown"], re.M)
            self.assertEqual(found, EXPECTED_HEADINGS, f"{memo.name}: 제목이 {found}")

    def test_T2_금지어_0건(self):
        saw_exception_case = False
        for memo, reply in gold_pairs():
            out, _ = build(memo, reply)
            text = out["markdown"].replace("아마추어", "")
            saw_exception_case |= "아마추어" in out["markdown"]
            hits = [w for w in CORE_BANNED if w in text]
            self.assertEqual(hits, [], f"{memo.name}: 금지어 {hits}")
            self.assertEqual(out["result"]["banned"], [], f"{memo.name}: 검사기가 금지어로 오판 {out['result']['banned']}")
        self.assertTrue(saw_exception_case, "'아마추어'가 든 골든 샘플이 있어야 한다")

    def test_T3_메모에_없는_숫자_이름_기관은_걸러진다(self):
        bad = []
        for name, meta in load_expected().items():
            if meta["kind"] != "grounding":
                continue
            status, detail, _ = trap_outcome(name, meta)
            problem = why_wrong(name, meta, status, detail)
            if problem:
                bad.append(f"{name}: {problem}")
        if bad:
            fail_with_list(self, "근거 대조 함정이 못 걸림", bad)

    def test_T4_제목순서_자유문장_누락은_거부된다(self):
        bad = []
        for name, meta in load_expected().items():
            if meta["kind"] not in ("shape", "free_text"):
                continue
            status, detail, _ = trap_outcome(name, meta)
            problem = why_wrong(name, meta, status, detail)
            if problem:
                bad.append(f"{name}: {problem}")
        if bad:
            fail_with_list(self, "구조 함정이 못 걸림", bad)

    def test_S4_자유문장은_최대_2회_다시_요청한다(self):
        memo = (GOLD / "memo_01.txt").read_text(encoding="utf-8")
        good = (GOLD / "reply_01.json").read_text(encoding="utf-8")
        prose = (TRAP / "trap_07_free_text.txt").read_text(encoding="utf-8")
        replies = iter([prose, prose, good])
        ai = MockAI(lambda p: next(replies))
        out = M.generate(memo, ai, date_text=DATE)
        self.assertEqual(len(ai.received), 3, "자유 문장이면 두 번 다시 요청해야 함")
        self.assertTrue(out["result"]["passed"])
        always_prose = MockAI(prose)
        with self.assertRaises(BadAIResponse):
            M.generate(memo, always_prose, date_text=DATE)
        self.assertEqual(len(always_prose.received), 3, "다시 요청은 최대 2회(총 3번 호출)")

    def test_S4_검사에_걸리면_문제를_알려주고_한번만_다시_요청한다(self):
        memo = (GOLD / "memo_01.txt").read_text(encoding="utf-8")
        good = (GOLD / "reply_01.json").read_text(encoding="utf-8")
        bad = (TRAP / "trap_08_banned_word.json").read_text(encoding="utf-8")
        replies = iter([bad, good])
        ai = MockAI(lambda p: next(replies))
        out = M.generate(memo, ai, date_text=DATE)
        self.assertEqual(len(ai.received), 2)
        self.assertIn("금지어: 것 같음", ai.received[1], "두 번째 요청에 검사기가 찾은 문제가 들어 있어야 함")
        self.assertTrue(out["result"]["passed"])
        always_bad = MockAI(bad)
        with self.assertRaises(M.ReportRejected):
            M.generate(memo, always_bad, date_text=DATE)
        self.assertEqual(len(always_bad.received), 2, "내용 문제는 한 번만 다시 요청하고 거부해야 함")

    def test_T5_PDF검사기가_정상_PDF와_글꼴없는_PDF를_가려낸다(self):
        memo, reply = gold_pairs()[0]
        out, _ = build(memo, reply)
        good = pdf_tools.inspect_pdf(GOLD / "report_ref.pdf", expected_text=out["markdown"])
        self.assertEqual(pdf_tools.pdf_problems(good), [], f"기준 PDF가 불합격: {pdf_tools.pdf_problems(good)}")
        bad = pdf_tools.inspect_pdf(TRAP / "trap_12_nofont.pdf", expected_text=out["markdown"])
        problems = pdf_tools.pdf_problems(bad)
        self.assertTrue(problems, "글꼴 없는 함정 PDF가 합격으로 판정됨")
        self.assertTrue(any("글꼴" in p for p in problems), f"다른 이유로 걸림: {problems}")
        record_metric(ROOT, "기준 PDF 페이지 수", good["pages"])
        record_metric(ROOT, "기준 PDF 글꼴", ", ".join(good["fonts"])[:60])

    def test_T5_브라우저가_PDF를_직접_만들고_합격한다(self):
        if os.environ.get("REPORT_SKIP_BROWSER") == "1":
            record_metric(ROOT, "PDF 직접 생성(브라우저 실행)", "생략됨: REPORT_SKIP_BROWSER=1")
            self.skipTest("브라우저를 띄울 수 없는 환경이라 생략(리포트에 기록됨)")
        TMP.mkdir(parents=True, exist_ok=True)
        memo, reply = gold_pairs()[0]
        out, _ = build(memo, reply, out_dir=TMP / "pdf", make_pdf=True)
        info = pdf_tools.inspect_pdf(out["files"]["pdf"], expected_text=out["markdown"])
        self.assertEqual(pdf_tools.pdf_problems(info), [], f"PDF 불합격: {pdf_tools.pdf_problems(info)}")
        record_metric(ROOT, "PDF 직접 생성(브라우저 실행)", f"통과, {info['pages']}쪽")

    def test_T6_개조식_비율_90퍼센트_이상(self):
        ratios = []
        for memo, reply in gold_pairs():
            out, _ = build(memo, reply)
            ratios.append(out["result"]["endings_ratio"])
        self.assertGreaterEqual(min(ratios), 0.9, f"개조식 비율 최저 {min(ratios)}")
        record_metric(ROOT, "개조식 비율(최저)", min(ratios))
        meta = load_expected()["trap_09_prose_style.json"]
        status, detail, _ = trap_outcome("trap_09_prose_style.json", meta)
        self.assertIsNone(why_wrong("trap_09_prose_style.json", meta, status, detail), "서술체 함정이 통과함")

    def test_N1_개인정보_메모는_AI호출전에_막힌다(self):
        name = "trap_11_pii_memo.txt"
        status, detail, ai = trap_outcome(name, load_expected()[name])
        self.assertEqual(status, "blocked", "전화번호가 든 메모가 AI 호출 단계까지 갔음")
        self.assertEqual(ai.received, [], "AI가 받은 글이 있음. 호출 전에 막아야 함")

    def test_N3_원본_메모는_바뀌지_않는다(self):
        TMP.mkdir(parents=True, exist_ok=True)
        memo, reply = gold_pairs()[0]
        before = hashlib.sha256(memo.read_bytes()).hexdigest()
        with contextlib.redirect_stdout(io.StringIO()):
            code = M.main([str(memo), "--ai", f"mock:{reply}", "--out", str(TMP / "cli"), "--date", DATE])
        self.assertEqual(code, 0)
        self.assertEqual(hashlib.sha256(memo.read_bytes()).hexdigest(), before, "원본 메모가 바뀜")
        self.assertTrue((TMP / "cli" / "보고서_20261016.docx").exists())

    def test_N4_걸린_보고서는_파일로_나가지_않는다(self):
        out_dir = TMP / "rejected"
        if out_dir.exists():
            for p in out_dir.iterdir():
                p.unlink()
        memo = (GOLD / "memo_01.txt").read_text(encoding="utf-8")
        ai = MockAI((TRAP / "trap_01_invented_pct.json").read_text(encoding="utf-8"))
        with self.assertRaises(M.ReportRejected):
            M.generate(memo, ai, out_dir=out_dir, date_text=DATE)
        self.assertEqual(list(out_dir.glob("*")) if out_dir.exists() else [], [], "거부된 보고서가 파일로 나갔음")

    def test_S7_DOCX_제목과_항목수가_일치(self):
        memo, reply = gold_pairs()[0]
        out, _ = build(memo, reply, out_dir=TMP / "docx")
        doc = docx.Document(str(out["files"]["docx"]))
        heads = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading")]
        self.assertEqual(heads[-3:], EXPECTED_HEADINGS, f"DOCX 제목 {heads}")
        bullets = [p.text for p in doc.paragraphs if p.style.name == "List Bullet"]
        total = sum(len(v) for v in out["data"].values())
        self.assertEqual(len(bullets), total, "DOCX 항목 수가 다름")

    def test_N5_설정으로_검사를_느슨하게_하지_않았다(self):
        self.assertEqual(TPL["sections"], ["개요", "추진실적", "향후계획"])
        for w in ("생각됨", "것 같음", "추정"):
            self.assertIn(w, TPL["banned_words"], f"금지어 '{w}'가 설정에서 빠짐")
        self.assertGreaterEqual(TPL["min_endings_ratio"], 0.9)
        self.assertLessEqual(TPL["max_memo_chars"], 10000)
        for ex in TPL.get("banned_exceptions", []):
            self.assertFalse(any(w in ex for w in ("생각됨", "것 같음")), f"예외 목록이 핵심 금지어를 가림: {ex}")

    def test_H1_함정은_정해_둔_이유로_걸린다(self):
        bad, caught = [], 0
        expected = load_expected()
        for name, meta in expected.items():
            status, detail, _ = trap_outcome(name, meta)
            problem = why_wrong(name, meta, status, detail)
            if problem:
                bad.append(f"{name}: {problem}")
            else:
                caught += 1
        record_metric(ROOT, "함정 샘플 중 정해진 이유로 걸린 수", f"{caught}/{len(expected)}")
        if bad:
            fail_with_list(self, "함정이 엉뚱하게 통과하거나 다른 이유로 걸림", bad)
        self.assertGreaterEqual(len(expected), 3, "함정 샘플은 최소 3개")


if __name__ == "__main__":
    unittest.main()
