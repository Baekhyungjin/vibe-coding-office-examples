"""AI 호출 창구 (모든 앱이 AI를 부를 때 이 파일 하나만 쓴다)

하는 일
  1. 보낼 글을 잔여 검사(residual_scan)에 통과시킨다. 개인정보가 보이면 호출 자체를 막는다.
  2. 내 PC의 구독 CLI(claude -p 또는 codex exec)를 부른다.  (모드 B)
  3. 응답에서 JSON을 꺼내 간단한 스키마 검사를 한다.
테스트할 때는 MockAI(가짜 응답)를 끼워 넣어 구독 사용량을 쓰지 않는다.
"""
import json
import re
import shutil
import subprocess

from masking import residual_scan


class MaskingNotPassed(Exception):
    """마스킹 검사를 통과하지 못한 글을 AI에 보내려 할 때"""


class BadAIResponse(Exception):
    """AI 응답이 약속한 JSON 형식이 아닐 때"""


class MockAI:
    """테스트용 가짜 AI. 정해 둔 응답을 돌려주고, 받은 글을 기록한다."""

    def __init__(self, reply):
        self.reply = reply          # 문자열 또는 함수(prompt -> 문자열)
        self.received = []

    def __call__(self, prompt):
        self.received.append(prompt)
        return self.reply(prompt) if callable(self.reply) else self.reply


def cli_backend(tool="claude", timeout=180):
    """구독 CLI를 부르는 함수를 만든다. [확인 필요: 독자 환경에서 실제 호출 확인]"""
    commands = {"claude": ["claude", "-p"], "codex": ["codex", "exec"]}
    if tool not in commands:
        raise ValueError("tool 은 claude 또는 codex 만 됩니다")
    if shutil.which(commands[tool][0]) is None:
        raise RuntimeError(f"{tool} 명령을 찾을 수 없습니다. Ch 0 설치를 먼저 확인하세요.")

    def run(prompt):
        done = subprocess.run(commands[tool] + [prompt], capture_output=True,
                              text=True, encoding="utf-8", timeout=timeout)
        if done.returncode != 0:
            raise RuntimeError(f"{tool} 호출 실패: {done.stderr.strip()[:200]}")
        return done.stdout
    return run


def extract_json(text):
    """응답 속 첫 번째 {...} 덩어리를 JSON으로 읽는다."""
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise BadAIResponse("응답에 JSON이 없습니다")
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError as e:
        raise BadAIResponse(f"JSON 읽기 실패: {e}") from e


def check_schema(data, schema):
    """schema 예: {"required": {"category": str, "draft": str},
                    "enum": {"category": ["배송", "환불"]}}"""
    for key, typ in schema.get("required", {}).items():
        if key not in data:
            raise BadAIResponse(f"필수 항목 없음: {key}")
        if not isinstance(data[key], typ):
            raise BadAIResponse(f"{key} 형식이 {typ.__name__} 이 아닙니다")
    for key, allowed in schema.get("enum", {}).items():
        if key in data and data[key] not in allowed:
            raise BadAIResponse(f"{key} 값 '{data[key]}' 은 허용 목록에 없습니다")
    return data


def call_ai(prompt, backend, schema=None, roster=None, retries=2):
    leftovers = residual_scan(prompt, roster)
    if leftovers:
        kinds = sorted({f["type"] for f in leftovers})
        raise MaskingNotPassed(f"개인정보로 보이는 값이 남아 있어 AI 호출을 막았습니다: {kinds}")
    last_error = None
    for _ in range(retries + 1):
        try:
            data = extract_json(backend(prompt))
            return check_schema(data, schema or {})
        except BadAIResponse as e:
            last_error = e
    raise last_error
