"""앱 2 진입점: 메모 -> AI -> 검사 -> 보고서 파일

    python src/make_report.py 메모.txt --ai claude --pdf
    python src/make_report.py 메모.txt --ai mock:응답.json      # AI 없이 체험

검사에 걸리면 보고서 파일을 만들지 않고 문제 목록만 보여 준다.
"""
import argparse
import datetime
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import report as R  # noqa: E402
from ai_call import BadAIResponse, MaskingNotPassed, MockAI, call_ai, cli_backend  # noqa: E402


def describe(result):
    lines = []
    for p in result.get("shape", []):
        lines.append(f"모양: {p}")
    for p in result.get("structure", []):
        lines.append(f"제목: {p}")
    for w in result.get("banned", []):
        lines.append(f"금지어: {w}")
    for u in result.get("ungrounded", []):
        lines.append(f"메모에 없는 {u['종류']} '{u['값']}': {u['문장']}")
    if "endings_ratio" in result and result["endings_ratio"] < 0.9:
        lines.append(f"개조식 비율 부족: {result['endings_ratio']}")
    return "\n".join(lines) or "검사 실패"


class ReportRejected(Exception):
    """검사기가 보고서를 거부했을 때. result 에 이유가 들어 있다."""

    def __init__(self, result, data=None):
        self.result = result
        self.data = data
        super().__init__(describe(result))


def _feedback(prompt, result):
    return (prompt + "\n\n[검사기가 찾은 문제]\n" + describe(result)
            + "\n위 문제를 고쳐서 JSON 하나만 다시 출력하라.")


def generate(memo, backend, out_dir=None, tpl=None, date_text="", make_pdf=False,
             fix_rounds=1, roster=None):
    """보고서를 만든다. 검사를 통과하지 못하면 ReportRejected."""
    tpl = tpl or R.load_template()
    if len(memo) > tpl["max_memo_chars"]:
        raise ValueError(f"메모가 {tpl['max_memo_chars']}자를 넘습니다 ({len(memo)}자). 나눠서 넣어 주세요.")
    date_text = date_text or datetime.date.today().isoformat()
    prompt = R.build_prompt(memo, tpl)
    result, data = None, None
    for _ in range(fix_rounds + 1):
        data = call_ai(prompt, backend, roster=roster)
        result = R.inspect(memo, data, tpl)
        if result["passed"]:
            break
        prompt = _feedback(R.build_prompt(memo, tpl), result)
    if not result["passed"]:
        raise ReportRejected(result, data)

    markdown = R.render_markdown(data, tpl, date_text=date_text)
    html_text = R.render_html(data, tpl, date_text=date_text)
    files = {}
    if out_dir:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = "보고서_" + date_text.replace("-", "")
        (out_dir / f"{stem}.md").write_text(markdown, encoding="utf-8")
        (out_dir / f"{stem}.html").write_text(html_text, encoding="utf-8")
        files["md"], files["html"] = out_dir / f"{stem}.md", out_dir / f"{stem}.html"
        files["docx"] = R.write_docx(data, tpl, out_dir / f"{stem}.docx", date_text=date_text)
        if make_pdf:
            from pdf_tools import html_to_pdf
            files["pdf"] = html_to_pdf(files["html"], out_dir / f"{stem}.pdf", work_dir=out_dir)
    return {"data": data, "markdown": markdown, "html": html_text,
            "result": result, "files": files}


def main(argv=None):
    ap = argparse.ArgumentParser(description="메모를 사내 서식 보고서로 바꿉니다.")
    ap.add_argument("memo", help="메모 파일(.txt/.md)")
    ap.add_argument("--ai", default="claude", help="claude | codex | mock:응답파일.json")
    ap.add_argument("--out", default=str(HERE.parent / "output"))
    ap.add_argument("--date", default="")
    ap.add_argument("--pdf", action="store_true")
    args = ap.parse_args(argv)

    memo = Path(args.memo).read_text(encoding="utf-8")
    if args.ai.startswith("mock:"):
        backend = MockAI(Path(args.ai[5:]).read_text(encoding="utf-8"))
    else:
        backend = cli_backend(args.ai)
    try:
        out = generate(memo, backend, out_dir=args.out, date_text=args.date, make_pdf=args.pdf)
    except MaskingNotPassed as e:
        print(f"중단: {e}\n메모에서 개인정보를 먼저 지워 주세요. AI에는 아무것도 보내지 않았습니다.")
        return 1
    except BadAIResponse as e:
        print(f"중단: AI 응답이 약속한 형식이 아닙니다. ({e})")
        return 1
    except ReportRejected as e:
        print("검사에 걸려 보고서를 만들지 않았습니다. 문제 목록:")
        print(e)
        return 1
    print("보고서를 만들었습니다.")
    for kind, path in out["files"].items():
        try:
            shown = Path(path).resolve().relative_to(HERE.parent)
        except ValueError:
            shown = path
        print(f"  {kind}: {shown}")
    return 0


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    sys.exit(main())
