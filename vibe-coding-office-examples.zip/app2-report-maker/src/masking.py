"""개인정보 마스킹 모듈 (로컬 전용, 표준 라이브러리만 사용)

원칙: 로컬 마스킹이 먼저, AI는 그다음.
이 모듈을 통과한 글만 ai_call.py 가 AI에게 보낸다.

치환 규칙 (사양서 7.3 FR1)
  전화번호 -> [전화]      주민/외국인등록번호 -> [주민번호]
  이메일   -> [이메일]    계좌번호 -> [계좌]      카드번호 -> [카드]
  이름     -> [고객A], [고객B] ... (한 번 정한 가명은 끝까지 같게)
  주소     -> [주소]
"""
import re

# ---------------------------------------------------------------- 패턴
PHONE = re.compile(r"(?<!\d)(?:\+82[-.\s]?1[016789]|01[016789]|0\d{1,2})[-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)")

RRN = re.compile(r"(?<!\d)(\d{2})(\d{2})(\d{2})[-\s]?([1-8])(\d{6})(?!\d)")
# 바코드(880...), 주문번호처럼 13자리 숫자가 주민번호 모양을 띠는 경우를 앞 단어로 구별한다
NOT_RRN_CONTEXT = re.compile(r"(바코드|상품코드|주문번호|운송장|송장|코드|번호표)\s*[:：]?\s*$")

EMAIL = re.compile(r"[A-Za-z0-9._%+-]+\s?@\s?[A-Za-z0-9.-]+\.[A-Za-z]{2,}")

CARD = re.compile(r"(?<!\d)\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}(?!\d)")

BANK_WORDS = ("국민은행|신한은행|우리은행|하나은행|농협은행|농협|기업은행|카카오뱅크|토스뱅크|"
              "케이뱅크|새마을금고|우체국|수협|SC제일은행|부산은행|대구은행|국민|신한|우리|하나")
ACCOUNT = re.compile(r"(" + BANK_WORDS + r")(\s*(?:계좌)?\s*[:：]?\s*)(\d[\d-]{8,18}\d)")

SIDO = ("서울특별시|서울|부산광역시|부산|대구광역시|대구|인천광역시|인천|광주광역시|광주|대전광역시|대전|"
        "울산광역시|울산|세종특별자치시|세종|경기도|경기|강원특별자치도|강원도|강원|충청북도|충북|충청남도|충남|"
        "전북특별자치도|전라북도|전북|전라남도|전남|경상북도|경북|경상남도|경남|제주특별자치도|제주")
ADDRESS = re.compile(
    r"(?:" + SIDO + r")\s+(?:[가-힣]+(?:시|군|구)\s+){1,2}[가-힣0-9]+(?:로|길)"
    r"(?:\s*\d+(?:번?길)?)?(?:\s*\d+(?:-\d+)?)?(?:\s*,?\s*\d+동)?(?:\s*,?\s*\d+호)?")

SURNAMES = set("김이박최정강조윤장임한오서신권황안송류홍전고문양손배백허유남심노하곽성차주우구민진나지엄채원천방공현함변염여추도소석선설마길연위표명기반왕금옥육인맹제모탁국어은편용")
NOT_NAMES = {"고객", "고객님", "담당자", "기사", "사장", "선생", "팀장", "상담사", "상담원", "회원",
             "여러분", "관리자", "직원", "본인", "주문자", "예금주", "책임자", "고객센터", "매니저"}
# 호칭/문맥으로 명단에 없는 이름을 찾는 패턴
NAME_CONTEXT = [
    re.compile(r"(?<![가-힣])([가-힣]{2,4})\s?(?:고객님|고객|님|씨)"),
    re.compile(r"저는\s?([가-힣]{2,4})(?:입니다|이라고|라고)"),
    re.compile(r"(?<![가-힣])([가-힣]{2,4})\s?(?:드림|올림)"),
    re.compile(r"(?m)^([가-힣]{2,4})입니다"),
    # 가족/지인 호칭 뒤에 호칭 없이 붙은 이름 (예: 동생 OOO이가, 남편이 OOO이라서)
    re.compile(r"(?:동생|남편이?|아내가?|엄마|아빠|아들|딸|친구|언니|오빠|누나|형)\s([가-힣]{3})(?:이가|이라서|이랑|이는|이)"),
]


def luhn_ok(digits):
    total = 0
    for i, d in enumerate(reversed(digits)):
        n = int(d)
        if i % 2 == 1:
            n = n * 2 - 9 if n > 4 else n * 2
        total += n
    return total % 10 == 0


def valid_birth(yy, mm, dd):
    return 1 <= int(mm) <= 12 and 1 <= int(dd) <= 31


def looks_like_name(word):
    return (2 <= len(word) <= 4 and word[0] in SURNAMES and word not in NOT_NAMES
            and not any(word.startswith(n) for n in NOT_NAMES))


class Masker:
    """메일 여러 개를 처리하는 동안 같은 사람에게 같은 가명을 준다."""

    def __init__(self, roster=None):
        self.roster = sorted(set(roster or []), key=len, reverse=True)
        self.alias = {}          # 실명 -> [고객A]
        self.counts = {}         # 종류별 마스킹 건수(마지막 처리 글 기준)
        self.mapping_rows = []   # 대응표 (주민번호는 저장하지 않음)

    def _alias_for(self, name):
        if name not in self.alias:
            n = len(self.alias)
            label = ""
            while True:
                label = chr(ord("A") + n % 26) + label
                n = n // 26 - 1
                if n < 0:
                    break
            self.alias[name] = f"[고객{label}]"
            self.mapping_rows.append({"실명": name, "가명": self.alias[name]})
        return self.alias[name]

    def _sub(self, pattern, text, kind, repl):
        def wrap(m):
            out = repl(m)
            if out != m.group(0):
                self.counts[kind] = self.counts.get(kind, 0) + 1
            return out
        return pattern.sub(wrap, text)

    def mask(self, text):
        self.counts = {}
        # 1) 주민/외국인등록번호: 생년월일이 말이 될 때만
        text = self._sub(RRN, text, "주민번호",
                         lambda m: "[주민번호]" if valid_birth(m.group(1), m.group(2), m.group(3))
                         and not NOT_RRN_CONTEXT.search(text[max(0, m.start() - 12):m.start()]) else m.group(0))
        # 2) 카드: 16자리 + Luhn 검사
        text = self._sub(CARD, text, "카드",
                         lambda m: "[카드]" if luhn_ok(re.sub(r"\D", "", m.group(0))) else m.group(0))
        # 3) 계좌: 은행 이름 바로 뒤의 숫자만
        text = self._sub(ACCOUNT, text, "계좌", lambda m: m.group(1) + m.group(2) + "[계좌]")
        # 4) 이메일
        text = self._sub(EMAIL, text, "이메일", lambda m: "[이메일]")
        # 5) 전화번호
        text = self._sub(PHONE, text, "전화", lambda m: "[전화]")
        # 6) 주소
        text = self._sub(ADDRESS, text, "주소", lambda m: "[주소]")
        # 7) 이름: 명단 대조 먼저, 그다음 호칭/문맥 패턴
        for name in self.roster:
            if name in text:
                self.counts["이름"] = self.counts.get("이름", 0) + text.count(name)
                text = text.replace(name, self._alias_for(name))
        for pat in NAME_CONTEXT:
            for m in list(pat.finditer(text)):
                word = m.group(1)
                if looks_like_name(word) and word in text:
                    self.counts["이름"] = self.counts.get("이름", 0) + text.count(word)
                    text = text.replace(word, self._alias_for(word))
        return text


# ---------------------------------------------------------------- 잔여 검사
RESIDUAL_PATTERNS = {
    "전화": re.compile(r"(?<!\d)(?:\+82[-.\s]?1[016789]|01[016789]|0\d{1,2})[-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)"),
    "주민번호": re.compile(r"(?<!\d)\d{6}[-\s]?[1-8]\d{6}(?!\d)"),
    "이메일": re.compile(r"[A-Za-z0-9._%+-]+\s?(?:@|\(at\)|\[at\])\s?[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "카드": re.compile(r"(?<!\d)\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}(?!\d)"),
    "계좌": re.compile(r"(?:" + BANK_WORDS + r")\s*(?:계좌)?\s*[:：]?\s*\d[\d-]{8,18}\d"),
}


def residual_scan(text, roster=None):
    """마스킹이 끝난 글에 개인정보처럼 보이는 것이 남았는지 찾는다.
    하나라도 나오면 그 글은 AI로 보내지 않고 '사람 확인 필요'로 돌린다."""
    found = []
    for kind, pat in RESIDUAL_PATTERNS.items():
        for m in pat.finditer(text):
            value = m.group(0)
            if kind == "주민번호" and not valid_birth(value[:2], value[2:4], value[4:6]):
                continue
            if kind == "카드" and not luhn_ok(re.sub(r"\D", "", value)):
                continue
            found.append({"type": kind, "value": value})
    for name in roster or []:
        if name and name in text:
            found.append({"type": "이름", "value": name})
    return found
