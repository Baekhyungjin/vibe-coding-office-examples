"""앱 2: 사내 서식 보고서 자동 생성기 (핵심 로직)

흐름: 메모 -> (마스킹 검사) -> AI(모드 B)에게 JSON 요청 -> 형식 검사
      -> 검사기 3종(제목 구조, 금지어, 근거 대조) + 문체 비율 -> Markdown/HTML -> DOCX/PDF
AI는 '정리'만 한다. 합격 여부는 이 파일의 검사기가 정한다.
"""
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_template(path=None):
    path = Path(path) if path else ROOT / "config" / "report_template.json"
    return json.loads(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- AI 요청
def build_prompt(memo, tpl):
    keys = ", ".join(f'"{s}"' for s in tpl["sections"])
    return (
        "아래 업무 메모를 사내 보고서용으로 정리하라.\n"
        f"반드시 JSON 하나만 출력한다. 키는 정확히 {keys} 이고 순서도 같다.\n"
        "각 값은 문자열 목록이다. 문장은 개조식(~함, ~임, ~예정)으로 끝낸다.\n"
        "메모에 없는 숫자, 날짜, 이름, 기관명은 절대 쓰지 않는다. 모르면 쓰지 않는다.\n"
        f"추측 표현({', '.join(tpl['banned_words'][:6])} 등)은 쓰지 않는다.\n"
        "--- 메모 시작 ---\n" + memo + "\n--- 메모 끝 ---"
    )


def validate_shape(data, tpl):
    """AI 응답 JSON의 모양 검사. 문제가 있으면 문제 목록을 돌려준다."""
    problems = []
    if not isinstance(data, dict):
        return ["응답이 JSON 객체가 아님"]
    keys = list(data.keys())
    for k in keys:
        if k not in tpl["sections"]:
            problems.append(f"허용되지 않은 제목: {k}")
    if set(keys) == set(tpl["sections"]) and keys != tpl["sections"]:
        problems.append(f"제목 순서가 다름: 기대 {tpl['sections']}, 실제 {keys}")
    for s in tpl["sections"]:
        if s not in data:
            problems.append(f"필수 제목 없음: {s}")
        elif not isinstance(data[s], list) or not all(isinstance(x, str) for x in data[s]):
            problems.append(f"{s} 값이 문자열 목록이 아님")
        elif not data[s]:
            problems.append(f"{s} 항목이 비어 있음")
        elif len(data[s]) > tpl["max_bullets_per_section"]:
            problems.append(f"{s} 항목 수 초과: {len(data[s])}")
    for s in tpl["sections"]:
        for line in data.get(s, []) if isinstance(data.get(s), list) else []:
            if isinstance(line, str) and len(line) > tpl["max_bullet_chars"]:
                problems.append(f"글자 수 초과({len(line)}자): {line[:20]}...")
    return problems


# ---------------------------------------------------------------- 검사기
def all_lines(data, tpl):
    return [line for s in tpl["sections"] for line in data.get(s, [])]


def check_structure(markdown, tpl):
    """Markdown 안의 '## n. 제목' 줄이 정해진 순서로 정확히 있는지 본다."""
    found = re.findall(r"^##\s+(.+?)\s*$", markdown, re.M)
    expected = [tpl["section_heading_format"].format(n=i + 1, name=s) for i, s in enumerate(tpl["sections"])]
    if found != expected:
        return [f"제목 구조 불일치: 기대 {expected}, 실제 {found}"]
    return []


def check_banned(text, tpl):
    # '아마추어'처럼 금지어 글자가 우연히 들어 있는 낱말은 설정의 예외 목록으로 먼저 지운다
    for ok in tpl.get("banned_exceptions", []):
        text = text.replace(ok, "")
    return [w for w in tpl["banned_words"] if w.replace("~", "") in text]


def _squash(text):
    return re.sub(r"[\s,]", "", text)


NUM_RE = re.compile(r"(\d[\d,]*(?:\.\d+)?)(\s*%)?")


def _num_key(text):
    """'1,200' -> '1200'. 쉼표와 끝의 콤마를 지운 비교용 숫자."""
    return text.replace(",", "")


def memo_numbers(memo):
    """메모에 '통째로' 적힌 숫자 모음과, % 달린 숫자 모음. 412 안의 '41'은 숫자 41이 아니다."""
    nums, pcts = set(), set()
    for m in NUM_RE.finditer(memo):
        (pcts if m.group(2) else nums).add(_num_key(m.group(1)))
        nums.add(_num_key(m.group(1)))
    return nums, pcts


def extract_claims(line, tpl):
    """한 줄에서 '메모에 있어야 하는 것'(숫자, 영문 약어, 기관명, 사람 이름)을 뽑는다.
    반환: (종류, 화면에 보일 값, 비교 방식, 비교용 값)"""
    claims = []
    for m in NUM_RE.finditer(line):
        key = _num_key(m.group(1))
        claims.append(("숫자", m.group(0).strip(), "pct" if m.group(2) else "num", key))
    for m in re.finditer(r"[A-Za-z][A-Za-z0-9&\-]+", line):
        claims.append(("영문", m.group(0), "text", m.group(0)))
    suf = "|".join(map(re.escape, tpl["proper_noun_suffixes"]))
    for m in re.finditer(rf"([가-힣]{{2,}}(?:{suf}))(?=[\s,.)이가은는을를의에와과도로]|$)", line):
        claims.append(("기관", m.group(1), "text", m.group(1)))
    sur, titles = tpl.get("person_surnames", ""), tpl.get("person_titles", [])
    if sur and titles:
        tit = "|".join(map(re.escape, titles))
        # 이름은 '성 + 두 글자' + 직함 형태만 본다. 동사 끝(정리해 등)은 이름이 아니다.
        for m in re.finditer(rf"(?<![가-힣])([{sur}][가-힣]{{2}})\s?(?:{tit})", line):
            if m.group(1)[-1] not in tpl.get("person_not_last_chars", ""):
                claims.append(("이름", m.group(1), "text", m.group(1)))
    return claims


def check_grounding(memo, data, tpl):
    """보고서의 숫자/약어/기관명/이름이 메모에 실제로 있는지 대조한다.
    존재만 본다. 자리가 맞는지(의미)는 사람이 본다."""
    memo_sq = _squash(memo)
    nums, pcts = memo_numbers(memo)
    missing = []
    for line in all_lines(data, tpl):
        for kind, shown, how, key in extract_claims(line, tpl):
            if how == "num":
                found = key in nums
            elif how == "pct":
                found = key in pcts
            else:
                found = _squash(key) in memo_sq
            if not found:
                missing.append({"종류": kind, "값": shown, "문장": line})
    return missing


def endings_ratio(data, tpl):
    lines = all_lines(data, tpl)
    if not lines:
        return 0.0
    ok = 0
    for line in lines:
        tail = re.sub(r"[\s.)\]]+$", "", line)
        if any(tail.endswith(e) for e in tpl["allowed_endings"]):
            ok += 1
    return ok / len(lines)


def inspect(memo, data, tpl, markdown=None):
    """검사 결과를 한 번에 돌려준다. passed 가 False 면 보고서를 내보내지 않는다."""
    shape = validate_shape(data, tpl)
    if shape:
        return {"passed": False, "shape": shape}
    markdown = markdown or render_markdown(data, tpl)
    result = {
        "shape": [],
        "structure": check_structure(markdown, tpl),
        "banned": check_banned("\n".join(all_lines(data, tpl)), tpl),
        "ungrounded": check_grounding(memo, data, tpl),
        "endings_ratio": round(endings_ratio(data, tpl), 3),
    }
    result["passed"] = (not result["structure"] and not result["banned"]
                        and not result["ungrounded"]
                        and result["endings_ratio"] >= tpl["min_endings_ratio"])
    return result


# ---------------------------------------------------------------- 출력
def render_markdown(data, tpl, title=None, date_text=""):
    title = title or tpl["report_title"]
    out = [f"# {title}", ""]
    if date_text:
        out += [f"작성일: {date_text}", ""]
    for i, s in enumerate(tpl["sections"]):
        out.append("## " + tpl["section_heading_format"].format(n=i + 1, name=s))
        out += [f"- {line}" for line in data[s]]
        out.append("")
    return "\n".join(out)


def render_html(data, tpl, title=None, date_text=""):
    title = title or tpl["report_title"]
    parts = [f"<h1>{html.escape(title)}</h1>"]
    if date_text:
        parts.append(f'<p class="date">작성일: {html.escape(date_text)}</p>')
    for i, s in enumerate(tpl["sections"]):
        head = tpl["section_heading_format"].format(n=i + 1, name=s)
        items = "".join(f"<li>{html.escape(x)}</li>" for x in data[s])
        parts.append(f"<h2>{html.escape(head)}</h2><ul>{items}</ul>")
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
@page {{ size: A4; margin: 20mm 18mm; }}
body {{ font-family: {tpl['font_family']}; font-size: 11pt; line-height: 1.6; color: #111; }}
h1 {{ font-size: 18pt; border-bottom: 2px solid #222; padding-bottom: 6px; }}
h2 {{ font-size: 13pt; margin-top: 18px; }}
.date {{ color: #555; }}
li {{ margin: 3px 0; }}
</style></head><body>{''.join(parts)}</body></html>"""


def write_docx(data, tpl, path, title=None, date_text=""):
    from docx import Document
    from docx.oxml.ns import qn
    from docx.shared import Pt

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Malgun Gothic"
    style.font.size = Pt(11)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "맑은 고딕")
    doc.add_heading(title or tpl["report_title"], level=0)
    if date_text:
        doc.add_paragraph(f"작성일: {date_text}")
    for i, s in enumerate(tpl["sections"]):
        doc.add_heading(tpl["section_heading_format"].format(n=i + 1, name=s), level=1)
        for line in data[s]:
            doc.add_paragraph(line, style="List Bullet")
    doc.save(str(path))
    return Path(path)
