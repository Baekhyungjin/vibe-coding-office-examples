"""PDF 만들기와 검사하기 (추가 설치 없이)

만들기: PC에 이미 있는 Edge 또는 Chrome의 '헤드리스 인쇄' 기능으로 HTML을 PDF로 저장한다.
검사하기: 표준 라이브러리(zlib)로 PDF 안을 열어
  - 페이지 수
  - 글꼴이 파일 안에 들어 있는지(내장 여부)
  - 글자 대응표(ToUnicode)에 보고서의 한글이 모두 있는지(깨짐 여부)
를 확인한다. 정밀한 PDF 분석기는 아니며, 이 앱이 만든 PDF를 검사하는 용도다.
"""
import os
import re
import shutil
import subprocess
import zlib
from pathlib import Path

CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]


def find_browser():
    env = os.environ.get("REPORT_BROWSER")
    if env and Path(env).exists():
        return env
    for c in CANDIDATES:
        if Path(c).exists():
            return c
    for name in ("msedge", "google-chrome", "chromium", "chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None


def html_to_pdf(html_path, pdf_path, work_dir, timeout=90):
    """브라우저 헤드리스 인쇄로 PDF를 만든다. 실패하면 RuntimeError."""
    browser = find_browser()
    if not browser:
        raise RuntimeError("Edge/Chrome을 찾지 못했습니다. HTML 파일을 브라우저로 열어 'PDF로 저장'하세요.")
    html_path, pdf_path = Path(html_path).resolve(), Path(pdf_path).resolve()
    profile = Path(work_dir).resolve() / "_browser_profile"
    profile.mkdir(parents=True, exist_ok=True)
    if pdf_path.exists():
        pdf_path.unlink()
    cmd = [browser, "--headless", "--disable-gpu", "--no-first-run",
           "--no-pdf-header-footer", f"--user-data-dir={profile}",
           f"--print-to-pdf={pdf_path}", html_path.as_uri()]
    # Edge가 내놓는 메시지를 한글 윈도우 기본 인코딩(cp949)으로 읽다 실패하지 않도록 utf-8로 읽는다
    done = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout)
    if not pdf_path.exists() or pdf_path.stat().st_size == 0:
        raise RuntimeError(f"PDF 생성 실패 (종료 코드 {done.returncode}): {(done.stderr or '').strip()[:300]}")
    return pdf_path


# ---------------------------------------------------------------- 검사
def _streams(raw):
    for m in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", raw, re.S):
        body = m.group(1)
        try:
            yield zlib.decompress(body)
        except zlib.error:
            yield body


def pdf_page_count(raw):
    return len(re.findall(rb"/Type\s*/Page(?![s\w])", raw))


def pdf_font_names(raw):
    return sorted({n.decode("latin-1") for n in re.findall(rb"/BaseFont\s*/([^\s/<>\[\]]+)", raw)})


def pdf_has_embedded_font(raw):
    return bool(re.search(rb"/FontFile[23]?\b", raw))


def pdf_mapped_chars(raw):
    """ToUnicode 대응표에 적힌 글자 모음. 여기에 없는 글자는 복사/검색 시 깨진다."""
    chars = set()
    for s in _streams(raw):
        if b"begincmap" not in s:
            continue
        text = s.decode("latin-1")
        for block in re.findall(r"beginbfchar(.*?)endbfchar", text, re.S):
            for _src, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block):
                chars.update(_hex_to_text(dst))
        for block in re.findall(r"beginbfrange(.*?)endbfrange", text, re.S):
            for lo, hi, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", block):
                start = int(dst, 16)
                for i in range(int(hi, 16) - int(lo, 16) + 1):
                    try:
                        chars.add(chr(start + i))
                    except ValueError:
                        pass
    return chars


def _hex_to_text(h):
    try:
        return bytes.fromhex(h).decode("utf-16-be")
    except (ValueError, UnicodeDecodeError):
        return ""


def pdf_problems(info):
    """inspect_pdf 결과를 합격/불합격 문제 목록으로 바꾼다. 빈 목록이면 합격."""
    problems = []
    if not info["is_pdf"]:
        problems.append("PDF 파일이 아님")
    if info["pages"] < 1:
        problems.append("페이지 수 0")
    if not info["embedded_font"]:
        problems.append("글꼴이 파일에 내장되지 않음")
    if info["hangul_missing"]:
        problems.append(f"글자 대응표에 없는 한글 {len(info['hangul_missing'])}자")
    return problems


def inspect_pdf(pdf_path, expected_text=""):
    raw = Path(pdf_path).read_bytes()
    mapped = pdf_mapped_chars(raw)
    hangul = sorted({c for c in expected_text if "\uac00" <= c <= "\ud7a3"})
    missing = [c for c in hangul if c not in mapped]
    return {
        "bytes": len(raw),
        "is_pdf": raw[:5] == b"%PDF-",
        "pages": pdf_page_count(raw),
        "fonts": pdf_font_names(raw),
        "embedded_font": pdf_has_embedded_font(raw),
        "hangul_expected": len(hangul),
        "hangul_missing": missing,
    }
