"""가짜 메모와 가짜 AI 응답을 만든다 (모든 내용은 지어낸 것, 실존 인물/회사 없음)

    python scripts/make_samples.py

golden: 통과해야 하는 메모 + 기대 응답
trap  : 반드시 걸려야 하는 응답. 걸리는 이유는 expected.json 에 적는다.
"""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GOLD, TRAP = ROOT / "samples" / "golden", ROOT / "samples" / "trap"

MEMOS = {
    "memo_01": """[주간 메모] 기획팀 박 주임 / 10월 12일~16일
- 고객 설문 3차 조사 마감. 응답 412건 회수, 목표 400건 달성
- 온다유통 담당자와 10월 14일 미팅. 재계약 조건으로 단가 3% 인하를 요청받음. 결론은 아직 미정
- 사내 포털 개편안 초안 작성 끝, 디자인팀에 검토 요청
- 11월 첫째 주까지 설문 결과 분석 보고서 작성할 계획
- 예산 1,200만 원 중 780만 원 집행
- 다음 주 월요일에 팀장 보고 필요
""",
    "memo_02": """기획팀 박 주임 주간 메모 (10월 5일~9일)
- 고객센터 응대 매뉴얼 개정 2차 회의 진행. 참석 7명
- 개정안 12개 항목 중 9개 합의, 3개는 다음 회의에서 재논의
- 외부 컨설팅 견적 두 곳 수령. 하늘컨설팅 850만 원, 모아컨설팅 920만 원
- 견적 비교표는 10월 13일까지 정리해서 팀장에게 공유
- 교육 일정은 확정 전. 인사팀과 협의 필요
""",
    "memo_03": """기획팀 박 주임 메모 / 10월 19일 주
- 가을 고객 초청 행사 장소 확정: 한울센터 3층 대강당, 수용 인원 150명
- 초청 대상 320명 중 수락 회신 118명, 미회신 고객은 10월 21일에 전화 안내 예정
- 현수막과 안내 책자는 새솔인쇄에 의뢰, 납품일은 10월 25일
- 행사 당일 진행 인력 부족. 총무팀에 5명 지원 요청
- 경품 예산은 아직 미정
""",
    "memo_04": """기획팀 박 주임 / 10월 26일~30일 메모
- 사내 아마추어 사진전 후원 문의가 들어옴. 후원 금액은 협의 필요
- 사보 11월호 원고 마감은 10월 30일. 현재 원고 8편 중 6편 수령
- 신규 입사자 환영 키트 구성안 검토 중
- 연말 시무식 일정은 12월 첫째 주로 가안, 확정되지 않음
""",
}

REPLIES = {
    "reply_01": {
        "개요": ["10월 12일~16일 주간 업무 현황 정리함",
                 "설문 조사 마감, 재계약 협의, 포털 개편안 초안 작성이 주요 내용임"],
        "추진실적": ["고객 설문 3차 조사 마감, 응답 412건 회수로 목표 400건 달성함",
                     "온다유통 담당자와 10월 14일 미팅, 단가 3% 인하 요청 접수함",
                     "재계약 결론은 미정임",
                     "사내 포털 개편안 초안 작성 완료, 디자인팀에 검토 요청함",
                     "예산 1,200만 원 중 780만 원 집행함"],
        "향후계획": ["11월 첫째 주까지 설문 결과 분석 보고서 작성 예정함",
                     "다음 주 월요일 팀장 보고 필요함"],
    },
    "reply_02": {
        "개요": ["10월 5일~9일 고객센터 응대 매뉴얼 개정 업무 정리함"],
        "추진실적": ["매뉴얼 개정 2차 회의 진행, 참석 7명임",
                     "개정안 12개 항목 중 9개 합의함, 3개는 재논의 예정",
                     "외부 컨설팅 견적 두 곳 수령함, 하늘컨설팅 850만 원과 모아컨설팅 920만 원임"],
        "향후계획": ["견적 비교표 10월 13일까지 정리해 팀장에게 공유 예정함",
                     "교육 일정은 확정 전이며 인사팀과 협의 필요함"],
    },
    "reply_03": {
        "개요": ["10월 19일 주 가을 고객 초청 행사 준비 현황 정리함"],
        "추진실적": ["행사 장소를 한울센터 3층 대강당으로 확정함, 수용 인원 150명임",
                     "초청 대상 320명 중 118명 수락 회신 접수함",
                     "현수막과 안내 책자를 새솔인쇄에 의뢰함, 납품일은 10월 25일임"],
        "향후계획": ["미회신 고객 대상 10월 21일 전화 안내 예정함",
                     "행사 당일 진행 인력 부족, 총무팀에 5명 지원 요청함",
                     "경품 예산 미정"],
    },
    "reply_04": {
        "개요": ["10월 26일~30일 사내 홍보 업무 정리함"],
        "추진실적": ["사내 아마추어 사진전 후원 문의 접수함, 후원 금액은 협의 필요함",
                     "사보 11월호 원고 8편 중 6편 수령함",
                     "신규 입사자 환영 키트 구성안 검토 중"],
        "향후계획": ["사보 11월호 원고 마감 10월 30일 예정함",
                     "시무식 일정은 12월 첫째 주 가안이며 확정 전임"],
    },
}


def variant(**changes):
    """reply_01 을 복사해서 한 군데만 망가뜨린다."""
    data = copy.deepcopy(REPLIES["reply_01"])
    for key, fn in changes.items():
        fn(data)
    return data


def prose(line):
    """개조식 문장을 서술체(~했습니다)로 바꾼다. 함정 샘플용."""
    if line.endswith("함"):
        return line[:-1] + "했습니다."
    if line.endswith("임"):
        return line[:-1] + "입니다."
    return line + "입니다."


def add(section, line):
    return lambda d: d[section].append(line)


def replace(section, index, line):
    def f(d):
        d[section][index] = line
    return f


TRAPS = {
    "trap_01_invented_pct.json": (
        variant(a=add("추진실적", "신규 고객 매출 35% 증가함")),
        {"memo": "golden/memo_01.txt", "kind": "grounding", "contains": "35%",
         "why": "메모에 없는 숫자"}),
    "trap_02_partial_number.json": (
        variant(a=replace("추진실적", 0, "고객 설문 3차 조사 마감, 응답 41건 회수로 목표 400건 달성함")),
        {"memo": "golden/memo_01.txt", "kind": "grounding", "contains": "41",
         "why": "메모의 412건 속에 '41'이 들어 있어도 같은 숫자가 아님"}),
    "trap_03_invented_date.json": (
        variant(a=add("향후계획", "12월 20일까지 납품 예정함")),
        {"memo": "golden/memo_01.txt", "kind": "grounding", "contains": "20",
         "why": "메모에 없는 날짜(1,200의 '20'은 다른 숫자)"}),
    "trap_04_invented_person.json": (
        variant(a=add("향후계획", "김민준 차장 검토 요청함")),
        {"memo": "golden/memo_01.txt", "kind": "grounding", "contains": "김민준",
         "why": "메모에 없는 사람 이름"}),
    "trap_05_invented_company.json": (
        variant(a=add("향후계획", "새론유통과 재계약 협의 예정함")),
        {"memo": "golden/memo_01.txt", "kind": "grounding", "contains": "새론유통",
         "why": "메모에 없는 기관명"}),
    "trap_06_order_swapped.json": (
        {"개요": REPLIES["reply_01"]["개요"], "향후계획": REPLIES["reply_01"]["향후계획"],
         "추진실적": REPLIES["reply_01"]["추진실적"]},
        {"memo": "golden/memo_01.txt", "kind": "shape", "contains": "순서",
         "why": "제목 순서가 바뀜"}),
    "trap_08_banned_word.json": (
        variant(a=add("추진실적", "재계약 가능성이 높은 것 같음")),
        {"memo": "golden/memo_01.txt", "kind": "banned", "contains": "것 같음",
         "why": "추측성 어조"}),
    "trap_09_prose_style.json": (
        {k: [prose(x) for x in v] for k, v in REPLIES["reply_01"].items()},
        {"memo": "golden/memo_01.txt", "kind": "style", "contains": "",
         "why": "개조식이 아닌 서술체"}),
    "trap_10_missing_section.json": (
        {k: v for k, v in REPLIES["reply_01"].items() if k != "향후계획"},
        {"memo": "golden/memo_01.txt", "kind": "shape", "contains": "필수 제목 없음",
         "why": "제목 하나가 빠짐"}),
}

FREE_TEXT = """보고서를 정리했습니다.

1. 개요
이번 주에는 설문 조사를 마감했고 재계약 협의를 진행했습니다.

2. 추진실적
응답을 충분히 회수했으며 포털 개편안 초안도 작성했습니다.

3. 향후계획
다음 주에 팀장님께 보고드릴 예정입니다.
"""

PII_MEMO = MEMOS["memo_01"] + "- 온다유통 담당자 연락처 010-5555-0123\n"


def make_nofont_pdf():
    """글꼴이 내장되지 않은 PDF(한글이 ???로 나오는 PDF의 축소판). PDF 검사기가 걸러야 한다."""
    body = b"BT /F1 14 Tf 72 760 Td (Report ???) Tj ET"
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R "
        b"/Resources << /Font << /F1 5 0 R >> >> >>",
        b"<< /Length %d >>\nstream\n" % len(body) + body + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out, offsets = bytearray(b"%PDF-1.4\n"), []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, xref)
    return bytes(out)


def main():
    GOLD.mkdir(parents=True, exist_ok=True)
    TRAP.mkdir(parents=True, exist_ok=True)
    for name, text in MEMOS.items():
        (GOLD / f"{name}.txt").write_text(text, encoding="utf-8")
    for name, data in REPLIES.items():
        (GOLD / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    expected = {"_설명": "함정 샘플마다 '어떤 이유로' 걸러져야 하는지 적은 표. 엉뚱한 이유로 걸러지면 그것도 실패로 본다."}
    for fname, (data, meta) in TRAPS.items():
        (TRAP / fname).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        expected[fname] = meta
    (TRAP / "trap_07_free_text.txt").write_text(FREE_TEXT, encoding="utf-8")
    expected["trap_07_free_text.txt"] = {"memo": "golden/memo_01.txt", "kind": "free_text", "contains": "JSON",
                                         "why": "JSON이 아닌 자유 문장 응답"}
    (TRAP / "trap_12_nofont.pdf").write_bytes(make_nofont_pdf())
    (TRAP / "trap_11_pii_memo.txt").write_text(PII_MEMO, encoding="utf-8")
    expected["trap_11_pii_memo.txt"] = {"memo": "trap/trap_11_pii_memo.txt", "kind": "pii", "contains": "전화",
                                        "why": "전화번호가 남은 메모는 AI 호출 전에 막혀야 함"}
    (TRAP / "expected.json").write_text(json.dumps(expected, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"골든 메모 {len(MEMOS)}개, 기대 응답 {len(REPLIES)}개, 함정 {len(expected) - 1}개(+글꼴 없는 PDF 1개)를 만들었습니다.")
    print("참고: samples/golden/report_ref.pdf 는 브라우저로 만든 기준 PDF라서 이 스크립트가 만들지 않습니다.")


if __name__ == "__main__":
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    main()
