"""CSV 합계 검사기 (Ch 0 최소 예제)

규칙: '합계' 열의 값이 나머지 숫자 열(부서 이름 열 제외)의 합과 같아야 한다.
표준 라이브러리만 사용한다. 원본 파일은 읽기만 한다.

사용법:
    python src/check_sum.py samples/golden/sales_ok.csv
"""
import csv
import sys

TOLERANCE = 0          # 허용 오차(원). 0이면 1원만 달라도 오류.
TOTAL_COL = "합계"      # 합계 열 이름
LABEL_COL = "부서"      # 숫자가 아닌 이름 열


def to_number(text):
    """'1,500,000' 같은 글자를 숫자로 바꾼다. 바꿀 수 없으면 None."""
    cleaned = str(text).replace(",", "").strip()
    try:
        return int(cleaned)
    except ValueError:
        return None


def check_file(path):
    """오류 목록을 돌려준다. 빈 목록이면 합격."""
    errors = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        columns = reader.fieldnames or []
        if TOTAL_COL not in columns:
            return [f"'{TOTAL_COL}' 열이 없습니다. 열 이름을 확인해 주세요."]
        value_cols = [c for c in columns if c not in (LABEL_COL, TOTAL_COL)]
        for line_no, row in enumerate(reader, start=2):
            label = row.get(LABEL_COL, f"{line_no}행")
            numbers = {}
            for col in value_cols + [TOTAL_COL]:
                n = to_number(row[col])
                if n is None:
                    errors.append(f"{line_no}행({label}) '{col}' 값 '{row[col]}'은 숫자가 아닙니다.")
                numbers[col] = n
            if None in numbers.values():
                continue
            expected = sum(numbers[c] for c in value_cols)
            actual = numbers[TOTAL_COL]
            if abs(expected - actual) > TOLERANCE:
                errors.append(
                    f"{line_no}행({label}) 합계 불일치: 계산 {expected:,} / 적힌 값 {actual:,} "
                    f"(차이 {actual - expected:,}원)"
                )
    return errors


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("사용법: python src/check_sum.py <CSV 파일 경로>")
        sys.exit(1)
    found = check_file(sys.argv[1])
    if found:
        print(f"오류 {len(found)}건")
        for e in found:
            print(" - " + e)
        sys.exit(1)
    print("오류 0건: 모든 합계가 일치합니다.")
