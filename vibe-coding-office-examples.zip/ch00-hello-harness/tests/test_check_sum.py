"""CRITERIA.md의 S, N 항목을 하나씩 확인하는 테스트.
사람이 승인한 뒤에는 AI가 이 파일을 고치지 않는다(CLAUDE.md 규칙).
"""
import hashlib
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from check_sum import check_file  # noqa: E402

GOLDEN = sorted((ROOT / "samples" / "golden").glob("*.csv"))
TRAP = sorted((ROOT / "samples" / "trap").glob("*.csv"))


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class TestCriteria(unittest.TestCase):

    def test_S1_골든샘플은_오류0건(self):
        self.assertTrue(GOLDEN, "골든 샘플이 하나도 없습니다.")
        for path in GOLDEN:
            self.assertEqual(check_file(path), [], f"{path.name}에서 오류가 나면 안 됩니다.")

    def test_S2_1원차이도_찾아낸다(self):
        errors = check_file(ROOT / "samples" / "trap" / "trap_sum_off_by_1.csv")
        self.assertEqual(len(errors), 1, f"정확히 1건이어야 합니다: {errors}")
        self.assertIn("영업2팀", errors[0])

    def test_S3_숫자가아닌값을_찾아낸다(self):
        errors = check_file(ROOT / "samples" / "trap" / "trap_text_value.csv")
        self.assertTrue(any("숫자가 아닙니다" in e for e in errors), errors)

    def test_S4_합계열이없으면_알려준다(self):
        errors = check_file(ROOT / "samples" / "trap" / "trap_no_total_col.csv")
        self.assertTrue(any("열이 없습니다" in e for e in errors), errors)

    def test_N1_원본파일은_바뀌지않는다(self):
        for path in GOLDEN + TRAP:
            before = sha256(path)
            check_file(path)
            self.assertEqual(before, sha256(path), f"{path.name} 원본이 바뀌었습니다.")

    def test_H1_함정샘플은_모두_FAIL(self):
        self.assertGreaterEqual(len(TRAP), 3, "함정 샘플은 최소 3개 있어야 합니다.")
        for path in TRAP:
            self.assertNotEqual(check_file(path), [], f"{path.name}을 통과시키면 안 됩니다.")


if __name__ == "__main__":
    unittest.main()
