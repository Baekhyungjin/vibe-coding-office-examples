# ch00-hello-harness

《직장인 실전 바이브 코딩》 Ch 0 실습 예제입니다. 표준 라이브러리만 쓰므로 Python만 있으면 됩니다.

## 실행 방법 3줄

```
cd ch00-hello-harness
python scripts/verify.py
```

마지막 줄에 `RESULT: PASSED (6/6)` 이 나오면 첫 PASS 성공입니다.

## 파일 하나씩 직접 검사해 보기

```
python src/check_sum.py samples/golden/sales_ok.csv
python src/check_sum.py samples/trap/trap_sum_off_by_1.csv
```

## 폴더 안내

| 폴더/파일 | 역할 |
| --- | --- |
| CRITERIA.md | 성공 기준서 (사람이 쓰고 승인) |
| CLAUDE.md | AI 작업 규칙 (Codex는 AGENTS.md) |
| samples/golden | 통과해야 하는 가짜 데이터 |
| samples/trap | 반드시 걸러져야 하는 가짜 데이터 |
| src/check_sum.py | 실제 검사 프로그램 |
| tests/ | 기준서를 확인하는 테스트 |
| scripts/verify.py | 하네스 실행 진입점, 리포트 생성 |
| output/verify_report.json | 검증 리포트 (실행할 때마다 새로 만들어짐) |
| .claude/settings.json | AI가 끝내려 할 때 하네스를 자동 실행하는 훅 |
