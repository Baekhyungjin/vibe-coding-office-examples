# ch11-publish-check : 공개 전 점검기

폴더를 올리기(공유, GitHub 등) 전에 "이거 올려도 되나?"를 대신 확인해 주는 도구입니다. 표준 라이브러리만 씁니다.

## 실행 방법 (3줄)
```
python scripts/make_samples.py                 # 가짜 샘플 폴더 만들기
python scripts/verify.py                       # 하네스 실행 -> RESULT: PASSED (8/8)
python src/publish_check.py <검사할 폴더 경로>   # 내 폴더 점검 (통과 0, 차단 1)
```

## 검사 5가지
| 코드 | 무엇을 보나 | 차단 / 주의 |
| --- | --- | --- |
| G1 | `.gitignore`에 data, output, .env가 뜻으로 들어 있나 | 차단 |
| P1 | 전화번호, 주민번호, 이메일 등 개인정보 형식 (엑셀 셀 안 포함) | 차단 (허용 목록이면 주의) |
| K1 | `sk-`, `ghp_`, `AKIA` 등 키/토큰 형식 | 항상 차단 |
| D1 | 엑셀, CSV, eml 등 실데이터 확장자 파일 | 차단 (허용 목록이면 주의) |
| A1 | `.publish-allow`의 줄에 사유가 빠졌나 | 차단 |

## 허용 목록 `.publish-allow`
```
samples/  # 테스트용 가짜 데이터. 승인: 김 대리 2026-10-18
```
사유(`#` 뒤)가 없는 줄은 무효입니다. 키(K1)는 허용 목록으로도 못 피합니다.

## 못 찾는 것 (사람이 봅니다)
명단에 없는 사람 이름, 회사 대외비 문장, 이미지 속 글자, 압축 파일 안의 파일.

## 폴더
- `src/publish_check.py` 점검기, `src/masking.py` 개인정보 형식 검사(공통 모듈 복사본)
- `tests/` 테스트(승인 후 수정 금지), `samples/golden`, `samples/trap` 가짜 폴더
- `scripts/verify.py` 하네스, `output/verify_report.json` 결과
- `log/` 집필 중 실제로 남은 첫 실행 리포트(`run1_report.json`)와 첫 판 소스(`publish_check_v1.py`)

모든 전화번호와 키는 가짜입니다 (`010-0123-4567`, `sk-test-FAKE...`).
