# 주간 보고 도우미

실행: python src/main.py
문의: 사내 메신저 '업무자동화' 채널
