"""공개 전 점검기 테스트 (CRITERIA.md 의 S, N 항목 번호를 이름에 붙였다)"""
import json
import shutil
import sys
import time
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from publish_check import check  # noqa: E402
from verify_core import record_metric  # noqa: E402

GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
FAKE_PHONE = "010-0123-4567"
FAKE_KEY = "sk-test-FAKE0000example0000NOTREAL"


def blocked(result):
    return [f for f in result["findings"] if f["level"] == "차단"]


class TestPublishCheck(unittest.TestCase):
    def test_S1_골든폴더는_모두_통과(self):
        for folder in sorted(p for p in GOLDEN.iterdir() if p.is_dir()):
            r = check(folder)
            self.assertEqual(r["verdict"], "통과", f"{folder.name} 이 차단됨: {blocked(r)[:3]}")

    def test_S2_gitignore는_모양이_달라도_뜻으로_판정(self):
        r = check(GOLDEN / "gitignore_variants")
        g1 = [f for f in r["findings"] if f["check"] == "G1"]
        self.assertEqual(g1, [], f"같은 뜻의 .gitignore 를 틀렸다고 봄: {g1}")

    def test_S3_무시되는_폴더는_공개대상이_아님(self):
        r = check(GOLDEN / "clean_basic")
        leaked = [f for f in r["findings"] if f["path"].startswith(("data/", "output/")) or f["path"] == ".env"]
        self.assertEqual(leaked, [], f".gitignore 로 빠지는 파일까지 문제 삼음: {leaked[:3]}")

    def test_S4_함정은_예상한_이유로_차단(self):
        expected = json.loads((TRAP / "expected.json").read_text(encoding="utf-8"))
        wrong = []
        for name, check_id in expected.items():
            if name.startswith("_"):
                continue
            r = check(TRAP / name)
            ids = {f["check"] for f in blocked(r)}
            if check_id not in ids:
                wrong.append(f"{name}: 기대 {check_id}, 실제 차단 {sorted(ids) or '없음'}")
        self.assertEqual(wrong, [], "함정이 예상한 이유로 차단되지 않음:\n" + "\n".join(wrong))

    def test_S5_허용목록은_사유가_있을때만_주의로_낮춤(self):
        r = check(GOLDEN / "allowed_fake_samples")
        warns = [f for f in r["findings"] if f["level"] == "주의"]
        self.assertTrue(warns, "허용된 가짜 샘플도 '주의'로는 보여야 한다")
        self.assertEqual(r["verdict"], "통과")

    def test_N1_키는_허용목록으로도_못_피함(self):
        r = check(TRAP / "key_in_allowed_path")
        keys = [f for f in r["findings"] if f["check"] == "K1"]
        self.assertTrue(keys and all(f["level"] == "차단" for f in keys), f"키가 차단되지 않음: {keys}")

    def test_N2_리포트에_원문이_다시_새지_않음(self):
        for name in ("phone_in_readme", "fake_key_in_config", "phone_in_xlsx"):
            text = json.dumps(check(TRAP / name), ensure_ascii=False)
            self.assertNotIn(FAKE_PHONE, text, f"{name} 리포트에 전화번호 원문이 그대로 있음")
            self.assertNotIn(FAKE_KEY, text, f"{name} 리포트에 키 원문이 그대로 있음")

    def test_S6_파일_1000개_폴더를_10초안에(self):
        big = ROOT / "output" / "_test_tmp" / "big"
        if big.exists():
            shutil.rmtree(big)
        shutil.copytree(GOLDEN / "clean_basic", big)
        for i in range(1000):
            p = big / "docs" / f"note_{i:04d}.md"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(f"# 메모 {i}\n주간 회의 정리. 다음 회의 10/{(i % 28) + 1}\n" * 20, encoding="utf-8")
        start = time.perf_counter()
        r = check(big)
        took = round(time.perf_counter() - start, 2)
        record_metric(ROOT, "파일 1000개 검사 시간(초)", took)
        shutil.rmtree(big)
        self.assertEqual(r["verdict"], "통과", f"깨끗한 메모 1000개가 차단됨: {blocked(r)[:3]}")
        self.assertLess(took, 10, f"{took}초 걸림")


if __name__ == "__main__":
    unittest.main()
