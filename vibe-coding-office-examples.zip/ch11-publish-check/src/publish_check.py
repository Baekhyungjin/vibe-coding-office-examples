"""공개 전 점검기 (Ch 11) 두 번째 판

폴더를 GitHub 등에 올리기 전에 다섯 가지를 검사한다.
  G1  .gitignore 에 data/, output/, .env 가 '뜻으로' 들어 있는가
  P1  개인정보처럼 보이는 문자열이 남아 있는가 (엑셀 셀 안까지 읽는다)
  K1  토큰/키처럼 보이는 문자열이 있는가 (어떤 경우에도 허용 불가)
  D1  엑셀/CSV 같은 실데이터 확장자 파일이 공개 대상에 있는가
  A1  .publish-allow (허용 목록) 의 줄에 사유가 빠져 있지 않은가

공개 대상: .gitignore 로 빠지는 data/, output/, .env 는 공개 대상이 아니므로 검사하지 않는다.
허용 목록: 'samples/  # 사유. 승인: 이름 날짜' 형식. 사유가 있는 줄만 유효하며,
           허용된 경로의 D1, P1 은 '차단' 대신 '주의'로 낮춘다. K1 은 낮추지 않는다.

사용법:
    python src/publish_check.py <검사할 폴더>
"""
import re
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from masking import residual_scan  # noqa: E402

REQUIRED_IGNORES = ["data", "output", ".env"]
DATA_EXTS = {".xlsx", ".xls", ".xlsm", ".csv", ".eml", ".mbox", ".db", ".sqlite", ".hwp", ".hwpx", ".pst"}
TEXT_EXTS = {".md", ".txt", ".py", ".js", ".html", ".css", ".json", ".yaml", ".yml", ".toml",
             ".ini", ".cfg", ".csv", ".eml", ".env", ".sh", ".ps1", ".bat", ""}
SKIP_DIRS = {".git", "__pycache__", "node_modules"}

SECRET_PATTERNS = {
    "sk- 형식 키": re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_\-]{16,}"),
    "GitHub 토큰": re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}"),
    "AWS 액세스 키": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API 키": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}"),
    "Slack 토큰": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}"),
    "개인 키 파일": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "비밀번호 직접 기입": re.compile(r"(?i)\b(?:password|passwd|pwd)\s*[:=]\s*['\"][^'\"\s]{4,}['\"]"),
}
# 개인정보 검사를 건너뛰어도 되는지 빨리 가려내는 거름망 (숫자 6자리 이상 이어지지 않으면 후보가 아니다)
_MAYBE_PII = re.compile(r"\d[\d\-\s.]{5,}\d|@")
_MAYBE_SECRET = re.compile(r"sk-|ghp_|gho_|ghu_|ghs_|ghr_|github_pat_|AKIA|AIza|xox[abprs]-|PRIVATE KEY|(?i:password|passwd|pwd)")


def hide(value):
    """리포트에 원문이 다시 새지 않도록 앞 4글자만 남긴다."""
    return value[:4] + "***" if len(value) > 4 else "***"


def normalize_ignore(line):
    """'/data/', 'data', 'output/**' 처럼 모양이 달라도 같은 이름이면 같은 뜻으로 본다."""
    s = line.strip()
    if not s or s.startswith("#") or s.startswith("!"):
        return None
    s = s.lstrip("/")
    for tail in ("/**", "/*", "/"):
        if s.endswith(tail):
            s = s[: -len(tail)]
    return s or None


def read_ignores(root):
    gi = root / ".gitignore"
    if not gi.exists():
        return set()
    return {n for n in (normalize_ignore(l) for l in gi.read_text(encoding="utf-8", errors="replace").splitlines()) if n}


def read_allow(root):
    """.publish-allow 읽기. 반환: (유효한 경로 접두어 목록, 사유 없는 줄 목록)"""
    path = root / ".publish-allow"
    ok, bad = [], []
    if not path.exists():
        return ok, bad
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        target, _, reason = line.partition("#")
        target = target.strip().lstrip("/")
        if not target:
            continue
        if reason.strip():
            ok.append(target)
        else:
            bad.append(target)
    return ok, bad


def xlsx_text(path):
    """엑셀 안의 글자(공유 문자열, 인라인 문자열)를 모아 하나의 글로 돌려준다."""
    parts = []
    try:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.startswith("xl/") and name.endswith(".xml") and (
                        "sharedStrings" in name or "worksheets/" in name):
                    xml = z.read(name).decode("utf-8", errors="replace")
                    parts.extend(re.findall(r">([^<>]+)<", xml))
    except (zipfile.BadZipFile, OSError):
        return ""
    return "\n".join(parts)


def is_ignored(rel_parts, ignores):
    """data/, output/, .env 처럼 .gitignore 로 빠지는 경로인가."""
    return any(part in ignores for part in rel_parts)


def check(root):
    root = Path(root).resolve()
    findings = []
    ignores = read_ignores(root)
    allow_ok, allow_bad = read_allow(root)

    def allowed(rel):
        return any(rel == a.rstrip("/") or rel.startswith(a if a.endswith("/") else a + "/") for a in allow_ok)

    def add(check_id, path, detail, soften=False):
        level = "주의" if soften and allowed(path) and check_id != "K1" else "차단"
        findings.append({"check": check_id, "level": level, "path": path, "detail": detail})

    # G1 .gitignore (뜻으로 판정)
    for req in REQUIRED_IGNORES:
        if req not in ignores:
            add("G1", ".gitignore", f"{req} 가 .gitignore 에 없습니다")
    # A1 허용 목록에 사유가 없는 줄
    for target in allow_bad:
        add("A1", ".publish-allow", f"{target} 줄에 사유가 없어 허용하지 않습니다 ('경로  # 사유. 승인: 이름 날짜')")

    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel_parts = p.relative_to(root).parts
        if any(part in SKIP_DIRS for part in rel_parts):
            continue
        if is_ignored(rel_parts, ignores):
            continue  # .gitignore 로 빠지는 파일은 공개 대상이 아니다
        rel = p.relative_to(root).as_posix()
        ext = p.suffix.lower()
        if ext in DATA_EXTS:
            add("D1", rel, f"실데이터 확장자({ext}) 파일이 공개 대상에 있습니다", soften=True)
        if ext in (".xlsx", ".xlsm"):
            text = xlsx_text(p)
        elif ext in TEXT_EXTS:
            text = p.read_text(encoding="utf-8", errors="replace")
        else:
            continue
        if _MAYBE_PII.search(text):
            for f in residual_scan(text):
                add("P1", rel, f"개인정보 의심({f['type']}): {hide(f['value'])}", soften=True)
        if _MAYBE_SECRET.search(text):
            for kind, pat in SECRET_PATTERNS.items():
                for m in pat.finditer(text):
                    add("K1", rel, f"{kind} 의심: {hide(m.group(0))}")
    blocked = [f for f in findings if f["level"] == "차단"]
    return {"folder": root.name, "verdict": "통과" if not blocked else "차단", "findings": findings}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    result = check(sys.argv[1])
    for f in result["findings"]:
        print(f"  [{f['level']}] {f['check']} {f['path']}: {f['detail']}")
    n = sum(f["level"] == "차단" for f in result["findings"])
    print(f"공개 판정: {result['verdict']} (차단 {n}건)")
    return 0 if result["verdict"] == "통과" else 1


if __name__ == "__main__":
    sys.exit(main())
