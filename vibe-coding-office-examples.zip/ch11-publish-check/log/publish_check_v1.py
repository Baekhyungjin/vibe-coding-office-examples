"""공개 전 점검기 (Ch 11)

폴더를 GitHub 등에 올리기 전에 네 가지를 검사한다.
  G1  .gitignore 에 data/, output/, .env 가 들어 있는가
  P1  개인정보처럼 보이는 문자열이 남아 있는가 (masking.residual_scan 재사용)
  K1  토큰/키처럼 보이는 문자열이 있는가 (sk-, ghp_, AKIA ...)
  D1  엑셀/CSV 같은 실데이터 확장자 파일이 공개 대상에 있는가

사용법:
    python src/publish_check.py <검사할 폴더>
"""
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from masking import residual_scan  # noqa: E402

REQUIRED_IGNORES = ["data/", "output/", ".env"]
DATA_EXTS = {".xlsx", ".xls", ".xlsm", ".csv", ".eml", ".mbox", ".db", ".sqlite", ".hwp", ".hwpx", ".pst"}
TEXT_EXTS = {".md", ".txt", ".py", ".js", ".html", ".css", ".json", ".yaml", ".yml", ".toml",
             ".ini", ".cfg", ".csv", ".eml", ".env", ".sh", ".ps1", ".bat", ""}

SECRET_PATTERNS = {
    "sk- 형식 키": re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_\-]{16,}"),
    "GitHub 토큰": re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}"),
    "AWS 액세스 키": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API 키": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}"),
    "Slack 토큰": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}"),
    "개인 키 파일": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "비밀번호 직접 기입": re.compile(r"(?i)\b(?:password|passwd|pwd)\s*[:=]\s*['\"][^'\"\s]{4,}['\"]"),
}


def hide(value):
    """리포트에 원문이 다시 새지 않도록 앞 4글자만 남긴다."""
    return value[:4] + "***" if len(value) > 4 else "***"


def check(root):
    root = Path(root).resolve()
    findings = []

    def add(check_id, path, detail):
        findings.append({"check": check_id, "level": "차단", "path": path, "detail": detail})

    # G1 .gitignore
    gi = root / ".gitignore"
    lines = gi.read_text(encoding="utf-8").splitlines() if gi.exists() else []
    for req in REQUIRED_IGNORES:
        if req not in [l.strip() for l in lines]:
            add("G1", ".gitignore", f"{req} 가 .gitignore 에 없습니다")

    # 파일 훑기
    for p in sorted(root.rglob("*")):
        if not p.is_file() or ".git" in p.parts:
            continue
        rel = p.relative_to(root).as_posix()
        ext = p.suffix.lower()
        if ext in DATA_EXTS:
            add("D1", rel, f"실데이터 확장자({ext}) 파일이 공개 대상에 있습니다")
        if ext not in TEXT_EXTS and p.name != ".env":
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        for f in residual_scan(text):
            add("P1", rel, f"개인정보 의심({f['type']}): {hide(f['value'])}")
        for kind, pat in SECRET_PATTERNS.items():
            for m in pat.finditer(text):
                add("K1", rel, f"{kind} 의심: {hide(m.group(0))}")
    blocked = [f for f in findings if f["level"] == "차단"]
    return {"folder": root.name, "verdict": "통과" if not blocked else "차단", "findings": findings}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    result = check(sys.argv[1])
    for f in result["findings"]:
        print(f"  [{f['level']}] {f['check']} {f['path']}: {f['detail']}")
    print(f"공개 판정: {result['verdict']} (차단 {sum(f['level'] == '차단' for f in result['findings'])}건)")
    return 0 if result["verdict"] == "통과" else 1


if __name__ == "__main__":
    sys.exit(main())
