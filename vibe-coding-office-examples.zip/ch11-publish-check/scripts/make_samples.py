"""골든/함정 샘플 폴더를 만든다. 모든 값은 가짜다.

    python scripts/make_samples.py

- 전화번호는 실제로 쓰이지 않는 010-0xxx 형식만 쓴다.
- 키 문자열은 누가 봐도 가짜인 'FAKE' 표시를 넣는다.
"""
import json
import shutil
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"

STD_IGNORE = "# 실데이터와 결과물은 올리지 않는다\ndata/\noutput/\n.env\n__pycache__/\n"
FAKE_PHONE = "010-0123-4567"
FAKE_KEY = "sk-test-FAKE0000example0000NOTREAL"


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_xlsx(path, cell_texts):
    """표준 라이브러리만으로 만든 아주 작은 엑셀 파일(셀 문자열만 들어 있음)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    si = "".join(f"<si><t>{t}</t></si>" for t in cell_texts)
    rows = "".join(
        f'<row r="{i + 1}"><c r="A{i + 1}" t="s"><v>{i}</v></c></row>' for i in range(len(cell_texts))
    )
    files = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            "</Types>"
        ),
        "_rels/.rels": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            "</Relationships>"
        ),
        "xl/workbook.xml": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets><sheet name="명단" sheetId="1" r:id="rId1"/></sheets></workbook>'
        ),
        "xl/_rels/workbook.xml.rels": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
            "</Relationships>"
        ),
        "xl/worksheets/sheet1.xml": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            f"<sheetData>{rows}</sheetData></worksheet>"
        ),
        "xl/sharedStrings.xml": (
            '<?xml version="1.0" encoding="UTF-8"?>'
            f'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">{si}</sst>'
        ),
    }
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, body in files.items():
            z.writestr(name, body)


def base_app(folder, ignore=STD_IGNORE):
    """평범한 앱 폴더 하나: 코드, README, 무시되는 data/와 output/."""
    write(folder / ".gitignore", ignore)
    write(folder / "README.md", "# 주간 보고 도우미\n\n실행: python src/main.py\n문의: 사내 메신저 '업무자동화' 채널\n")
    write(folder / "src" / "main.py", 'print("주간 보고 도우미")\n')
    # 아래 두 폴더는 .gitignore 로 빠지므로 공개 대상이 아니다
    write(folder / "data" / "customers.csv", f"이름,연락처\n가나다,{FAKE_PHONE}\n")
    write(folder / "output" / "result.txt", f"담당 연락처 {FAKE_PHONE}\n")
    write(folder / ".env", f"AI_KEY={FAKE_KEY}\n")


def main():
    if SAMPLES.exists():
        shutil.rmtree(SAMPLES)
    g = SAMPLES / "golden"
    t = SAMPLES / "trap"

    # 골든 1: 표준 .gitignore, 실데이터는 모두 data/ 와 output/ 안
    base_app(g / "clean_basic")

    # 골든 2: .gitignore 를 다른 모양으로 써도 같은 뜻이면 통과해야 한다
    base_app(g / "gitignore_variants", ignore="/data/\noutput/**\n.env\n")

    # 골든 3: 가짜 샘플 폴더를 사유와 함께 허용 목록에 올린 경우 -> 통과, 단 '주의'로 표시
    base_app(g / "allowed_fake_samples")
    write(g / "allowed_fake_samples" / "samples" / "fake_customers.csv", f"이름,연락처\n가짜고객,{FAKE_PHONE}\n")
    write(g / "allowed_fake_samples" / ".publish-allow",
          "# 공개를 허용하는 경로와 사유 (사유 없는 줄은 무효)\nsamples/  # 테스트용 가짜 데이터. 승인: 김 대리 2026-10-18\n")

    # 함정 1: README 에 전화번호가 남음
    base_app(t / "phone_in_readme")
    write(t / "phone_in_readme" / "README.md", f"# 주간 보고 도우미\n\n문의: 김 대리 {FAKE_PHONE}\n")

    # 함정 2: 설정 파일에 키를 직접 적음
    base_app(t / "fake_key_in_config")
    write(t / "fake_key_in_config" / "src" / "config.py", f'AI_KEY = "{FAKE_KEY}"\n')

    # 함정 3: .gitignore 에 data/ 가 빠짐
    base_app(t / "gitignore_missing_data", ignore="output/\n.env\n")

    # 함정 4: 실데이터 엑셀이 공개 폴더(루트)에 놓임
    base_app(t / "data_file_not_ignored")
    write_xlsx(t / "data_file_not_ignored" / "10월_예산실적.xlsx", ["부서", "영업1팀"])

    # 함정 5: 엑셀 셀 안에 전화번호 (허용된 samples/ 안이어도 D1은 주의, P1은 셀 내용까지 읽어야 잡힘)
    base_app(t / "phone_in_xlsx")
    write_xlsx(t / "phone_in_xlsx" / "명단.xlsx", ["이름", "연락처", "가짜고객", FAKE_PHONE])

    # 함정 6: 허용 목록에 사유가 없음
    base_app(t / "allow_without_reason")
    write(t / "allow_without_reason" / "samples" / "list.csv", f"이름,연락처\n가짜고객,{FAKE_PHONE}\n")
    write(t / "allow_without_reason" / ".publish-allow", "samples/\n")

    # 함정 7: 허용 목록 안이라도 키는 절대 허용하지 않는다
    base_app(t / "key_in_allowed_path")
    write(t / "key_in_allowed_path" / "samples" / "settings.json", json.dumps({"key": FAKE_KEY}))
    write(t / "key_in_allowed_path" / ".publish-allow", "samples/  # 가짜 데이터. 승인: 김 대리 2026-10-18\n")

    expected = {
        "_설명": "함정 폴더마다 어떤 검사(check)로 '차단'되어야 하는지 적은 정답표",
        "phone_in_readme": "P1",
        "fake_key_in_config": "K1",
        "gitignore_missing_data": "G1",
        "data_file_not_ignored": "D1",
        "phone_in_xlsx": "P1",
        "allow_without_reason": "A1",
        "key_in_allowed_path": "K1",
    }
    write(t / "expected.json", json.dumps(expected, ensure_ascii=False, indent=2))
    n_g = len([p for p in g.iterdir() if p.is_dir()])
    n_t = len([p for p in t.iterdir() if p.is_dir()])
    print(f"샘플 생성 완료: 골든 {n_g}개, 함정 {n_t}개")


if __name__ == "__main__":
    main()
