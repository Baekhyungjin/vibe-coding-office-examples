"""URL 정리(정규화)와 중복 기사 묶기. (CRITERIA S2)"""
import difflib
import re
import urllib.parse

TITLE_SIMILARITY = 0.9

# 기사 내용과 상관없이 '어디서 눌렀는지'만 기록하는 추적용 값들
TRACKING_PREFIXES = ("utm_",)
TRACKING_KEYS = {"fbclid", "gclid", "dclid", "msclkid", "igshid", "ref", "ref_src",
                 "mc_cid", "mc_eid", "spm", "cmpid", "from"}


def normalize_url(url):
    """같은 기사를 가리키는 주소를 하나의 모양으로 맞춘다.

    - 도메인은 소문자로, 기본 포트(:80, :443)는 뺀다.
    - #뒤(페이지 안 위치)는 뺀다.
    - 추적용 값(utm_*, fbclid, gclid, ref 등)은 지우고, 기사 번호 같은 나머지 값은 남겨 정렬한다.
    - 끝의 / 는 뺀다 (루트 제외).
    """
    parts = urllib.parse.urlsplit(url.strip())
    scheme = parts.scheme.lower()
    host = parts.netloc.lower()
    if (scheme, host.rsplit(":", 1)[-1]) in (("http", "80"), ("https", "443")):
        host = host.rsplit(":", 1)[0]
    query = [(k, v) for k, v in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
             if not k.lower().startswith(TRACKING_PREFIXES) and k.lower() not in TRACKING_KEYS]
    path = parts.path.rstrip("/") or "/"
    return urllib.parse.urlunsplit((scheme, host, path, urllib.parse.urlencode(sorted(query)), ""))


def _clean_title(title):
    return re.sub(r"\s+", " ", title or "").strip()


def title_similarity(a, b):
    return difflib.SequenceMatcher(None, _clean_title(a), _clean_title(b)).ratio()


def dedupe(items, threshold=TITLE_SIMILARITY):
    """먼저 나온 기사를 남기고, 같은 주소이거나 제목이 매우 비슷한 기사는 묶는다.

    돌려주는 값: (남긴 기사 목록, 묶인 기사 목록)
    묶인 기사에는 어떤 기사와 왜 묶였는지(reason)가 붙는다.
    """
    kept, merged, seen = [], [], {}
    for item in items:
        canon = normalize_url(item["link"])
        item = dict(item, url=canon)
        if canon in seen:
            merged.append(dict(item, merged_into=seen[canon]["url"], reason="같은 주소"))
            continue
        twin = None
        for k in kept:
            sm = difflib.SequenceMatcher(None, _clean_title(item["title"]), _clean_title(k["title"]))
            if sm.real_quick_ratio() >= threshold and sm.quick_ratio() >= threshold and sm.ratio() >= threshold:
                twin = k
                break
        if twin is not None:
            merged.append(dict(item, merged_into=twin["url"], reason="제목 유사"))
            continue
        seen[canon] = item
        kept.append(item)
    return kept, merged
