"""예의 바른 수집기: robots.txt 확인, 같은 사이트 1초 간격, 요청 기록. (CRITERIA N2, N3)

- 모든 네트워크 요청은 이 파일의 PoliteFetcher 하나로만 보낸다.
- robots.txt가 막은 주소는 요청 자체를 보내지 않는다.
- 같은 도메인에 연속으로 요청할 때는 이전 응답이 끝난 뒤 최소 min_interval초를 쉰다.
- 링크 검사는 HEAD 요청으로 상태 코드만 본다. 기사 본문은 읽지 않는다.
"""
import csv
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser

MIN_INTERVAL_FLOOR = 1.0


class Blocked(Exception):
    """robots.txt가 허용하지 않는 주소."""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    # 다른 주소로 자동 이동하면 robots 확인과 간격 지키기를 건너뛰게 되므로 따라가지 않는다.
    # 3xx는 '살아 있는 링크'로 본다 (200~399 허용).
    def redirect_request(self, *args, **kwargs):
        return None


class PoliteFetcher:
    def __init__(self, user_agent, min_interval=1.0, max_requests=400, timeout=10, route=None):
        if min_interval < MIN_INTERVAL_FLOOR:
            raise ValueError(f"요청 간격은 {MIN_INTERVAL_FLOOR}초보다 짧을 수 없습니다.")
        self.user_agent = user_agent
        self.min_interval = min_interval
        self.max_requests = max_requests
        self.timeout = timeout
        # route: 테스트용 '가짜 사이트' 연결표. {"garam.example.test": "127.0.0.1:8000"}
        self.route = {k.lower(): v for k, v in (route or {}).items()}
        handlers = [_NoRedirect()]
        if self.route:
            handlers.append(urllib.request.ProxyHandler({}))
        self.opener = urllib.request.build_opener(*handlers)
        self._last = {}
        self._robots = {}
        self.log = []  # {"t", "domain", "method", "path", "status"}

    # ---------- 내부 도구 ----------
    def _wait(self, domain):
        last = self._last.get(domain)
        if last is not None:
            gap = time.monotonic() - last
            if gap < self.min_interval:
                time.sleep(self.min_interval - gap)

    def _send(self, url, method="GET", read_body=False):
        if len(self.log) >= self.max_requests:
            raise RuntimeError(f"1회 실행 요청 한도({self.max_requests}건)를 넘었습니다.")
        parts = urllib.parse.urlsplit(url)
        domain = parts.netloc.lower()
        target = url
        if domain in self.route:
            target = urllib.parse.urlunsplit(("http", self.route[domain], parts.path, parts.query, ""))
        req = urllib.request.Request(target, method=method, headers={"User-Agent": self.user_agent})
        if domain in self.route:
            req.add_header("Host", domain)
        self._wait(domain)
        status, body = None, b""
        try:
            with self.opener.open(req, timeout=self.timeout) as resp:
                status = resp.status
                if read_body:
                    body = resp.read()
        except urllib.error.HTTPError as e:
            status = e.code
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            status = f"연결 실패({type(e).__name__})"
        finally:
            self._last[domain] = time.monotonic()
            self.log.append({"t": round(time.time(), 3), "domain": domain, "method": method,
                             "path": parts.path, "status": status})
        return status, body

    # ---------- robots.txt ----------
    def allowed(self, url):
        parts = urllib.parse.urlsplit(url)
        domain = parts.netloc.lower()
        if domain not in self._robots:
            robots_url = f"{parts.scheme}://{domain}/robots.txt"
            status, body = self._send(robots_url, read_body=True)
            rp = urllib.robotparser.RobotFileParser()
            if status == 200:
                rp.parse(body.decode("utf-8", "replace").splitlines())
            elif status in (401, 403) or not isinstance(status, int) or status >= 500:
                rp.disallow_all = True  # 확인할 수 없으면 보수적으로 수집하지 않는다
            else:
                rp.allow_all = True  # robots.txt가 없으면(404 등) 허용
            self._robots[domain] = rp
        return self._robots[domain].can_fetch(self.user_agent, url)

    # ---------- 공개 기능 ----------
    def get_text(self, url):
        if not self.allowed(url):
            raise Blocked(url)
        status, body = self._send(url, read_body=True)
        if status != 200:
            raise RuntimeError(f"피드를 가져오지 못했습니다: {url} (상태 {status})")
        return body.decode("utf-8", "replace")

    def check_link(self, url):
        """링크 상태만 확인한다. 돌려주는 값: (살아있음 여부, 상태 설명)"""
        if not self.allowed(url):
            return False, "robots.txt 차단"
        status, _ = self._send(url, method="HEAD")
        if status in (405, 501):  # HEAD를 받지 않는 사이트: GET으로 상태만 보고 본문은 읽지 않는다
            status, _ = self._send(url, method="GET")
        if isinstance(status, int) and 200 <= status < 400:
            return True, str(status)
        return False, f"HTTP {status}" if isinstance(status, int) else status

    def save_log(self, path):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=["t", "domain", "method", "path", "status"])
            w.writeheader()
            w.writerows(self.log)
