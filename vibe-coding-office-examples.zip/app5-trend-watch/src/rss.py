"""RSS 2.0 / Atom 피드를 읽어 기사 목록으로 바꾼다 (표준 라이브러리만 사용).

주의: content:encoded 같은 '기사 본문' 필드는 일부러 읽지 않는다.
이 앱은 제목, 링크, 날짜, 설명문(요약용)만 다룬다. (CRITERIA N1)
"""
import datetime
import email.utils
import xml.etree.ElementTree as ET

ATOM = "{http://www.w3.org/2005/Atom}"


def _text(el, tag):
    found = el.find(tag)
    return (found.text or "").strip() if found is not None and found.text else ""


def _parse_date(value):
    value = (value or "").strip()
    if not value:
        return None
    try:
        dt = email.utils.parsedate_to_datetime(value)  # RSS: Fri, 17 Oct 2026 09:00:00 +0900
    except (TypeError, ValueError):
        try:
            dt = datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))  # Atom
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone(datetime.timedelta(hours=9)))
    return dt


def parse_feed(xml_text, feed_name=""):
    """피드 문자열을 받아 기사 딕셔너리 목록을 돌려준다."""
    root = ET.fromstring(xml_text)
    items = []
    if root.tag == ATOM + "feed":
        source = _text(root, ATOM + "title") or feed_name
        for entry in root.findall(ATOM + "entry"):
            link_el = entry.find(ATOM + "link")
            items.append({
                "title": _text(entry, ATOM + "title"),
                "link": (link_el.get("href") or "").strip() if link_el is not None else "",
                "published": _parse_date(_text(entry, ATOM + "updated") or _text(entry, ATOM + "published")),
                "description": _text(entry, ATOM + "summary"),
                "source": source,
                "feed": feed_name,
            })
        return items

    channel = root.find("channel")
    if channel is None:
        raise ValueError(f"RSS 형식이 아닙니다: {feed_name}")
    source = _text(channel, "title") or feed_name
    for item in channel.findall("item"):
        items.append({
            "title": _text(item, "title"),
            "link": _text(item, "link"),
            "published": _parse_date(_text(item, "pubDate")),
            "description": _text(item, "description"),
            "source": source,
            "feed": feed_name,
        })
    return items
