"""(선택 과제) Streamlit 대시보드. 표준 라이브러리 버전(HTML 리포트)으로 충분하면 쓰지 않아도 된다.

설치와 실행 (인터넷, pip 필요):
    pip install streamlit
    streamlit run src/dashboard_streamlit.py

data/trend.db 에 쌓인 기사를 키워드와 기간으로 걸러 보여 준다. 화면은 내 PC(localhost)에서만 연다.
[확인 필요: 집필 환경에서 streamlit 설치가 막혀 실행 확인 전]
"""
import sqlite3
from pathlib import Path

import streamlit as st

DB = Path(__file__).resolve().parent.parent / "data" / "trend.db"

st.set_page_config(page_title="업계 동향", layout="wide")
st.title("업계 동향 대시보드")
if not DB.exists():
    st.warning("data/trend.db 가 없습니다. 먼저 python scripts/collect.py 를 실행하세요.")
    st.stop()
con = sqlite3.connect(DB)
rows = con.execute(
    "SELECT published, source, title, summary, keyword, url, first_seen FROM articles ORDER BY published DESC"
).fetchall()
con.close()
keywords = sorted({r[4] for r in rows})
pick = st.multiselect("키워드", keywords, default=keywords)
shown = [r for r in rows if r[4] in pick]
st.caption(f"{len(shown)}건 / 요약은 RSS 설명문 기준, 본문은 저장하지 않습니다.")
for published, source, title, summary, keyword, url, first_seen in shown:
    st.markdown(f"**[{title}]({url})**  \n{published} | {source} | {keyword}")
    st.text(summary)