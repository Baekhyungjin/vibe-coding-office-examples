"""SQLite 저장. 기사 본문 칸은 처음부터 만들지 않는다. (CRITERIA N1, FR4)"""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    url        TEXT PRIMARY KEY,   -- 정리된 원문 주소
    title      TEXT NOT NULL,
    source     TEXT,               -- 언론사
    published  TEXT,
    summary    TEXT,               -- 2줄(120자) 이내 요약
    keyword    TEXT,
    first_seen TEXT NOT NULL,      -- 처음 수집한 시각 ('신규' 판단용)
    last_seen  TEXT NOT NULL
)
"""


def connect(path):
    con = sqlite3.connect(path)
    con.execute(SCHEMA)
    return con


def upsert(con, article, now_iso):
    """저장하고, 처음 보는 기사면 True를 돌려준다."""
    cur = con.execute("SELECT 1 FROM articles WHERE url = ?", (article["url"],))
    is_new = cur.fetchone() is None
    if is_new:
        con.execute(
            "INSERT INTO articles VALUES (?,?,?,?,?,?,?,?)",
            (article["url"], article["title"], article["source"], article["published_text"],
             article["summary"], article["keyword"], now_iso, now_iso))
    else:
        con.execute("UPDATE articles SET last_seen = ? WHERE url = ?", (now_iso, article["url"]))
    con.commit()
    return is_new


def columns(con):
    return [row[1] for row in con.execute("PRAGMA table_info(articles)")]
