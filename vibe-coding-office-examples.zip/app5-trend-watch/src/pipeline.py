"""수집 > 걸러내기 > 중복 묶기 > 링크 검사 > 요약 > 저장 > 리포트 순서로 한 번 실행한다."""
import datetime
import json
from pathlib import Path

import dedupe
import report
import rss
import store
from fetcher import Blocked, MIN_INTERVAL_FLOOR
from summary import make_summary

MAX_ITEMS_CEILING = 300
KST = datetime.timezone(datetime.timedelta(hours=9))


class ConfigError(ValueError):
    pass


def load_config(path):
    cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_config(cfg)
    return cfg


def validate_config(cfg):
    kws = cfg.get("keywords", [])
    if not 1 <= len(kws) <= 5:
        raise ConfigError("키워드는 1~5개여야 합니다.")
    if cfg.get("days") not in (1, 7, 30):
        raise ConfigError("기간(days)은 1, 7, 30 중 하나여야 합니다.")
    limits = cfg.get("limits", {})
    if limits.get("min_interval_sec", 0) < MIN_INTERVAL_FLOOR:
        raise ConfigError("같은 사이트 요청 간격은 1초 이상이어야 합니다.")
    if not 1 <= limits.get("max_items", 0) <= MAX_ITEMS_CEILING:
        raise ConfigError("1회 수집 건수(max_items)는 1~300 사이여야 합니다.")


def _match_keyword(item, keywords, excludes):
    text = f"{item['title']} {item['description']}".lower()
    if any(x.lower() in text for x in excludes):
        return None
    for k in keywords:
        if k.lower() in text:
            return k
    return None


def run(cfg, now, sources=None, fetcher=None, db_path=None, report_dir=None):
    """sources: [(이름, XML 문자열)]을 주면 네트워크 없이 처리한다(오프라인 테스트용).
    fetcher를 주면 cfg['feeds']의 주소에서 피드를 가져오고 링크도 검사한다."""
    validate_config(cfg)
    keywords, excludes = cfg["keywords"], cfg.get("exclude", [])
    since = now - datetime.timedelta(days=cfg["days"])
    unverified, parsed = [], []

    # 1) 피드 읽기
    if sources is None:
        sources = []
        for feed in cfg.get("feeds", []):
            try:
                sources.append((feed["name"], fetcher.get_text(feed["url"])))
            except Blocked:
                unverified.append({"title": f"[피드] {feed['name']}", "source": "", "url": feed["url"],
                                   "reason": "robots.txt 차단"})
            except RuntimeError as e:
                unverified.append({"title": f"[피드] {feed['name']}", "source": "", "url": feed["url"],
                                   "reason": str(e)})
    for name, xml_text in sources:
        parsed.extend(rss.parse_feed(xml_text, name))

    # 2) 기간과 키워드로 걸러내기, 3) 최대 건수 제한
    matched = []
    for item in parsed:
        if item["published"] is not None and item["published"] < since:
            continue
        kw = _match_keyword(item, keywords, excludes)
        if kw:
            matched.append(dict(item, keyword=kw))
    capped = matched[: cfg["limits"]["max_items"]]

    # 4) 중복 묶기
    kept, duplicates = dedupe.dedupe(capped)

    # 5) 링크 검사 (fetcher가 있을 때만)
    articles = []
    for a in kept:
        if fetcher is not None:
            ok, why = fetcher.check_link(a["url"])
            if not ok:
                unverified.append({"title": a["title"], "source": a["source"], "url": a["url"], "reason": why})
                continue
        pub = a["published"].astimezone(KST).strftime("%Y-%m-%d") if a["published"] else "날짜 미상"
        articles.append({"url": a["url"], "title": a["title"], "source": a["source"],
                         "published_text": pub, "summary": make_summary(a["description"]),
                         "keyword": a["keyword"]})
    articles.sort(key=lambda x: x["published_text"], reverse=True)

    # 6) 저장 (본문 칸 없음)
    new_count = 0
    if db_path is not None:
        con = store.connect(db_path)
        for a in articles:
            a["is_new"] = store.upsert(con, a, now.isoformat(timespec="seconds"))
            new_count += a["is_new"]
        con.close()

    result = {"keywords": keywords, "days": cfg["days"], "parsed_count": len(parsed),
              "matched_count": len(matched), "capped_count": len(capped), "articles": articles,
              "duplicates": duplicates, "unverified": unverified, "new_count": new_count,
              "report_path": None}

    # 7) 리포트
    if report_dir is not None:
        Path(report_dir).mkdir(parents=True, exist_ok=True)
        path = Path(report_dir) / f"동향_{now.strftime('%Y%m%d')}.html"
        path.write_text(report.build_html(result, now.strftime("%Y-%m-%d")), encoding="utf-8")
        result["report_path"] = str(path)
    return result
