"""일일 동향 리포트를 HTML 파일 하나로 만든다 (브라우저로 열어 보는 대시보드)."""
import html

STYLE = """
body{font-family:'Noto Sans KR','Malgun Gothic',sans-serif;margin:24px;color:#222}
table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:6px 8px;vertical-align:top}
th{background:#f3f3f3}td.sum{white-space:pre-line;font-size:14px}.new{color:#c00;font-weight:bold}
.note{color:#666;font-size:13px}
"""


def build_html(result, title_date):
    e = html.escape
    rows = []
    for a in result["articles"]:
        rows.append(
            "<tr>"
            f"<td>{e(a['published_text'])}</td><td>{e(a['source'])}</td>"
            f"<td><a href=\"{e(a['url'])}\" target=\"_blank\" rel=\"noopener\">{e(a['title'])}</a></td>"
            f"<td class=\"sum\">{e(a['summary'])}</td><td>{e(a['keyword'])}</td>"
            f"<td>{'<span class=new>신규</span>' if a.get('is_new') else ''}</td>"
            "</tr>")
    bad = "".join(
        f"<li>{e(u['title'])} ({e(u['source'])}) : {e(u['reason'])} <span class=note>{e(u['url'])}</span></li>"
        for u in result["unverified"]) or "<li>없음</li>"
    dup = "".join(
        f"<li>{e(d['title'])} ({e(d['source'])}) : {e(d['reason'])}로 묶음 <span class=note>대표 기사 {e(d['merged_into'])}</span></li>"
        for d in result["duplicates"]) or "<li>없음</li>"
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<title>업계 동향 {e(title_date)}</title><style>{STYLE}</style></head><body>
<h1>업계 동향 리포트 {e(title_date)}</h1>
<p>키워드: {e(', '.join(result['keywords']))} / 기간: 최근 {result['days']}일 /
기사 {len(result['articles'])}건 (신규 {result['new_count']}건) / 중복 묶음 {len(result['duplicates'])}건</p>
<table><tr><th>날짜</th><th>언론사</th><th>제목</th><th>2줄 요약</th><th>키워드</th><th>신규</th></tr>
{''.join(rows)}</table>
<h2>확인 불가 링크 ({len(result['unverified'])}건)</h2><ul>{bad}</ul>
<h2>중복으로 묶은 기사 ({len(result['duplicates'])}건)</h2>
<p class="note">제목 유사도로 묶은 기사는 서로 다른 기사일 수 있습니다. 한 번씩 눈으로 확인하세요.</p><ul>{dup}</ul>
<p class="note">이 리포트는 RSS 설명문만 요약합니다. 기사 본문은 저장하지 않습니다.
자세한 내용은 반드시 원문 링크에서 확인하세요.</p>
</body></html>"""
