"""RSS 설명문을 2줄(120자) 이내 요약으로 만든다. (CRITERIA S1, N1)

기사 본문을 가져오지 않는다. 언론사가 RSS에 넣어 준 설명문만 줄여 쓴다.
"""
import html
import re
from html.parser import HTMLParser

MAX_CHARS = 120
MAX_LINES = 2


class _Stripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def strip_html(text):
    p = _Stripper()
    p.feed(html.unescape(text or ""))
    return re.sub(r"\s+", " ", " ".join(p.parts)).strip()


def make_summary(description, max_chars=MAX_CHARS, max_lines=MAX_LINES):
    text = strip_html(description)
    if not text:
        return "(요약 없음: 원문 링크에서 확인)"
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", text) if s]
    summary = "\n".join(sentences[:max_lines])
    if len(summary) > max_chars:
        summary = summary[: max_chars - 3].rstrip() + "..."
    return summary
