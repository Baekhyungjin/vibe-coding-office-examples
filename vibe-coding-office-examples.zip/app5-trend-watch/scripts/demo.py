"""인터넷 없이 리포트 화면을 미리 보는 데모.
내 PC 안에 가짜 뉴스 사이트를 잠깐 띄우고, 샘플 피드 6개를 실제와 같은 방식으로 수집한다.

    python scripts/demo.py      (20초 안팎, 1초 간격을 지키기 때문)

결과: output/demo/동향_20261018.html, output/demo/request_log.csv
"""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

import fake_site  # noqa: E402
import pipeline  # noqa: E402
from common import DOMAINS, NOW, TRAP, test_config  # noqa: E402
from fetcher import PoliteFetcher  # noqa: E402


def main():
    server, addr = fake_site.start()
    feeds = [{"name": "가람", "url": "http://garam.example.test/rss/feed_garam.xml"},
             {"name": "새솔", "url": "http://saessol.example.test/rss/feed_saessol_atom.xml"}]
    feeds += [{"name": p.stem, "url": f"http://dasom.example.test/rss/{p.name}"} for p in sorted(TRAP.glob("*.xml"))]
    cfg = test_config(feeds)
    out = ROOT / "output" / "demo"
    out.mkdir(parents=True, exist_ok=True)
    db = out / "demo.db"
    if db.exists():
        db.unlink()
    f = PoliteFetcher(cfg["user_agent"], cfg["limits"]["min_interval_sec"], route={d: addr for d in DOMAINS})
    print("가짜 사이트에서 수집 중... (같은 사이트는 1초 간격)")
    r = pipeline.run(cfg, NOW, fetcher=f, db_path=db, report_dir=out)
    server.shutdown()
    server.server_close()
    f.save_log(out / "request_log.csv")
    print(f"읽은 기사 {r['parsed_count']}건 > 키워드/기간 통과 {r['matched_count']}건 > "
          f"중복 묶음 {len(r['duplicates'])}건 > 표 {len(r['articles'])}건, 확인 불가 {len(r['unverified'])}건")
    for u in r["unverified"]:
        print(f"  확인 불가: {u['title']} ({u['reason']})")
    print(f"요청 {len(f.log)}건 기록: output/demo/request_log.csv")
    print(f"리포트: {r['report_path']}")


if __name__ == "__main__":
    main()