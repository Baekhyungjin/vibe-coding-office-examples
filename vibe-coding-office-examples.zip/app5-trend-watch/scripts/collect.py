"""매일 실행하는 수집 스크립트. config/watch.json 의 feeds 를 실제로 수집한다 (인터넷 필요).

    python scripts/collect.py

결과: data/trend.db (누적 저장, Git 제외), output/동향_YYYYMMDD.html, output/request_log.csv
"""
import datetime
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import pipeline  # noqa: E402
from fetcher import PoliteFetcher  # noqa: E402


def main():
    cfg = pipeline.load_config(ROOT / "config" / "watch.json")
    if not cfg.get("feeds"):
        print("config/watch.json 의 feeds 가 비어 있습니다. RSS 주소를 넣은 뒤 다시 실행하세요.")
        print("인터넷 없이 화면만 보고 싶다면: python scripts/demo.py")
        return 1
    (ROOT / "data").mkdir(exist_ok=True)
    (ROOT / "output").mkdir(exist_ok=True)
    f = PoliteFetcher(cfg["user_agent"], cfg["limits"]["min_interval_sec"])
    now = datetime.datetime.now().astimezone()
    r = pipeline.run(cfg, now, fetcher=f, db_path=ROOT / "data" / "trend.db", report_dir=ROOT / "output")
    f.save_log(ROOT / "output" / "request_log.csv")
    print(f"기사 {len(r['articles'])}건 (신규 {r['new_count']}건), 중복 묶음 {len(r['duplicates'])}건, "
          f"확인 불가 {len(r['unverified'])}건, 요청 {len(f.log)}건")
    print(f"리포트: {r['report_path']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())