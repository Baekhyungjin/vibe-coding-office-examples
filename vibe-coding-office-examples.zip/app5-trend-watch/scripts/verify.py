"""하네스 실행 진입점 (모든 앱 공통 이름: scripts/verify.py)

하는 일
  1. tests/ 폴더의 테스트를 모두 돌린다.
  2. 결과를 output/verify_report.json 에 기록한다.
  3. 마지막 줄에 RESULT: PASSED (n/n) 또는 RESULT: FAILED (k/n) 을 출력한다.
  4. 실패하면 종료 코드 2를 돌려준다(훅이 AI에게 '아직 안 끝났다'고 알릴 때 사용).

사용법:
    python scripts/verify.py          # 자세히
    python scripts/verify.py --quiet  # 요약만
    python scripts/verify.py --live   # 테스트 + config/watch.json 의 실제 RSS 수집 점검(인터넷 필요)
"""
import datetime
import hashlib
import json
import os
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True  # 고친 코드가 바로 반영되도록 캐시 파일을 만들지 않는다

ROOT = Path(__file__).resolve().parent.parent
QUIET = "--quiet" in sys.argv
LIVE = "--live" in sys.argv


def file_hashes():
    hashes = {}
    for path in sorted((ROOT / "samples").rglob("*.xml")):
        rel = path.relative_to(ROOT).as_posix()
        hashes[rel] = hashlib.sha256(path.read_bytes()).hexdigest()[:12]
    return hashes


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def _name(self, test):
        return test.id().split(".")[-1]

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({"test": self._name(test), "result": "PASS"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({"test": self._name(test), "result": "FAIL",
                             "reason": str(err[1]).splitlines()[0]})

    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({"test": self._name(test), "result": "ERROR",
                             "reason": f"{err[0].__name__}: {err[1]}"})


def live_check():
    """config/watch.json 의 실제 피드를 한 번 수집해 본다. 결과는 표에 저장하지 않는다."""
    sys.path.insert(0, str(ROOT / "src"))
    import datetime as _dt
    import pipeline
    from fetcher import PoliteFetcher
    cfg = pipeline.load_config(ROOT / "config" / "watch.json")
    if not cfg.get("feeds"):
        print("[LIVE] config/watch.json 의 feeds 가 비어 있어 실제 수집 점검을 건너뜁니다.")
        return {"result": "SKIPPED", "reason": "feeds 비어 있음"}
    f = PoliteFetcher(cfg["user_agent"], cfg["limits"]["min_interval_sec"])
    now = _dt.datetime.now().astimezone()
    r = pipeline.run(cfg, now, fetcher=f)
    (ROOT / "output").mkdir(exist_ok=True)
    f.save_log(ROOT / "output" / "request_log_live.csv")
    status = "PASSED" if r["parsed_count"] > 0 else "FAILED"
    print(f"[LIVE] 피드 {len(cfg['feeds'])}개, 읽은 기사 {r['parsed_count']}건, 표 {len(r['articles'])}건, "
          f"확인 불가 {len(r['unverified'])}건, 요청 {len(f.log)}건 -> {status}")
    return {"result": status, "parsed": r["parsed_count"], "articles": len(r["articles"]),
            "unverified": len(r["unverified"]), "requests": len(f.log)}

def main():
    if not QUIET:
        print("[하네스] 가짜 사이트 테스트는 1초 간격을 지키므로 20초 안팎 걸립니다.")
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with open(os.devnull, "w", encoding="utf-8") as sink:
        runner = unittest.TextTestRunner(resultclass=RecordingResult, verbosity=0, stream=sink)
        result = runner.run(suite)

    total = len(result.records)
    passed = sum(1 for r in result.records if r["result"] == "PASS")
    ok = total > 0 and passed == total

    report = {
        "app": ROOT.name,
        "run_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "sample_hashes": file_hashes(),
        "tests": result.records,
        "result": "PASSED" if ok else "FAILED",
        "passed": passed,
        "total": total,
    }
    if LIVE:
        report["live"] = live_check()
        if report["live"]["result"] == "FAILED":
            ok = False
            report["result"] = "FAILED"

    out_dir = ROOT / "output"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "verify_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    if not QUIET:
        print(f"[하네스] {ROOT.name} 검사 시작 ({report['run_at']})")
        for r in result.records:
            line = f"  {r['result']:<5} {r['test']}"
            if "reason" in r:
                line += f"\n        이유: {r['reason']}"
            print(line)
        print("  리포트: output/verify_report.json")
    if ok:
        print(f"RESULT: PASSED ({passed}/{total})")
        return 0
    print(f"RESULT: FAILED ({total - passed}/{total})")
    # 훅(Stop)이 종료 코드 2를 받으면 stderr 내용을 AI에게 보여준다.
    # 그래서 실패 항목과 이유를 stderr에도 남긴다.
    for r in result.records:
        if r["result"] != "PASS":
            print(f"{r['result']} {r['test']}: {r.get('reason', '')}", file=sys.stderr)
    print("하네스 실패: 위 항목을 고친 뒤 다시 실행하세요. tests/와 samples/는 고치지 마세요.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
