# app5-trend-watch: 업계 동향 모니터링 (Ch 10)

Python 3.11 이상, 표준 라이브러리만 사용합니다. 설치할 것이 없습니다.

## 실행 3줄
```
python scripts/verify.py     # 하네스: 인터넷 없이 15개 테스트 (20초 안팎)
python scripts/demo.py       # 가짜 뉴스 사이트로 리포트 미리 보기 > output/demo/
python scripts/collect.py    # 실제 수집 (config/watch.json 의 feeds 에 RSS 주소를 넣은 뒤)
```

## 폴더
| 위치 | 내용 |
| --- | --- |
| CRITERIA.md | 성공 기준서 (사람이 승인, 이후 잠금) |
| CLAUDE.md | AI 작업 규칙 |
| config/watch.json | 키워드, 기간, 제외어, RSS 주소, 수집 한도 |
| src/ | rss.py(피드 읽기) dedupe.py(주소 정리, 중복) summary.py(2줄 요약) fetcher.py(robots, 1초 간격, 링크 검사) store.py(SQLite) report.py(HTML) pipeline.py(전체 순서) dashboard_streamlit.py(선택) |
| samples/golden | 통과해야 하는 가상 언론사 피드 (RSS 1, Atom 1) |
| samples/trap | 추적 파라미터 중복, 404 링크, robots 차단, 본문 포함 피드 |
| samples/site/robots.txt | 가짜 사이트의 robots.txt (/private/ 차단) |
| tests/ | test_offline.py(파일만), test_site.py(가짜 사이트), fake_site.py, common.py |
| scripts/verify.py | 하네스 진입점, --live 로 실제 피드 점검 |
| data/ | 누적 DB (Git 제외) |
| output/ | 리포트, 요청 기록, verify_report.json (Git 제외) |

샘플의 언론사(가람일보, 새솔경제, 다솜뉴스)와 기사는 모두 가상입니다. 주소는 예약 도메인(.example.test)입니다.
