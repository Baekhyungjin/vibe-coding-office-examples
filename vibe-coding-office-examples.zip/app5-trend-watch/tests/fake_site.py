"""테스트용 가짜 뉴스 사이트 (인터넷 없이 내 PC 안에서만 동작).

- /robots.txt          : samples/site/robots.txt (/private/ 차단)
- /rss/<파일명>.xml    : samples/golden, samples/trap 의 피드 파일
- /news/ok-*.html      : 200 (살아 있는 기사)
- /news/gone-*.html    : 404 (삭제된 기사)
- /private/*           : 200 이지만, 예의 바른 수집기라면 절대 요청하면 안 되는 곳

들어온 요청은 모두 server.request_log 에 (시각, Host, 방식, 경로) 로 남는다.
수집기 자신의 기록이 아니라 '사이트 쪽 기록'으로 검사하기 위해서다.
"""
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SAMPLES = Path(__file__).resolve().parent.parent / "samples"


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # 콘솔을 조용하게
        pass

    def _reply(self, code, body=b"", ctype="text/html; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _handle(self):
        path = self.path.split("?")[0]
        self.server.request_log.append(
            (time.monotonic(), (self.headers.get("Host") or "").lower(), self.command, path))
        if path == "/robots.txt":
            return self._reply(200, (SAMPLES / "site" / "robots.txt").read_bytes(), "text/plain; charset=utf-8")
        if path.startswith("/rss/"):
            name = path[len("/rss/"):]
            for folder in ("golden", "trap"):
                f = SAMPLES / folder / name
                if f.is_file():
                    return self._reply(200, f.read_bytes(), "application/rss+xml; charset=utf-8")
            return self._reply(404)
        if path.startswith("/news/ok-") or path.startswith("/private/"):
            return self._reply(200, "<html><body>기사 본문(가짜)</body></html>".encode("utf-8"))
        return self._reply(404)

    do_GET = _handle
    do_HEAD = _handle


def start():
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    server.request_log = []
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"127.0.0.1:{server.server_address[1]}"
