"""테스트 공통 설정. 기준 시각을 고정해서 언제 돌려도 같은 결과가 나오게 한다."""
import contextlib
import datetime
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.dont_write_bytecode = True

KST = datetime.timezone(datetime.timedelta(hours=9))
NOW = datetime.datetime(2026, 10, 18, 9, 0, tzinfo=KST)
GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
DOMAINS = ["garam.example.test", "saessol.example.test", "dasom.example.test"]


def test_config(feeds=None):
    return {
        "keywords": ["전기자전거", "구독 서비스", "친환경 포장"],
        "days": 7,
        "exclude": ["광고"],
        "feeds": feeds or [],
        "limits": {"max_items": 300, "min_interval_sec": 1.0, "summary_max_chars": 120},
        "user_agent": "TrendWatchBook/0.1 (+test)",
    }


def read(path):
    return Path(path).read_text(encoding="utf-8")


@contextlib.contextmanager
def work_dir(name):
    """테스트용 임시 폴더. 회사 PC 보안 프로그램이 시스템 임시 폴더(TEMP)를 막는 경우가 있어
    앱 폴더 안 output/_test_tmp 를 쓰고, 끝나면 지운다."""
    d = ROOT / "output" / "_test_tmp" / name
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    try:
        yield d
    finally:
        shutil.rmtree(d, ignore_errors=True)