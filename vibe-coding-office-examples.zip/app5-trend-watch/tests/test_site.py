"""가짜 뉴스 사이트를 내 PC에 띄우고 실제로 수집해 보는 테스트 (T3, T5, T6).
요청 간격 1초를 지키므로 이 파일은 20초 안팎이 걸린다.
사람이 승인한 뒤에는 AI가 이 파일을 고치지 않는다(CLAUDE.md 규칙).
"""
import collections
import unittest

from common import DOMAINS, GOLDEN, NOW, TRAP, test_config

import fake_site  # noqa: E402
import pipeline  # noqa: E402
from fetcher import PoliteFetcher  # noqa: E402


class TestFakeSite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.server, addr = fake_site.start()
        feeds = [{"name": "가람", "url": "http://garam.example.test/rss/feed_garam.xml"},
                 {"name": "새솔", "url": "http://saessol.example.test/rss/feed_saessol_atom.xml"}]
        feeds += [{"name": p.stem, "url": f"http://dasom.example.test/rss/{p.name}"}
                  for p in sorted(TRAP.glob("*.xml"))]
        cfg = test_config(feeds)
        cls.fetcher = PoliteFetcher(cfg["user_agent"], cfg["limits"]["min_interval_sec"],
                                    route={d: addr for d in DOMAINS})
        cls.result = pipeline.run(cfg, NOW, fetcher=cls.fetcher)
        cls.server.shutdown()
        cls.server.server_close()
        cls.site_log = list(cls.server.request_log)

    def test_T3_404기사는_표에서_빠지고_확인불가에_2건(self):
        urls = [a["url"] for a in self.result["articles"]]
        self.assertFalse(any("gone-" in u for u in urls), f"404 기사가 표에 있습니다: {urls}")
        gone = [u for u in self.result["unverified"] if u["reason"] == "HTTP 404"]
        self.assertEqual(len(gone), 2, f"확인 불가(404)는 2건이어야 합니다: {self.result['unverified']}")

    def test_T3_정상기사는_모두_표에_남는다(self):
        self.assertEqual(len(self.result["articles"]), 9,
                         f"표에 9건이 있어야 합니다: {[a['title'] for a in self.result['articles']]}")

    def test_T5_robots차단_경로에는_요청을_보내지_않는다(self):
        private = [r for r in self.site_log if r[3].startswith("/private/")]
        self.assertEqual(private, [], "robots.txt가 막은 /private/ 경로에 요청이 들어왔습니다.")
        blocked = [u for u in self.result["unverified"] if u["reason"] == "robots.txt 차단"]
        self.assertEqual(len(blocked), 2)
        robots_reads = collections.Counter(r[1] for r in self.site_log if r[3] == "/robots.txt")
        self.assertEqual(set(robots_reads), set(DOMAINS), "사이트마다 robots.txt를 먼저 확인해야 합니다.")

    def test_T6_같은사이트_연속요청_간격_1초이상(self):
        by_host = collections.defaultdict(list)
        for t, host, _, _ in self.site_log:
            by_host[host].append(t)
        gaps = []
        for host, times in by_host.items():
            gaps += [(round(b - a, 3), host) for a, b in zip(times, times[1:])]
        self.assertTrue(gaps, "요청 기록이 없습니다.")
        short = [g for g in gaps if g[0] < 1.0]
        self.assertEqual(short, [], f"1초보다 짧은 간격: {short[:5]}")

    def test_링크검사는_HEAD로_본문을_받지_않는다(self):
        news = [r for r in self.site_log if r[3].startswith("/news/")]
        self.assertTrue(news)
        self.assertTrue(all(r[2] == "HEAD" for r in news), "기사 주소에는 HEAD 요청만 보내야 합니다.")


if __name__ == "__main__":
    unittest.main()
