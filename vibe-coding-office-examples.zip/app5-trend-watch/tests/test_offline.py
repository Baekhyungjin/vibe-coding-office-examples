"""인터넷 없이 저장된 샘플 파일만으로 확인하는 테스트 (T1, T2, T4, 수집 한도).
사람이 승인한 뒤에는 AI가 이 파일을 고치지 않는다(CLAUDE.md 규칙).
"""
import hashlib
import sqlite3
import unittest
from pathlib import Path

from common import GOLDEN, NOW, TRAP, read, test_config, work_dir

import pipeline  # noqa: E402
import rss  # noqa: E402
import store  # noqa: E402
from dedupe import normalize_url  # noqa: E402
from summary import make_summary  # noqa: E402


def golden_sources():
    return [(p.name, read(p)) for p in sorted(GOLDEN.glob("*.xml"))]


class TestOffline(unittest.TestCase):

    def test_T1_골든피드_파싱_건수일치(self):
        garam = rss.parse_feed(read(GOLDEN / "feed_garam.xml"))
        atom = rss.parse_feed(read(GOLDEN / "feed_saessol_atom.xml"))
        self.assertEqual((len(garam), len(atom)), (6, 5), "RSS 6건, Atom 5건을 모두 읽어야 합니다.")
        r = pipeline.run(test_config(), NOW, sources=golden_sources())
        titles = sorted(a["title"] for a in r["articles"])
        self.assertEqual(len(r["articles"]), 6,
                         f"기간, 키워드, 제외어, 중복을 거친 뒤 6건이어야 합니다. 실제 {len(titles)}건: {titles}")
        for bad in ("프로야구", "반도체", "[광고]", "배터리 화재"):
            self.assertFalse(any(bad in t for t in titles), f"'{bad}' 기사가 표에 들어가면 안 됩니다.")

    def test_T2_추적파라미터만_다른_같은기사는_1건(self):
        r = pipeline.run(test_config(), NOW, sources=[("trap", read(TRAP / "trap_tracking_params.xml"))])
        urls = [a["url"] for a in r["articles"]]
        self.assertEqual(len(urls), 1, f"같은 기사 3건이 1건으로 묶여야 합니다. 남은 주소: {urls}")
        self.assertEqual(urls[0], "http://dasom.example.test/news/ok-3001.html")

    def test_T2_정규화는_진짜_다른기사를_합치지_않는다(self):
        a = normalize_url("http://garam.example.test/news/view?id=1001&utm_source=rss")
        b = normalize_url("http://garam.example.test/news/view?id=1002&utm_source=rss")
        self.assertNotEqual(a, b, "기사 번호(id)처럼 의미 있는 값은 지우면 안 됩니다.")

    def test_T2_골든에서_다른언론사_같은기사는_제목유사도로_묶인다(self):
        r = pipeline.run(test_config(), NOW, sources=golden_sources())
        reasons = [d["reason"] for d in r["duplicates"]]
        self.assertEqual(reasons, ["제목 유사"], f"묶인 기사: {reasons}")

    def test_T4_요약은_2줄_120자_이내(self):
        r = pipeline.run(test_config(), NOW, sources=golden_sources() + [
            ("long", read(TRAP / "trap_long_body.xml"))])
        for a in r["articles"]:
            self.assertLessEqual(len(a["summary"]), 120, f"요약이 너무 깁니다: {a['title']}")
            self.assertLessEqual(len(a["summary"].splitlines()), 2, f"요약이 2줄을 넘습니다: {a['title']}")
        self.assertIn("...", make_summary("가" * 500))

    def test_T4_본문저장칸이_없고_본문이_DB에_들어가지_않는다(self):
        with work_dir("t4") as d:
            db = Path(d) / "t.db"
            pipeline.run(test_config(), NOW, sources=[("long", read(TRAP / "trap_long_body.xml"))], db_path=db)
            con = sqlite3.connect(db)
            cols = store.columns(con)
            dump = "\n".join(con.iterdump())
            con.close()
        for bad in ("body", "content", "본문", "html"):
            self.assertFalse(any(bad in c.lower() for c in cols), f"본문 저장 칸이 있으면 안 됩니다: {cols}")
        self.assertNotIn("BODY-SHOULD-NOT-BE-STORED", dump, "content:encoded 본문이 저장되었습니다.")

    def test_수집한도_1회_300건을_넘지_않는다(self):
        items = "".join(
            f"<item><title>전기자전거 {hashlib.sha256(str(i).encode()).hexdigest()[:24]}</title>"
            f"<link>http://bulk.example.test/news/ok-{i}.html</link>"
            f"<pubDate>Fri, 17 Oct 2026 09:00:00 +0900</pubDate><description>대량 샘플</description></item>"
            for i in range(350))
        xml = f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>대량(가상)</title>{items}</channel></rss>'
        r = pipeline.run(test_config(), NOW, sources=[("bulk", xml)])
        self.assertEqual(r["matched_count"], 350)
        self.assertLessEqual(len(r["articles"]), 300, "1회 실행 최대 300건을 넘었습니다.")

    def test_설정으로_원칙을_완화할_수_없다(self):
        for key, value in (("min_interval_sec", 0.2), ("max_items", 1000)):
            cfg = test_config()
            cfg["limits"][key] = value
            with self.assertRaises(pipeline.ConfigError, msg=f"{key}={value} 설정은 거부되어야 합니다."):
                pipeline.run(cfg, NOW, sources=[])

    def test_FR4_두번째_수집에서는_신규가_0건(self):
        with work_dir("fr4") as d:
            db = Path(d) / "t.db"
            first = pipeline.run(test_config(), NOW, sources=golden_sources(), db_path=db)
            second = pipeline.run(test_config(), NOW, sources=golden_sources(), db_path=db)
        self.assertEqual((first["new_count"], second["new_count"]), (6, 0))

    def test_FR5_리포트파일_생성과_특수문자_처리(self):
        with work_dir("fr5") as d:
            r = pipeline.run(test_config(), NOW, sources=golden_sources(), report_dir=d)
            page = Path(r["report_path"]).read_text(encoding="utf-8")
            name = Path(r["report_path"]).name
        self.assertEqual(name, "동향_20261018.html")
        self.assertEqual(page.count("<tr>") - 1, 6, "표의 기사 행이 6개여야 합니다.")
        self.assertNotIn("<p>월 단위로", page, "설명문의 HTML 태그가 그대로 들어가면 안 됩니다.")


if __name__ == "__main__":
    unittest.main()
