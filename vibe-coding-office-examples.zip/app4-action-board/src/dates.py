"""상대 날짜 표현을 회의 날짜 기준 YYYY-MM-DD 로 바꾼다 (모드 A, AI 미사용).

AI가 계산한 날짜는 믿지 않는다. AI는 회의록에 적힌 표현(due_text)만 옮기고,
날짜 계산은 언제나 이 파일이 한다. 그래서 결과가 매번 같다.

지원 표현 (회의 날짜가 2026-10-19 월요일일 때)
  오늘(중으로)          -> 2026-10-19
  내일                  -> 2026-10-20
  모레                  -> 2026-10-21
  N일 후 / N일 뒤       -> 회의 날짜 + N일
  이번 주 (안/중/까지)  -> 이번 주 금요일
  이번 주 X요일         -> 이번 주의 X요일
  다음 주 (안/중/까지)  -> 다음 주 금요일
  다음 주 X요일         -> 다음 주의 X요일
  월말 / 이달 말        -> 이번 달 마지막 날
  다음 달 N일           -> 다음 달 N일
  M월 D일 / M/D         -> 올해(지났으면 내년) 그 날짜
"""
import calendar
import datetime as dt
import re

WEEKDAYS = "월화수목금토일"


def _monday(d):
    return d - dt.timedelta(days=d.weekday())


def _weekday_index(text):
    m = re.search(r"([월화수목금토일])요일", text)
    return WEEKDAYS.index(m.group(1)) if m else None


def resolve(expr, base):
    """expr: 회의록 표현, base: 회의 날짜(date). (날짜, 근거) 또는 None"""
    if isinstance(base, str):
        base = dt.date.fromisoformat(base)
    t = re.sub(r"\s+", " ", expr.strip())

    m = re.search(r"(\d{1,2})월 ?(\d{1,2})일", t) or re.search(r"(?<!\d)(\d{1,2})/(\d{1,2})(?!\d)", t)
    if m and "다음 달" not in t:
        month, day = int(m.group(1)), int(m.group(2))
        year = base.year
        try:
            d = dt.date(year, month, day)
        except ValueError:
            return None
        if d < base:
            d = dt.date(year + 1, month, day)
        return d, f"날짜를 직접 적음 ({month}월 {day}일)"

    m = re.search(r"다음 ?달 ?(\d{1,2})일", t)
    if m:
        y, mo = (base.year + 1, 1) if base.month == 12 else (base.year, base.month + 1)
        try:
            return dt.date(y, mo, int(m.group(1))), f"회의 다음 달 {int(m.group(1))}일"
        except ValueError:
            return None

    m = re.search(r"(\d{1,3}) ?일 ?(후|뒤)", t)
    if m:
        n = int(m.group(1))
        return base + dt.timedelta(days=n), f"회의 날짜 + {n}일"

    if "모레" in t:
        return base + dt.timedelta(days=2), "회의 날짜 + 2일 (모레)"
    if "내일" in t:
        return base + dt.timedelta(days=1), "회의 날짜 + 1일 (내일)"
    if "오늘" in t:
        return base, "회의 당일 (오늘)"

    if re.search(r"월말|이달 ?말|이번 ?달 ?말", t):
        last = calendar.monthrange(base.year, base.month)[1]
        return dt.date(base.year, base.month, last), "회의가 열린 달의 마지막 날 (월말)"

    wd = _weekday_index(t)
    if re.search(r"다음 ?주", t):
        if wd is None:
            wd = 4
        d = _monday(base) + dt.timedelta(days=7 + wd)      # 월요일 시작 기준으로 '다음 주'
        return d, f"다음 주 {WEEKDAYS[wd]}요일"
    if re.search(r"이번 ?주", t):
        if wd is None:
            wd = 4
        d = _monday(base) + dt.timedelta(days=wd)
        return max(d, base), f"회의가 열린 주의 {WEEKDAYS[wd]}요일"
    return None
