"""회의록 -> Action Item JSON

흐름
  1. 회의록(.txt/.md/.docx)을 읽는다.
  2. 고객 전화번호, 이메일 같은 정형 개인정보를 로컬에서 가린다. (앱 3 원칙: 로컬 먼저, AI는 그다음)
  3. AI(모드 B)에게 '회의록에 적힌 그대로' 할 일을 JSON으로 뽑게 한다.
  4. 결과를 기계로 검사한다. (모드 A)
     - 스키마 검사       : 칸 이름, 형식, 상태값
     - 근거 대조         : source_quote 가 회의록에 글자 그대로 있는가
     - 담당자 대조       : owner 가 근거 문장 앞뒤 2문장 안에 있는가, 참석자 명단에 있는가
     - 마감일 대조       : due_text 가 근거 근처에 있는가, 날짜 계산이 맞는가
  5. 문제가 0건일 때만 output/actions_<이름>.json 을 쓴다. 아니면 output/rejected_<이름>.json.

사용 예
  python src/extract.py samples/golden/meeting_01.txt --date 2026-10-19 \
         --attendees 한지원,도하윤,변지석,남궁솔,여태민 --ai mock:samples/golden/responses/meeting_01.json
  python src/extract.py 회의록.docx --date 2026-10-19 --ai claude      [확인 필요: 독자 환경]
"""
import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))

from ai_call import BadAIResponse, MockAI, call_ai, cli_backend, extract_json  # noqa: E402
from dates import resolve  # noqa: E402
from masking import residual_scan  # noqa: E402

UNKNOWN = "미정"
STATUSES = ("todo", "doing", "done")
ITEM_FIELDS = {"id": str, "task": str, "owner": str, "due": str, "due_text": str,
               "status": str, "source_quote": str}

PROMPT = """아래 회의록에서 할 일(Action Item)을 뽑아 JSON 하나로만 답하세요. 설명 문장은 쓰지 마세요.
규칙
- source_quote 에는 근거 문장을 회의록에서 글자 하나 바꾸지 말고 그대로 복사합니다.
- owner 는 회의록에 적힌 이름만 씁니다. 없으면 "미정".
- due_text 에는 회의록에 적힌 마감 표현(예: "다음 주 금요일까지")을 그대로 옮기고, 없으면 "".
- due 는 비워 두지 말고 날짜를 모르면 "미정". 날짜 계산은 프로그램이 다시 합니다.
- status 는 모두 "todo".
형식
{{"meeting_date": "{date}", "items": [{{"id": "A1", "task": "", "owner": "", "due": "YYYY-MM-DD 또는 미정",
  "due_text": "", "status": "todo", "source_quote": ""}}]}}
회의 날짜: {date}
회의록:
{notes}
"""


# ---------- 1. 읽기 ----------
def read_notes(path):
    path = Path(path)
    if path.suffix.lower() == ".docx":
        import docx  # python-docx
        return "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    return path.read_text(encoding="utf-8-sig")


# ---------- 2. 로컬 가리기 (정형 개인정보만) ----------
def mask_structured(text):
    """고객 전화, 이메일, 주민번호, 카드, 계좌처럼 형식이 있는 값만 가린다.
    팀원 이름은 담당자를 찾아야 하므로 가리지 않는다(사내 회의록 전제)."""
    hits = residual_scan(text)
    for h in sorted(hits, key=lambda h: len(h["value"]), reverse=True):
        text = text.replace(h["value"], f"[{h['type']}]")
    return text, len(hits)


# ---------- 3. 문장 나누기 ----------
def split_sentences(text):
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        out.extend(s for s in re.split(r"(?<=[.?!])\s+", line) if s.strip())
    return out


def window_of(quote, sentences, size=2):
    """quote 가 들어 있는 문장 앞뒤 size 문장을 하나의 글로 돌려준다."""
    for i, s in enumerate(sentences):
        if quote in s or s in quote:
            return " ".join(sentences[max(0, i - size): i + size + 1])
    return ""


# ---------- 4. 검사 ----------
def check_schema(data):
    problems = []
    if not isinstance(data, dict):
        return [("SCHEMA", "응답이 JSON 객체가 아닙니다")]
    md = data.get("meeting_date")
    if not isinstance(md, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", md):
        problems.append(("SCHEMA", "meeting_date 가 YYYY-MM-DD 형식이 아닙니다"))
    items = data.get("items")
    if not isinstance(items, list):
        return problems + [("SCHEMA", "items 가 목록이 아닙니다")]
    seen = set()
    for n, it in enumerate(items, 1):
        tag = it.get("id", f"#{n}") if isinstance(it, dict) else f"#{n}"
        if not isinstance(it, dict):
            problems.append(("SCHEMA", f"{tag}: 항목이 객체가 아닙니다"))
            continue
        for key, typ in ITEM_FIELDS.items():
            if key not in it:
                problems.append(("SCHEMA", f"{tag}: 필수 칸 '{key}' 없음"))
            elif not isinstance(it[key], typ):
                problems.append(("SCHEMA", f"{tag}: '{key}' 형식 오류"))
        extra = set(it) - set(ITEM_FIELDS)
        if extra:
            problems.append(("SCHEMA", f"{tag}: 약속에 없는 칸 {sorted(extra)}"))
        if it.get("status") not in STATUSES:
            problems.append(("SCHEMA", f"{tag}: status '{it.get('status')}' 는 todo/doing/done 이 아닙니다"))
        due = it.get("due")
        if isinstance(due, str) and due != UNKNOWN and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", due):
            problems.append(("SCHEMA", f"{tag}: due '{due}' 는 YYYY-MM-DD 또는 미정이어야 합니다"))
        if isinstance(it.get("task"), str) and not it["task"].strip():
            problems.append(("SCHEMA", f"{tag}: task 가 비어 있습니다"))
        if tag in seen:
            problems.append(("SCHEMA", f"{tag}: id 중복"))
        seen.add(tag)
    return problems


def check_grounding(data, notes, attendees=None):
    problems = []
    sentences = split_sentences(notes)
    base = data["meeting_date"]
    for it in data["items"]:
        tag, quote = it["id"], it["source_quote"]
        if not quote or quote not in notes:
            problems.append(("QUOTE", f"{tag}: source_quote 가 회의록에 글자 그대로 없습니다: '{quote[:30]}'"))
            continue
        near = window_of(quote, sentences)
        owner = it["owner"]
        if owner != UNKNOWN:
            if owner not in near:
                problems.append(("OWNER", f"{tag}: 담당자 '{owner}' 가 근거 문장 앞뒤 2문장 안에 없습니다"))
            if attendees and owner not in attendees:
                problems.append(("OWNER", f"{tag}: 담당자 '{owner}' 는 참석자 명단에 없습니다"))
        due, due_text = it["due"], it["due_text"]
        if due == UNKNOWN:
            if due_text:
                problems.append(("DUE", f"{tag}: due_text '{due_text}' 가 있는데 due 가 미정입니다"))
            continue
        if not due_text:
            problems.append(("DUE", f"{tag}: 마감 표현(due_text) 없이 날짜 {due} 를 적었습니다 (지어낸 마감일 의심)"))
            continue
        if due_text not in near:
            problems.append(("DUE", f"{tag}: 마감 표현 '{due_text}' 가 근거 문장 근처에 없습니다"))
            continue
        r = resolve(due_text, base)
        if r is None:
            problems.append(("DUE", f"{tag}: '{due_text}' 는 날짜로 바꿀 수 없는 표현입니다 (사람 확인)"))
        elif r[0].isoformat() != due:
            problems.append(("DUE", f"{tag}: '{due_text}' 는 {r[0]} ({r[1]}) 인데 AI는 {due} 로 적었습니다"))
    return problems


def validate(data, notes, attendees=None):
    problems = check_schema(data)
    if problems:
        return problems
    return check_grounding(data, notes, attendees)


def attach_basis(data):
    """보드에 보여 줄 '변환 근거'를 붙인다."""
    for it in data["items"]:
        r = resolve(it["due_text"], data["meeting_date"]) if it["due_text"] else None
        it["due_basis"] = r[1] if r else ""
    return data


# ---------- 5. 실행 ----------
def run(notes_path, meeting_date, backend, attendees=None, out_dir=None):
    notes = read_notes(notes_path)
    safe, masked = mask_structured(notes)
    prompt = PROMPT.format(date=meeting_date, notes=safe)
    try:
        data = call_ai(prompt, backend)
    except BadAIResponse as e:
        data, problems = None, [("SCHEMA", f"AI 응답을 JSON으로 읽지 못했습니다: {e}")]
    else:
        problems = validate(data, safe, attendees)
    result = {"source": Path(notes_path).name, "masked_values": masked,
              "problems": [{"code": c, "message": m} for c, m in problems]}
    if out_dir:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        stem = Path(notes_path).stem
        if problems:
            (out / f"rejected_{stem}.json").write_text(json.dumps({**result, "ai_response": data},
                                                                 ensure_ascii=False, indent=2), encoding="utf-8")
        else:
            attach_basis(data)
            data["source"] = result["source"]
            data["extracted_at"] = dt.datetime.now().astimezone().isoformat(timespec="seconds")
            (out / f"actions_{stem}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                                      encoding="utf-8")
    return data, problems


def make_backend(spec):
    if spec.startswith("mock:"):
        reply = Path(spec[5:]).read_text(encoding="utf-8")
        return MockAI(reply)
    return cli_backend(spec)


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="회의록에서 Action Item 뽑기")
    ap.add_argument("notes")
    ap.add_argument("--date", required=True, help="회의 날짜 YYYY-MM-DD (상대 날짜 계산 기준)")
    ap.add_argument("--attendees", default="", help="참석자 이름, 쉼표로 구분 (선택)")
    ap.add_argument("--ai", default="claude", help="claude | codex | mock:응답파일.json")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "output"))
    a = ap.parse_args(argv)
    attendees = [x.strip() for x in a.attendees.split(",") if x.strip()] or None
    data, problems = run(a.notes, a.date, make_backend(a.ai), attendees, a.out)
    if problems:
        print(f"[거부] {Path(a.notes).name}: 문제 {len(problems)}건. 보드에 올리지 않습니다.")
        for code, msg in problems:
            print(f"  {code:<6} {msg}")
        return 1
    print(f"[통과] {Path(a.notes).name}: 할 일 {len(data['items'])}건 -> output/actions_{Path(a.notes).stem}.json")
    for it in data["items"]:
        print(f"  {it['id']} {it['owner']:<4} {it['due']:<10} {it['task']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
