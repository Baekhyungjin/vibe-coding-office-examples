"""앱 4 하네스 테스트 (CRITERIA.md 의 S/N 항목과 사양서 T1~T6 에 대응)

화면 동작(T5)은 브라우저로 직접 확인한다. 여기서는 화면 파일이 약속한 부품을 갖췄는지(정적 검사)와
회의 데이터가 섞여 들어가지 않았는지(T6)를 본다.
"""
import json
import re
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from ai_call import MaskingNotPassed, MockAI, call_ai  # noqa: E402
from dates import resolve  # noqa: E402
from extract import PROMPT, check_schema, mask_structured, read_notes, run, validate  # noqa: E402
from verify_core import record_metric  # noqa: E402

GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
BOARD = ROOT / "board" / "index.html"
OUT = ROOT / "output" / "_test_tmp"      # 시스템 TEMP 는 쓰기가 막힌 PC가 있어 output/ 아래를 쓴다


def meetings():
    return json.loads((GOLDEN / "meetings.json").read_text(encoding="utf-8"))


def mock_for(rel):
    return MockAI((GOLDEN / rel).read_text(encoding="utf-8"))


class T1_추출결과_검사통과(unittest.TestCase):
    def test_T1_골든3개_스키마와_근거_모두_통과(self):
        total = 0
        for m in meetings():
            data, problems = run(GOLDEN / m["file"], m["date"], mock_for(m["response"]), m["attendees"], None)
            self.assertEqual([], problems, f"{m['file']} 에서 문제 발견: {problems}")
            total += len(data["items"])
        self.assertEqual(15, total)
        record_metric(ROOT, "골든 Action Item 수", total)

    def test_T1_docx_회의록도_읽는다(self):
        text = read_notes(GOLDEN / "meeting_03.docx")
        self.assertIn("남궁솔 님이 3일 후까지 장소 견적을 받아 온다.", text)

    def test_T1_성공하면_actions_파일_실패하면_rejected_파일(self):
        m = meetings()[0]
        OUT.mkdir(parents=True, exist_ok=True)
        for f in OUT.glob("*.json"):
            f.unlink()
        run(GOLDEN / m["file"], m["date"], mock_for(m["response"]), m["attendees"], OUT)
        self.assertTrue((OUT / "actions_meeting_01.json").exists())
        bad = (TRAP / "trap_unknown_owner.json").read_text(encoding="utf-8")
        run(GOLDEN / m["file"], m["date"], MockAI(bad), m["attendees"], OUT)
        self.assertTrue((OUT / "rejected_meeting_01.json").exists())
        saved = json.loads((OUT / "actions_meeting_01.json").read_text(encoding="utf-8"))
        self.assertTrue(all("due_basis" in it for it in saved["items"]))


class T2_함정응답은_반드시_FAIL(unittest.TestCase):
    def test_T2_함정마다_정해진_이유로_걸린다(self):
        expected = json.loads((TRAP / "expected.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(expected), 3)
        m = meetings()[0]
        notes, _ = mask_structured(read_notes(GOLDEN / m["file"]))   # AI가 본 것과 같은 '가린 글'로 대조
        for fname, rule in expected.items():
            data = json.loads((TRAP / fname).read_text(encoding="utf-8"))
            problems = validate(data, notes, m["attendees"])
            codes = {c for c, _ in problems}
            self.assertIn(rule["must_fail_with"], codes, f"{fname}: {rule['why']} 인데 {sorted(codes) or '문제 없음'} 으로 통과")

    def test_T2_없는_담당자는_지어내지_않고_미정이어야_한다(self):
        data = json.loads((TRAP / "trap_guess_owner.json").read_text(encoding="utf-8"))
        notes, _ = mask_structured(read_notes(GOLDEN / "meeting_01.txt"))
        problems = validate(data, notes, meetings()[0]["attendees"])
        self.assertTrue(any(c == "OWNER" for c, _ in problems))


class T3_근거문장_대조(unittest.TestCase):
    def test_T3_한글자_다른_인용도_잡는다(self):
        data = json.loads((TRAP / "trap_quote_changed.json").read_text(encoding="utf-8"))
        notes, _ = mask_structured(read_notes(GOLDEN / "meeting_01.txt"))
        problems = validate(data, notes, None)
        self.assertTrue(any(c == "QUOTE" for c, _ in problems))

    def test_T3_스키마_위반을_잡는다(self):
        data = json.loads((TRAP / "trap_schema.json").read_text(encoding="utf-8"))
        codes = {c for c, _ in check_schema(data)}
        self.assertEqual({"SCHEMA"}, codes)


class T4_상대날짜_변환(unittest.TestCase):
    CASES = [  # (회의 날짜, 표현, 기대 날짜)  회의 날짜 2026-10-19 는 월요일
        ("2026-10-19", "오늘 중으로", "2026-10-19"),
        ("2026-10-19", "내일까지", "2026-10-20"),
        ("2026-10-19", "모레까지", "2026-10-21"),
        ("2026-10-19", "3일 후까지", "2026-10-22"),
        ("2026-10-19", "이번 주 안에", "2026-10-23"),
        ("2026-10-19", "이번 주 수요일까지", "2026-10-21"),
        ("2026-10-19", "다음 주 금요일까지", "2026-10-30"),
        ("2026-10-19", "다음 주 화요일까지", "2026-10-27"),
        ("2026-10-19", "다음 주 중에", "2026-10-30"),
        ("2026-10-19", "월말까지", "2026-10-31"),
        ("2026-10-19", "다음 달 5일까지", "2026-11-05"),
        ("2026-10-19", "11월 3일까지", "2026-11-03"),
        ("2026-12-28", "다음 달 10일까지", "2027-01-10"),
        ("2026-10-21", "다음 주 중에", "2026-10-30"),      # 수요일에 말한 '다음 주'
        ("2026-10-23", "다음 주 월요일까지", "2026-10-26"),  # 금요일에 말한 '다음 주 월요일'
        ("2026-10-25", "다음 주 금요일까지", "2026-10-30"),  # 일요일에 말한 '다음 주'
    ]

    def test_T4_상대날짜_정확도_100퍼센트(self):
        wrong = []
        for base, expr, want in self.CASES:
            r = resolve(expr, base)
            got = r[0].isoformat() if r else None
            if got != want:
                wrong.append(f"{base} 에 '{expr}' -> {got} (기대 {want})")
        record_metric(ROOT, "상대 날짜 정확도", f"{len(self.CASES) - len(wrong)}/{len(self.CASES)}")
        self.assertEqual([], wrong, "상대 날짜 변환 오류: " + " | ".join(wrong))

    def test_T4_바꿀수_없는_표현은_억지로_바꾸지_않는다(self):
        for expr in ("조만간", "시간 날 때", "다음에"):
            self.assertIsNone(resolve(expr, "2026-10-19"), expr)


class N1_AI에는_가린_글만(unittest.TestCase):
    def test_N1_고객번호는_AI가_받기_전에_가려진다(self):
        m = meetings()[0]
        ai = mock_for(m["response"])
        run(GOLDEN / m["file"], m["date"], ai, m["attendees"], None)
        self.assertEqual(1, len(ai.received))
        self.assertNotIn("010-2741-3958", ai.received[0])
        self.assertIn("[phone]", ai.received[0].lower().replace("[전화]", "[phone]"))

    def test_N1_가리지_않은_글은_AI_호출이_막힌다(self):
        with self.assertRaises(MaskingNotPassed):
            call_ai("고객 연락처 010-2741-3958 확인", MockAI("{}"))


class T6_보드_화면파일_정적검사(unittest.TestCase):
    def html(self):
        return BOARD.read_text(encoding="utf-8")

    def test_T5_화면에_필요한_부품이_있다(self):
        h = self.html()
        for needle in ('id="file-input"', 'id="owner-filter"', 'id="col-todo"', 'id="col-doing"',
                       'id="col-done"', 'id="export-csv"', "localStorage", "draggable", "기한 지남"):
            self.assertIn(needle, h, f"board/index.html 에 {needle} 가 없습니다")

    def test_T6_회의_데이터_문자열이_0건(self):
        h = self.html()
        leaked = []
        for m in meetings():
            data = json.loads((GOLDEN / m["response"]).read_text(encoding="utf-8"))
            for it in data["items"]:
                for key in ("task", "source_quote"):
                    if it[key] in h:
                        leaked.append(it[key][:20])
            for name in m["attendees"]:
                if name in h:
                    leaked.append(name)
        self.assertEqual([], leaked, f"화면 파일에 회의 데이터가 들어 있습니다: {leaked}")

    def test_T6_외부_주소와_외부_스크립트가_0건(self):
        h = self.html()
        self.assertIsNone(re.search(r"https?://", h), "외부 주소가 있으면 데이터가 밖으로 나갈 수 있습니다")
        self.assertIsNone(re.search(r"<script[^>]+src=", h, re.I))
        self.assertIsNone(re.search(r"\b(fetch|XMLHttpRequest|sendBeacon)\b", h), "네트워크 전송 코드가 있습니다")

    def test_N4_gitignore가_회의데이터_폴더를_막는다(self):
        g = (ROOT / ".gitignore").read_text(encoding="utf-8")
        self.assertIn("data/", g)
        self.assertIn("output/", g)


if __name__ == "__main__":
    unittest.main()
