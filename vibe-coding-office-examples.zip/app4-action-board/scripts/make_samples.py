"""가짜 회의록과 '기대 AI 응답', 함정 응답을 만든다.

모든 이름, 부서, 숫자는 지어낸 것이다. 실제 회의록은 data/ 에만 두고 여기에 복사하지 않는다.
한 번 만든 뒤 사람이 승인하면 samples/ 는 잠근다. (AI가 고치지 않는다)
"""
import copy
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
G = ROOT / "samples" / "golden"
T = ROOT / "samples" / "trap"

M1 = """고객지원팀 주간 회의록
일시: 2026년 10월 19일(월) 10:00
참석: 한지원 팀장, 도하윤, 변지석, 남궁솔, 여태민

1. 지난주 문의 현황
지난주 문의는 612건으로 전주보다 8% 늘었다.
환불 문의가 가장 많았고, 배송 지연 문의가 뒤를 이었다.

2. 환불 처리 지연
환불 처리가 평균 4일 걸린다는 불만이 많다.
도하윤 님이 환불 처리 단계별 소요 시간을 정리해 다음 주 금요일까지 공유하기로 했다.
재무팀과의 협의는 한지원 팀장이 이번 주 안에 일정을 잡는다.

3. 답변 템플릿 정비
자주 묻는 질문 답변 템플릿이 오래되었다.
변지석 님이 상위 20개 질문 템플릿을 새로 쓰기로 했다. 마감은 월말.
남궁솔 님은 템플릿 검수를 맡는다.

4. 기타
야간 문의 자동 응답 문구를 바꾸자는 의견이 나왔다. 담당과 일정은 다음 회의에서 정한다.
여태민 님은 내일까지 지난주 불만 문의 상위 5건을 요약해 팀 채널에 올린다.
고객 재연락 요청 건은 고객 번호 010-2741-3958 로 오늘 다시 연락하기로 했다.
"""

M2 = """# 영업-고객지원 연계 회의
- 일시: 2026-10-21 (수) 15:00
- 참석: 한지원, 봉수아, 표건우, 도하윤

## 안건 1. 기업 고객 문의 창구 일원화
- 기업 고객 문의가 영업과 고객지원으로 나뉘어 들어와 중복 응대가 생긴다.
- 봉수아 님이 기업 고객 전용 문의 양식 초안을 모레까지 만든다.
- 표건우 님은 이번 주 금요일까지 기업 고객 목록을 고객지원팀에 넘긴다.

## 안건 2. 응대 품질 점검
- 도하윤 님이 11월 3일까지 기업 고객 응대 사례 10건을 모아 공유한다.
- 점검 결과 보고는 한지원 팀장이 다음 주 중에 한다.
"""

M3 = [
    "고객지원팀 워크숍 준비 회의",
    "일시: 2026년 10월 26일(월) 14:00 / 참석: 한지원, 남궁솔, 여태민, 변지석",
    "워크숍 장소 후보 세 곳을 비교했다.",
    "남궁솔 님이 3일 후까지 장소 견적을 받아 온다.",
    "여태민 님은 다음 주 화요일까지 워크숍 일정표 초안을 만든다.",
    "변지석 님이 오늘 중으로 참석 인원을 확정해 공유한다.",
    "예산 승인은 한지원 팀장이 다음 달 5일까지 받는다.",
]


def item(i, task, owner, due, due_text, quote):
    return {"id": f"A{i}", "task": task, "owner": owner, "due": due, "due_text": due_text,
            "status": "todo", "source_quote": quote}


R1 = {"meeting_date": "2026-10-19", "items": [
    item(1, "환불 처리 단계별 소요 시간 정리 후 공유", "도하윤", "2026-10-30", "다음 주 금요일까지",
         "도하윤 님이 환불 처리 단계별 소요 시간을 정리해 다음 주 금요일까지 공유하기로 했다."),
    item(2, "재무팀 협의 일정 잡기", "한지원", "2026-10-23", "이번 주 안에",
         "재무팀과의 협의는 한지원 팀장이 이번 주 안에 일정을 잡는다."),
    item(3, "상위 20개 질문 답변 템플릿 새로 쓰기", "변지석", "2026-10-31", "월말",
         "변지석 님이 상위 20개 질문 템플릿을 새로 쓰기로 했다."),
    item(4, "새 템플릿 검수", "남궁솔", "미정", "", "남궁솔 님은 템플릿 검수를 맡는다."),
    item(5, "야간 자동 응답 문구 변경 검토", "미정", "미정", "",
         "야간 문의 자동 응답 문구를 바꾸자는 의견이 나왔다."),
    item(6, "지난주 불만 문의 상위 5건 요약해 팀 채널에 올리기", "여태민", "2026-10-20", "내일까지",
         "여태민 님은 내일까지 지난주 불만 문의 상위 5건을 요약해 팀 채널에 올린다."),
    item(7, "재연락 요청 고객에게 다시 연락", "미정", "2026-10-19", "오늘",
         "고객 재연락 요청 건은 고객 번호 [전화] 로 오늘 다시 연락하기로 했다."),
]}

R2 = {"meeting_date": "2026-10-21", "items": [
    item(1, "기업 고객 전용 문의 양식 초안 만들기", "봉수아", "2026-10-23", "모레까지",
         "- 봉수아 님이 기업 고객 전용 문의 양식 초안을 모레까지 만든다."),
    item(2, "기업 고객 목록을 고객지원팀에 넘기기", "표건우", "2026-10-23", "이번 주 금요일까지",
         "- 표건우 님은 이번 주 금요일까지 기업 고객 목록을 고객지원팀에 넘긴다."),
    item(3, "기업 고객 응대 사례 10건 모아 공유", "도하윤", "2026-11-03", "11월 3일까지",
         "- 도하윤 님이 11월 3일까지 기업 고객 응대 사례 10건을 모아 공유한다."),
    item(4, "응대 품질 점검 결과 보고", "한지원", "2026-10-30", "다음 주 중에",
         "- 점검 결과 보고는 한지원 팀장이 다음 주 중에 한다."),
]}

R3 = {"meeting_date": "2026-10-26", "items": [
    item(1, "워크숍 장소 견적 받기", "남궁솔", "2026-10-29", "3일 후까지",
         "남궁솔 님이 3일 후까지 장소 견적을 받아 온다."),
    item(2, "워크숍 일정표 초안 만들기", "여태민", "2026-11-03", "다음 주 화요일까지",
         "여태민 님은 다음 주 화요일까지 워크숍 일정표 초안을 만든다."),
    item(3, "참석 인원 확정해 공유", "변지석", "2026-10-26", "오늘 중으로",
         "변지석 님이 오늘 중으로 참석 인원을 확정해 공유한다."),
    item(4, "워크숍 예산 승인 받기", "한지원", "2026-11-05", "다음 달 5일까지",
         "예산 승인은 한지원 팀장이 다음 달 5일까지 받는다."),
]}

MEETINGS = [
    {"file": "meeting_01.txt", "date": "2026-10-19",
     "attendees": ["한지원", "도하윤", "변지석", "남궁솔", "여태민"], "response": "responses/meeting_01.json"},
    {"file": "meeting_02.md", "date": "2026-10-21",
     "attendees": ["한지원", "봉수아", "표건우", "도하윤"], "response": "responses/meeting_02.json"},
    {"file": "meeting_03.docx", "date": "2026-10-26",
     "attendees": ["한지원", "남궁솔", "여태민", "변지석"], "response": "responses/meeting_03.json"},
]


def traps():
    """meeting_01 에 대한 '틀린 AI 응답'. 하네스가 반드시 FAIL 로 잡아야 한다."""
    out = {}
    t = copy.deepcopy(R1)
    t["items"][0]["owner"] = "윤재호"                       # 회의록에 없는 사람
    out["trap_unknown_owner.json"] = (t, "OWNER", "회의록과 참석자 명단에 없는 담당자 '윤재호'")
    t = copy.deepcopy(R1)
    t["items"][1]["source_quote"] = t["items"][1]["source_quote"].replace("이번 주 안에", "이번 주 내에")
    out["trap_quote_changed.json"] = (t, "QUOTE", "근거 문장에서 '안'을 '내'로 한 글자 바꿈")
    t = copy.deepcopy(R1)
    t["items"][3]["due"], t["items"][3]["due_text"] = "2026-10-23", ""   # 검수 마감은 회의록에 없다
    out["trap_invented_due.json"] = (t, "DUE", "회의록에 없는 검수 마감일을 지어냄")
    t = copy.deepcopy(R1)
    t["items"][0]["due"] = "2026-10-23"                     # 다음 주 금요일을 이번 주로 잘못 계산
    out["trap_wrong_date.json"] = (t, "DUE", "'다음 주 금요일'을 이번 주 금요일로 계산")
    t = copy.deepcopy(R1)
    t["items"][2]["status"] = "보류"
    del t["items"][4]["source_quote"]
    out["trap_schema.json"] = (t, "SCHEMA", "허용되지 않은 상태값 '보류', 근거 칸 누락")
    t = copy.deepcopy(R1)
    t["items"][4]["owner"] = "한지원"                       # 담당 미정인데 아무나 붙임 (앞뒤 2문장 안에 없는 사람)
    out["trap_guess_owner.json"] = (t, "OWNER", "담당 미정 항목에 근처에 없는 사람을 붙임")
    return out


def main():
    G.mkdir(parents=True, exist_ok=True)
    (G / "responses").mkdir(exist_ok=True)
    T.mkdir(parents=True, exist_ok=True)
    (G / "meeting_01.txt").write_text(M1, encoding="utf-8")
    (G / "meeting_02.md").write_text(M2, encoding="utf-8")
    import docx
    d = docx.Document()
    for p in M3:
        d.add_paragraph(p)
    d.save(str(G / "meeting_03.docx"))
    for name, data in (("meeting_01", R1), ("meeting_02", R2), ("meeting_03", R3)):
        (G / "responses" / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (G / "meetings.json").write_text(json.dumps(MEETINGS, ensure_ascii=False, indent=2), encoding="utf-8")
    expected = {}
    for fname, (data, code, why) in traps().items():
        (T / fname).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        expected[fname] = {"must_fail_with": code, "why": why, "notes": "golden/meeting_01.txt"}
    (T / "expected.json").write_text(json.dumps(expected, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"골든 회의록 3개, 기대 응답 3개, 함정 응답 {len(expected)}개를 만들었습니다.")


if __name__ == "__main__":
    main()
