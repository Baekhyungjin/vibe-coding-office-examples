# 앱 4. 회의록 Action Item 추적 대시보드

회의록 한 편을 넣으면 담당자, 마감일, 할 일을 뽑아 칸반 보드로 보여줍니다. 모든 예제 데이터는 지어낸 것입니다.

## 실행 (3줄)
```
python scripts/make_samples.py                      # 가짜 회의록과 기대 응답 만들기 (한 번만)
python src/extract.py samples/golden/meeting_01.txt --date 2026-10-19 --attendees 한지원,도하윤,변지석,남궁솔,여태민 --ai mock:samples/golden/responses/meeting_01.json
python scripts/verify.py                            # 하네스 실행, 마지막 줄이 RESULT: PASSED 여야 합니다
```
보드는 `board/index.html` 을 브라우저로 열고, 추출 결과(`output/actions_*.json`)를 "불러오기" 합니다.

실제 AI로 추출하려면 `--ai claude` 또는 `--ai codex` 를 씁니다. [확인 필요: 독자 환경에서 실제 호출 확인]

## 폴더
- `src/extract.py` 회의록 -> AI -> 검사 -> JSON,  `src/dates.py` 상대 날짜 계산,  `src/ai_call.py`, `src/masking.py` 공통 모듈 복사본
- `board/index.html` 빌드가 필요 없는 단일 화면 파일. 회의 데이터는 들어 있지 않습니다.
- `samples/golden`, `samples/trap` 통과해야 하는 예시와 반드시 걸려야 하는 예시
- `data/` 실제 회의록 (Git 제외),  `output/` 결과물 (Git 제외)

## 공개 배포
화면 파일만 GitHub Pages에 올릴 수 있습니다. 회의 데이터(`data/`, `output/`)는 올리지 마세요.
