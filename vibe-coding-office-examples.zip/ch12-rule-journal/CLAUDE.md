# 이 폴더에서 일하는 AI가 지킬 규칙 (CLAUDE.md)

Codex를 쓰는 경우 같은 내용을 AGENTS.md 로 복사해 두세요.

## 작업 시작할 때
- CRITERIA.md 를 먼저 읽고, 어떤 테스트로 확인할지 목록부터 보여준다.
- 사람이 테스트 목록을 승인하기 전에는 코드를 고치지 않는다.

## 완료 기준
- "다 했습니다"라고 말하기 전에 반드시 `python scripts/verify.py` 를 실행한다.
- 마지막 줄이 `RESULT: PASSED (n/n)` 일 때만 완료로 보고한다.

## 절대 하지 말 것
- tests/, samples/, CRITERIA.md 를 고치지 않는다.
- CLAUDE.md 를 직접 손으로 고치지 말고 `python scripts/add_rule.py` 로만 항목을 추가한다.
- monthly_review.py 가 보여 주는 정리 후보를 사람 확인 없이 지우지 않는다.
- 같은 테스트가 5번 연속 실패하면 더 고치지 말고 원인과 선택지를 보고한다.

## 실수 기록