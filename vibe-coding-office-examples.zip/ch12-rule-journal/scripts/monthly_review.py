"""월 1회 규칙 점검. CLAUDE.md 의 실수 기록을 훑어서 정리할 것을 알려 준다.

사용법:
    python scripts/monthly_review.py                 # 이 폴더의 CLAUDE.md
    python scripts/monthly_review.py --claude 경로\\CLAUDE.md --root 앱폴더
    python scripts/monthly_review.py --today 2027-01-20 --stale-days 90

보여 주는 것
  1. 항목 수와 파일 길이 (너무 길면 AI가 뒤쪽 규칙을 놓치기 쉽다)
  2. 지키는 테스트가 없는 규칙 (부탁만 있는 규칙)
  3. 오래된 항목 (정리 후보)
  4. 옛 형식 항목 (한 줄 형식으로 옮길 후보)
이 스크립트는 파일을 고치지 않는다. 정리는 사람이 정한다.
"""
import argparse
import datetime
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import journal  # noqa: E402


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="월 1회 CLAUDE.md 점검")
    ap.add_argument("--claude", default=str(ROOT / "CLAUDE.md"))
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--today", default=datetime.date.today().isoformat())
    ap.add_argument("--stale-days", type=int, default=90)
    ap.add_argument("--max-entries", type=int, default=30)
    args = ap.parse_args(argv)

    r = journal.review(args.claude, args.root, args.today,
                       stale_days=args.stale_days, max_entries=args.max_entries)

    print(f"[월 점검] {Path(args.claude).name}  (기준일 {args.today})")
    print(f"  실수 기록 항목: {r['entries']}개 (권장 {r['max_entries']}개 이하), 파일 {r['line_count']}줄 (권장 {r['max_lines']}줄 이하)")
    if r["too_many"] or r["too_long"]:
        print("  주의: 규칙이 너무 많거나 깁니다. 중복을 합치고 오래된 항목을 정리하세요.")

    print(f"  지키는 테스트가 없는 규칙: {len(r['unlinked'])}개")
    for e in r["unlinked"]:
        print(f"    - {e['date']} {e['rule']}")
    print(f"  {r['stale_days']}일이 지난 항목: {len(r['stale'])}개")
    for e, age in r["stale"]:
        print(f"    - {e['date']} ({age}일 전) {e['rule']}")
    print(f"  옛 형식 항목: {len(r['old_format'])}개")
    for e in r["old_format"]:
        print(f"    - {e['date']} {e['rule'][:50]}")

    todo = len(r["unlinked"]) + len(r["old_format"]) + len(r["stale"])
    print(f"  정리 후보 합계: {todo}건")
    return 0


if __name__ == "__main__":
    sys.exit(main())
