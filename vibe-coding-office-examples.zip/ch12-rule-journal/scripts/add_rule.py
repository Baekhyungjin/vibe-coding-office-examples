"""CLAUDE.md 의 '## 실수 기록' 칸에 항목 한 줄을 추가한다.

사용법:
    python scripts/add_rule.py --mistake "무엇이 틀렸나" --cause "왜 그랬나" ^
        --rule "앞으로 이렇게 한다" --guard "tests/test_x.py::test_name"

    --guard 에 테스트가 아직 없으면 '없음'이라고 적는다(월 점검 때 따로 보여 준다).
    --file  다른 파일을 고치고 싶을 때(기본: CLAUDE.md)
    --date  날짜를 직접 정할 때(기본: 오늘)
"""
import argparse
import datetime
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import journal  # noqa: E402


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="CLAUDE.md 에 실수-원인-규칙 한 줄 추가")
    ap.add_argument("--mistake", required=True)
    ap.add_argument("--cause", required=True)
    ap.add_argument("--rule", required=True)
    ap.add_argument("--guard", required=True, help="지키는 테스트 (예: tests/test_x.py::test_name) 또는 '없음'")
    ap.add_argument("--file", default=str(ROOT / "CLAUDE.md"))
    ap.add_argument("--date", default=datetime.date.today().isoformat())
    args = ap.parse_args(argv)

    path = Path(args.file)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    problems = journal.validate_new_entry(text, args.mistake, args.cause, args.rule, args.guard)
    if problems:
        print("추가하지 않았습니다:", file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        return 1

    line = journal.format_entry(args.date, args.mistake, args.cause, args.rule, args.guard)
    journal.append_entry(path, line)
    print(f"추가했습니다: {path.name}")
    print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
