"""규칙 일지 도우미의 핵심 로직 (표준 라이브러리만 사용)

CLAUDE.md 의 '## 실수 기록' 칸에 아래 한 줄 형식으로 항목을 쌓는다.

- 2026-10-18 | 실수: ... | 원인: ... | 규칙: ... | 지키는 곳: tests/test_x.py::test_name

'지키는 곳'은 그 규칙을 어기면 FAIL 이 나는 테스트다. 테스트가 없으면 '없음'이라고 적는다.
(규칙은 AI에게 하는 부탁이고, 테스트는 강제다. 부탁만 있는 규칙은 월 점검 때 따로 보여 준다.)
"""
import datetime
import re
from pathlib import Path

SECTION = "## 실수 기록"
ENTRY_RE = re.compile(r"^- (\d{4}-\d{2}-\d{2}) \| 실수: (.+?) \| 원인: (.+?) \| 규칙: (.+?) \| 지키는 곳: (.+)$")
OLD_RE = re.compile(r"^- (\d{4}-\d{2}-\d{2}): (.+)$")
NO_GUARD = ("없음", "", "부탁만")
MAX_RULE_CHARS = 120


def parse_entries(text):
    """CLAUDE.md 본문에서 실수 기록 항목을 읽는다.

    반환: [{"kind": "new"|"old", "date": "YYYY-MM-DD", "mistake", "cause", "rule", "guard", "raw"}]
    """
    entries = []
    in_section = False
    for line in text.splitlines():
        if line.startswith("## "):
            in_section = line.strip().startswith(SECTION)
            continue
        if not in_section:
            continue
        m = ENTRY_RE.match(line)
        if m:
            entries.append({"kind": "new", "date": m.group(1), "mistake": m.group(2),
                            "cause": m.group(3), "rule": m.group(4), "guard": m.group(5).strip(),
                            "raw": line})
            continue
        m = OLD_RE.match(line)
        if m:
            entries.append({"kind": "old", "date": m.group(1), "mistake": m.group(2),
                            "cause": "", "rule": m.group(2), "guard": "", "raw": line})
    return entries


def format_entry(date, mistake, cause, rule, guard):
    return f"- {date} | 실수: {mistake} | 원인: {cause} | 규칙: {rule} | 지키는 곳: {guard}"


def append_entry(path, entry_line):
    """'## 실수 기록' 칸의 맨 끝에 한 줄을 넣는다. 칸이 없으면 파일 끝에 만든다."""
    path = Path(path)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    lines = text.splitlines()
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith(SECTION):
            start = i
            break
    if start is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines += [SECTION, entry_line]
    else:
        end = len(lines)
        for j in range(start + 1, len(lines)):
            if lines[j].startswith("## "):
                end = j
                break
        insert_at = end
        while insert_at > start + 1 and not lines[insert_at - 1].strip():
            insert_at -= 1
        lines.insert(insert_at, entry_line)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def validate_new_entry(text, mistake, cause, rule, guard):
    """새 항목이 규칙을 지키는지 본다. 문제가 있으면 한국어 문장 목록을 돌려준다."""
    problems = []
    for name, value in (("실수", mistake), ("원인", cause), ("규칙", rule)):
        if not value or not value.strip():
            problems.append(f"'{name}' 칸이 비어 있습니다.")
    if guard is None or not str(guard).strip():
        problems.append("'지키는 곳'이 비어 있습니다. 테스트 이름을 적거나 '없음'이라고 적어 주세요.")
    for value in (mistake, cause, rule, guard or ""):
        if "|" in value or "\n" in value:
            problems.append("항목 안에 '|' 문자나 줄바꿈은 쓸 수 없습니다.")
            break
    if rule and len(rule) > MAX_RULE_CHARS:
        problems.append(f"규칙이 {len(rule)}자입니다. {MAX_RULE_CHARS}자 이내 한 줄로 줄여 주세요.")
    if rule:
        for e in parse_entries(text):
            if e["rule"].strip() == rule.strip():
                problems.append("이미 같은 규칙이 있습니다. 새로 추가하지 말고 기존 항목을 고쳐 주세요.")
                break
    return problems


def guard_status(entry, root):
    """그 규칙을 지키는 테스트가 있는지 본다. 'linked' | 'unlinked' | 'old'"""
    if entry["kind"] == "old":
        return "old"
    guard = entry["guard"]
    if guard in NO_GUARD:
        return "unlinked"
    # '지키는 곳'은 tests/파일.py::테스트이름 형식이어야 하고, 파일과 이름이 실제로 있어야 한다.
    if "::" not in guard:
        return "unlinked"
    rel, name = guard.split("::", 1)
    test_file = Path(root) / rel.strip()
    if not test_file.is_file():
        return "unlinked"
    if f"def {name.strip()}(" not in test_file.read_text(encoding="utf-8"):
        return "unlinked"
    return "linked"


def review(claude_md, root, today, stale_days=90, max_entries=30, max_lines=150):
    """월 1회 점검 결과를 딕셔너리로 돌려준다."""
    claude_md = Path(claude_md)
    text = claude_md.read_text(encoding="utf-8")
    entries = parse_entries(text)
    today_d = datetime.date.fromisoformat(today)

    unlinked, old_format, stale = [], [], []
    for e in entries:
        status = guard_status(e, root)
        if status == "unlinked":
            unlinked.append(e)
        elif status == "old":
            old_format.append(e)
        age = (today_d - datetime.date.fromisoformat(e["date"])).days
        if age > stale_days:
            stale.append((e, age))

    line_count = len(text.splitlines())
    return {
        "entries": len(entries),
        "unlinked": unlinked,
        "old_format": old_format,
        "stale": stale,
        "too_many": len(entries) > max_entries,
        "too_long": line_count > max_lines,
        "line_count": line_count,
        "max_entries": max_entries,
        "max_lines": max_lines,
        "stale_days": stale_days,
    }
