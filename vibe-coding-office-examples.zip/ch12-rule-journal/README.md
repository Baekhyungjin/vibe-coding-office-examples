# ch12-rule-journal: 실수할 때마다 규칙 한 줄

CLAUDE.md 의 '## 실수 기록' 칸에 `날짜 | 실수 | 원인 | 규칙 | 지키는 곳` 한 줄을 쌓고,
한 달에 한 번 정리 후보를 점검하는 작은 도구입니다. 표준 라이브러리만 씁니다.

    python scripts/add_rule.py --mistake "..." --cause "..." --rule "..." --guard "tests/test_x.py::test_name"
    python scripts/monthly_review.py
    python scripts/verify.py