import hashlib
import io
import shutil
import sys
import unittest
import uuid
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import journal  # noqa: E402
import add_rule  # noqa: E402

GOLDEN = ROOT / "samples" / "golden" / "CLAUDE.sample.md"
TRAP = ROOT / "samples" / "trap"
TODAY = "2026-10-18"
TMP_BASE = ROOT / "output" / "_test_tmp"  # 시스템 TEMP 는 막힌 PC가 있어 앱 폴더 안을 쓴다


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Base(unittest.TestCase):
    def setUp(self):
        TMP_BASE.mkdir(parents=True, exist_ok=True)
        self.tmp = TMP_BASE / uuid.uuid4().hex[:8]
        self.tmp.mkdir()
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    def copy_golden(self):
        dst = self.tmp / "CLAUDE.md"
        shutil.copy(GOLDEN, dst)
        return dst

    def run_add(self, path, **kw):
        argv = ["--file", str(path), "--date", "2026-10-18"]
        for k, v in kw.items():
            argv += [f"--{k}", v]
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = add_rule.main(argv)
        return code, out.getvalue(), err.getvalue()


class TestAddRule(Base):
    GOOD = dict(mistake="표를 반올림함", cause="반올림 금지 규칙이 없었음",
                rule="금액은 반올림하지 않는다", guard="tests/test_journal.py::test_review_golden_numbers")

    def test_parse_entries(self):  # S1 (읽기)
        entries = journal.parse_entries(GOLDEN.read_text(encoding="utf-8"))
        self.assertEqual(len(entries), 5)
        self.assertEqual([e["kind"] for e in entries].count("new"), 4)
        self.assertEqual([e["kind"] for e in entries].count("old"), 1)

    def test_parse_header_with_suffix(self):  # S3: 실제 앱 폴더의 CLAUDE.md 제목은 뒤에 설명이 붙어 있다
        text = ("## 실수 기록 (실수할 때마다 한 줄씩 추가)\n"
                "- 2026-10-18: 옛 형식 항목\n"
                "- 2026-10-19 | 실수: a | 원인: b | 규칙: c | 지키는 곳: 없음\n")
        entries = journal.parse_entries(text)
        self.assertEqual(len(entries), 2)
    def test_add_rule_appends_in_section(self):  # S1, N2
        path = self.copy_golden()
        before = path.read_text(encoding="utf-8").splitlines()
        code, out, err = self.run_add(path, **self.GOOD)
        self.assertEqual(code, 0, err)
        after = path.read_text(encoding="utf-8").splitlines()
        self.assertEqual(after[:len(before)], before, "기존 줄이 바뀌었습니다")
        self.assertEqual(len(after), len(before) + 1)
        self.assertTrue(after[-1].startswith("- 2026-10-18 | 실수: 표를 반올림함 | 원인:"))
        self.assertTrue(after[-1].endswith("지키는 곳: tests/test_journal.py::test_review_golden_numbers"))

    def test_add_rule_keeps_other_sections(self):  # S1
        path = self.tmp / "CLAUDE.md"
        original = ("# 제목\n\n## 실수 기록\n"
                    "- 2026-10-01 | 실수: a | 원인: b | 규칙: c | 지키는 곳: 없음\n\n"
                    "## 메모\n여기는 건드리면 안 됩니다.\n")
        path.write_text(original, encoding="utf-8")
        code, _, err = self.run_add(path, **self.GOOD)
        self.assertEqual(code, 0, err)
        text = path.read_text(encoding="utf-8")
        self.assertTrue(text.endswith("## 메모\n여기는 건드리면 안 됩니다.\n"))
        self.assertLess(text.index("금액은 반올림하지 않는다"), text.index("## 메모"))

    def _assert_rejected(self, **override):
        path = self.copy_golden()
        h = sha(path)
        kw = dict(self.GOOD)
        kw.update(override)
        code, out, err = self.run_add(path, **kw)
        self.assertEqual(code, 1)
        self.assertEqual(sha(path), h, "거절했는데 파일이 바뀌었습니다")
        return err

    def test_add_rule_rejects_long_rule(self):  # S2
        err = self._assert_rejected(rule="가" * 121)
        self.assertIn("120자 이내", err)

    def test_add_rule_rejects_duplicate(self):  # S2
        err = self._assert_rejected(rule="추가하기 전에 같은 규칙이 있는지 먼저 본다")
        self.assertIn("같은 규칙", err)

    def test_add_rule_rejects_missing_guard(self):  # S2
        err = self._assert_rejected(guard="")
        self.assertIn("지키는 곳", err)


class TestReview(Base):
    def test_review_golden_numbers(self):  # S3
        r = journal.review(GOLDEN, ROOT, TODAY)
        self.assertEqual(r["entries"], 5)
        self.assertEqual(len(r["unlinked"]), 1)
        self.assertEqual(len(r["old_format"]), 1)
        self.assertEqual(len(r["stale"]), 1)
        self.assertFalse(r["too_many"])

    def test_review_flags_unlinked(self):  # S3 (지키는 곳 '없음')
        r = journal.review(GOLDEN, ROOT, TODAY)
        self.assertIn("월 점검", r["unlinked"][0]["rule"])

    def test_review_flags_ghost_file(self):  # S4, 함정
        r = journal.review(TRAP / "CLAUDE.trap_ghost_file.md", ROOT, TODAY)
        self.assertEqual(len(r["unlinked"]), 1, "없는 테스트 파일을 가리키는 규칙을 못 잡았습니다")

    def test_review_flags_ghost_name(self):  # S4, 함정
        r = journal.review(TRAP / "CLAUDE.trap_ghost_name.md", ROOT, TODAY)
        self.assertEqual(len(r["unlinked"]), 1, "없는 테스트 이름을 가리키는 규칙을 못 잡았습니다")

    def test_review_flags_too_many(self):  # S5, 함정
        r = journal.review(TRAP / "CLAUDE.trap_too_long.md", ROOT, TODAY)
        self.assertEqual(r["entries"], 35)
        self.assertTrue(r["too_many"])

    def test_review_does_not_modify(self):  # N1
        path = self.copy_golden()
        h = sha(path)
        journal.review(path, ROOT, TODAY)
        self.assertEqual(sha(path), h)


if __name__ == "__main__":
    unittest.main()
